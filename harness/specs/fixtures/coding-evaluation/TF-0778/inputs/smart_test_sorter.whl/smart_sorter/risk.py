"""TF-0023：把可选的并行改动风险提示用于测试优先级（确定性、可解释、只增不减）。

风险提示由宿主（VG）通过 v1 `candidate_request.risk` 提供，来源与版本由宿主保证；本模块
只负责回答一件事：**这条提示在本次候选/这一版目标上，是否有效、以及影响哪些测试**。
它不重写宿主的风险算法（铁律 1），也不猜——裁不了就如实说裁不了。

## 采用规则（写死，可对拍）

对 `risk.hints[]` 里的每条提示，按顺序判定，得到**恰好一条** decision：

| 情形 | decision | 理由前缀 |
| --- | --- | --- |
| 提示带 `oid`，与目标内容身份一致，且 `symbol` 能解析到计划内测试 | `adopted` | `有效风险：` |
| 提示带 `oid`，与目标内容身份**不一致** | `ignored` | `过期风险：` |
| 提示带 `oid`，但请求没有可比的版本身份（无法确认是否过期） | `ignored` | `缺失风险：` |
| **没有 `symbol`**（只有 path） | `ignored` | `无符号风险：` |
| 有 `symbol` 但本次收集的测试里没有引用者 | `ignored` | `失配风险：` |
| 本次以关闭增强的开关运行（`--no-ssi`） | `ignored` | `已关闭：` |

"无符号风险"之所以一律不提权，是跟契约夹具
`contracts/vg-sts/v1/samples/valid/plan_risk_decisions_stale.json` 同口径：只有路径时定位不到
**具体测试**，降级为文件级参考而不单独提权——否则一个叫 `util.py` 的路径提示会把半仓测试都
提到最前，那不是"优先级"而是噪声。

## 影响面（只增不减）

被采用的提示会：

1. 把它解析到的测试**额外纳入** `selected`（若原本被排除）——风险提示说这些测试可能暴露
   两侧交互问题，不跑就无法做到"优先执行"；这是单调更安全的方向，永远不会让计划跑得更少；
2. 把这些测试**排到 order 最前**，顺序确定：先按提示在请求里的先后，再按 `score` 从高到低，
   最后按 collected 原序。

风险**永不**删除常规选择要保留的测试，**永不**把全量回退收窄成子集（回退时 `selected`
已是全集并保持原生顺序，原先可用的风险由共享计划引擎改记 ignored / 保守全量）。

## 关闭增强（增量对照）

`--no-ssi` 时所有提示都记 `ignored / 已关闭：`，计划退回普通选择与普通排序；同一个请求
不带该开关即得增强版。两版除 `rules_id`（`smart-select/v2` vs `smart-select/v2+risk`）与
`plan_id` 外可直接对拍——这就是交给 VG:TF-0169 的"关闭增强的对照输入"。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from smart_sorter import plan

# 采用风险增强时 rules_id 的后缀，与契约夹具 plan_risk_decisions_stale.json 完全一致。
RISK_RULES_SUFFIX = "+risk"


@dataclass(frozen=True)
class RiskOutcome:
    """一次风险评估的结果。

    decisions  直接放进 plan.risk_decisions 的逐条裁定（顺序与提示顺序一致）
    adopted    被采用提示解析到的计划内 nodeid 集合（含原本已被选中的）
    priority   nodeid -> 排序键 (提示序号, -score, collected 序号)，越小越靠前
    labels     nodeid -> 触发它的提示定位符（写进 reasons，便于人工复核）
    applied    是否至少有一条提示被采用（决定 rules_id 是否带 +risk 后缀）
    """

    decisions: list[dict] = field(default_factory=list)
    adopted: frozenset[str] = frozenset()
    priority: dict[str, tuple] = field(default_factory=dict)
    labels: dict[str, str] = field(default_factory=dict)
    applied: bool = False

    def rules_id(self, base: str = plan.DEFAULT_RULES_ID) -> str:
        """本次计划应使用的规则身份：真采用了增强才加后缀，否则与普通计划完全同身份。"""
        return base + RISK_RULES_SUFFIX if self.applied else base


def target_content_identity(request: dict) -> str | None:
    """请求所能比对的【目标内容身份】：提示 oid 就是拿它来判过期的。

    三种模式各自的身份来源（与契约字段一一对应）：
      - candidate：candidate_tree_oid（缺省退到 candidate_commit_oid）——候选内容身份
      - commit：commit_oid——历史提交身份
      - workspace：worktree_content_digest——未提交工作树身份（只用 HEAD 认不出未提交代码）

    取不到时返回 None：那表示"没法判断过期"，而不是"没过期"。
    """
    mode = request.get("mode")
    target = request.get("target") or {}
    identities = request.get("identities") or {}
    if mode == "candidate":
        return target.get("candidate_tree_oid") or target.get("candidate_commit_oid")
    if mode == "commit":
        return target.get("commit_oid")
    if mode == "workspace":
        return identities.get("worktree_content_digest")
    return None


def _oid_equal(left: str, right: str) -> bool:
    """比较两个 OID：大小写不敏感，允许任一方是缩写（>=7 位）前缀。"""
    a, b = str(left).strip().lower(), str(right).strip().lower()
    if len(a) < 7 or len(b) < 7:
        return a == b
    return a.startswith(b) or b.startswith(a)


def _locate(symbol: str, root: str, collected: list[str]) -> set[str]:
    """把提示里的符号解析成【计划内】的测试 nodeid。

    复用 call_graph.select_tests_referencing——这正是 --smart-select 的名称级安全网所用的
    同一份"引用即命中"判据（比只看调用的调用图召回更高，能覆盖把函数当值传递、装饰器引用、
    运算符分派等），所以风险定位的选择口径与常规选择完全同源，不另写一套。
    """
    from smart_sorter.call_graph import select_tests_referencing

    referenced = select_tests_referencing(root, [symbol])
    return {nodeid for nodeid in collected if plan.group_key(nodeid) in referenced}


def evaluate(
    request: dict,
    *,
    root: str,
    collected: list[str],
    enabled: bool = True,
) -> RiskOutcome:
    """评估请求里的风险提示，返回逐条裁定 + 排序键 + 额外纳入的测试。

    纯确定性：同样的 (request, root, collected) 永远得到同样的结果，没有时间/随机因素，
    因此计划在固定输入下稳定可重放（验收第 3 条）。
    """
    risk = request.get("risk")
    if not isinstance(risk, dict):
        return RiskOutcome()
    hints = [h for h in (risk.get("hints") or []) if isinstance(h, dict)]
    if not hints:
        return RiskOutcome()

    source_version = risk.get("source_version") or "unknown"
    identity = target_content_identity(request)
    position = {node_id: index for index, node_id in enumerate(collected)}

    decisions: list[dict] = []
    adopted_priority: dict[str, tuple] = {}
    adopted_labels: dict[str, str] = {}

    for index, hint in enumerate(hints):
        symbol = hint.get("symbol")
        path = hint.get("path")
        hint_oid = hint.get("oid")

        decision = _decide_one(
            hint, index=index, symbol=symbol, path=path, hint_oid=hint_oid,
            source_version=source_version, identity=identity,
            root=root, collected=collected, position=position,
            enabled=enabled,
        )
        decisions.append(decision["entry"])
        for node_id in decision["matched"]:
            key = (index, -decision["score"], position.get(node_id, len(collected)))
            if node_id not in adopted_priority or key < adopted_priority[node_id]:
                adopted_priority[node_id] = key
                adopted_labels[node_id] = symbol or path or ""

    applied = any(item["decision"] == "adopted" for item in decisions)
    return RiskOutcome(
        decisions=decisions,
        adopted=frozenset(adopted_priority),
        priority=adopted_priority,
        labels=adopted_labels,
        applied=applied,
    )


def _decide_one(
    hint: dict, *, index: int, symbol, path, hint_oid, source_version: str,
    identity: str | None, root: str, collected: list[str], position: dict,
    enabled: bool,
) -> dict:
    """对单条提示给出裁定。返回 {entry, matched, score}，entry 即 plan.risk_decisions 的一项。"""
    entry: dict = {"decision": "ignored", "reason": ""}
    if symbol:
        entry["symbol"] = symbol
    if path:
        entry["path"] = path

    def ignored(reason: str) -> dict:
        entry["decision"] = "ignored"
        entry["reason"] = reason
        return {"entry": entry, "matched": set(), "score": 0.0}

    # ① 版本核对放在最前：一条指向旧树的提示，即便符号能解析也不该提权。
    if hint_oid:
        if identity is None:
            return ignored(
                f"缺失风险：提示 oid={hint_oid} 需要版本身份才能判定是否过期，"
                f"但请求未提供可比的目标内容身份（{_identity_hint(hint_oid)}），保守忽略"
            )
        if not _oid_equal(hint_oid, identity):
            return ignored(
                f"过期风险：提示 oid={hint_oid} 与目标内容身份 {identity} 不符，"
                "不采用其排序，普通选择独立决定"
            )

    # ② 关闭增强：如实说明，而不是假装没有风险提示。
    if not enabled:
        return ignored("已关闭：本次以关闭增强的开关运行，风险提示不参与排序（供增量对照）")

    # ③ 没有符号就定位不到具体测试——降级为文件级参考，不单独提权（与契约夹具同口径）。
    if not symbol:
        return ignored(
            "无符号风险：仅路径命中，未能定位到具体测试，降级为文件级参考，不单独提权"
        )

    matched = _locate(symbol, root, collected)
    if not matched:
        return ignored(
            f"失配风险：符号 {symbol} 在本次收集的测试里没有引用者，无法定位测试，退回普通选择"
        )

    score = hint.get("score")
    score = float(score) if isinstance(score, (int, float)) and not isinstance(score, bool) else 0.0
    entry["decision"] = "adopted"
    entry["reason"] = (
        f"有效风险：来源版本 {source_version} 与目标一致，符号 {symbol} 解析到 "
        f"{len(matched)} 个计划内测试，优先执行"
    )
    return {"entry": entry, "matched": matched, "score": score}


def _identity_hint(hint_oid: str) -> str:
    """给"缺版本身份"的提示一句可操作的说明，指出该模式本应提供什么字段。"""
    return "candidate 模式需 candidate_tree_oid/candidate_commit_oid，commit 模式需 commit_oid，" \
           "workspace 模式需 identities.worktree_content_digest"
