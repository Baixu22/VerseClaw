# -*- coding: utf-8 -*-
"""把 1.1 形状的计划**升格**成 2.0 形状（在 `contracts/vg-sts/v2/` 下）。

设计前提（照实说）：
- **决策逻辑一行没改**。选择/排序/回退全部仍由 `plan.assemble_plan` 决定；
  本模块只做"把已决定的结论**表达**成 2.0 要求的形状"。⇒ 2.0 与 1.1 的
  `selected`/`order`/`excluded` 必然**逐项相同**，这是可测的（见 tests）。
- **不臆造身份**。v2 的 `content_identity` 全部取自**请求里已经声明的**内容身份
  与 `content_manifest`。VG 负责完整目录覆盖与排除规则；STS 在规划和执行前后逐项核对
  清单声明的实际字节，再计算清单摘要。不一致就拒绝或记录失效。
- `observed_at` 必填（VG 0039 needs-1 裁定）：规划期我们对内容身份**实际观察**过两次
  ——`before_build`（收集前）与 `after_build`（`build_plan` 之后重新确认），这是
  1.1 里**本来就在做**的事（TF-0019 规则②），此处只是把它显式记进文档。
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from smart_sorter import contract_trees

#: v2 里 `content_identity.kind` 的取值（与权威 schema 的 enum 一致）
_KIND_BY_MODE = {
    "candidate": "git-tree",
    "commit": "git-commit",
    "workspace": "worktree-content",
}


def manifest_digest(content_manifest: dict) -> str:
    """按**声明的算法**对清单再算一次摘要。

    刻意复用请求里的 `algorithm`（R4：摘要必须带算法前缀，否则两版不可比）。
    归一化口径用清单自己声明的 `line_endings`——`normalized-lf` 就先做 CRLF→LF。
    """
    algorithm = str(content_manifest.get("algorithm") or "sha256")
    normalized = str(content_manifest.get("line_endings") or "") == "normalized-lf"
    entries = content_manifest.get("entries") or []
    h = hashlib.new(algorithm)
    for entry in sorted(entries, key=lambda e: str(e.get("path") or "")):
        path = str(entry.get("path") or "")
        digest = str(entry.get("digest") or "")
        algo, _, value = digest.partition(":")
        h.update(path.encode("utf-8"))
        h.update(b"\0")
        h.update(algo.encode("utf-8"))
        h.update(b"\0")
        h.update(value.encode("utf-8"))
        if normalized:
            h.update(b"\n")
        else:
            h.update(b"\r\n")
    return f"{algorithm}:{h.hexdigest()}"


def upgrade_refusal(doc: dict) -> dict:
    """A failed plan has not completed both content observations; do not grant full fallback."""
    return {
        **doc,
        "protocol_version": "2.0",
        "refusal_kind": {
            "target-unconfirmable": "target-unconfirmable",
            "candidate-mismatch": "content-unbound",
            "candidate-drift": "invalidated-during-planning",
            "collection-error": "collection-failed",
        }.get(doc.get("refusal_code"), "unsupported"),
        "content_confirmed": False,
        "conservative_full_available": False,
        "unconfirmed": [{"what": "content_identity", "detail": doc["reason"]}],
    }


def content_mismatch(request: dict, root: str) -> str | None:
    """Check every declared byte; VG separately owns full manifest coverage and exclusions."""
    from pathlib import Path, PurePosixPath
    manifest = request.get("content_manifest") or {}
    base = Path(root).resolve()
    for entry in manifest.get("entries", []):
        rel = entry["path"]
        try:
            relative = PurePosixPath(rel)
            path = base / relative
            if relative.is_absolute() or ".." in relative.parts or not path.parent.resolve().is_relative_to(base):
                return f"内容清单路径超出候选根：{rel}"
            if path.is_symlink():
                if manifest.get("symlinks") != "record-target":
                    return f"不支持清单符号链接口径：{rel}"
                data = str(path.readlink()).encode("utf-8")
            else:
                data = path.read_bytes()
            if manifest.get("line_endings") == "normalized-lf":
                data = data.replace(b"\r\n", b"\n")
            algorithm, expected = entry["digest"].split(":", 1)
            actual = hashlib.new(algorithm, data).hexdigest()
            if actual != expected:
                return f"内容清单与磁盘不一致：{rel}"
        except (OSError, ValueError, UnicodeError) as exc:
            return f"内容清单无法确认 {rel}：{exc}"
    return None


def environment_identity_now() -> dict:
    """本实现**实际**运行环境（v2 的 `environment_identity` / `expected_*` 都用它）。

    诚实边界：这是**规划侧**看到的解释器。执行侧（run_plan）会再取一次并与它比对——
    那时不一致就是 R12 要抓的漂移。两侧复用 Python 版本、平台和安装分发摘要的同一采集器。
    """
    from smart_sorter.environment import identity

    return identity()


def build_v2_plan(
    *,
    plan_v1: dict,
    request: dict,
    before_build_confirmed: bool,
    after_build_confirmed: bool,
) -> dict:
    """把 1.1 计划升格成 2.0。`before/after_build_confirmed` 由调用方给出。

    抛 `ValueError` 的两种情形（**都对应"请求不自洽"，不是"我们做不到"**）：
      ① 请求没有 `content_manifest` 或 `identities.content_identity`（2.0 必填）；
      ② 我们重算的 `manifest_digest` 与 plan 侧声明的对不上（内容身份漂移）。
    """
    manifest = request.get("content_manifest")
    if not isinstance(manifest, dict):
        raise ValueError("2.0 请求必须带 content_manifest（v2 request 必填）")
    req_identity = ((request.get("identities") or {}).get("content_identity")) or {}
    if not req_identity.get("value"):
        raise ValueError("2.0 请求必须带 identities.content_identity.value")

    computed = manifest_digest(manifest)
    declared_in_plan = plan_v1.get("manifest_digest")
    if declared_in_plan and declared_in_plan != computed:
        raise ValueError(
            f"内容身份漂移：plan 侧声明的 manifest_digest={declared_in_plan!r}，"
            f"按请求清单重算={computed!r}"
        )

    mode = str(request.get("mode") or "workspace")
    env = environment_identity_now()
    from smart_sorter.environment import mismatch
    error = mismatch((request.get("identities") or {}).get("environment_identity") or {}, env)
    if error:
        raise ValueError(error)
    import sys

    plan: dict[str, Any] = {
        "protocol_version": "2.0",
        "product_version": plan_v1.get("product_version"),
        "request_id": plan_v1["request_id"],
        "plan_id": plan_v1["plan_id"],
        # target_identity 在 2.0 里**降级为仅展示**（R2）：真实身份在 content_identity。
        "target_identity": plan_v1["target_identity"],
        "content_identity": {
            "kind": _KIND_BY_MODE.get(mode, "worktree-content"),
            "value": str(req_identity["value"]),
            "manifest_digest": computed,
            "exclusion_policy_id": str(manifest.get("exclusion_policy_id") or ""),
            "observed_at": {
                "before_build": "confirmed" if before_build_confirmed else "unconfirmed",
                "after_build": "confirmed" if after_build_confirmed else "unconfirmed",
            },
        },
        "environment_identity": dict(env),
        "expected_environment_identity": dict(env),
        "expected_execution_identity": {"interpreter": sys.executable},
        "policy_identity": {
            "rules_id": plan_v1["rules_id"],
            "policy_version": "enablement/v2",
        },
        "supported_run_modes": list(plan_v1.get("supported_run_modes") or ["pytest-nodeids"]),
        "selection_scope": plan_v1["selection_scope"],
        "collected": list(plan_v1["collected"]),
        "selected": list(plan_v1["selected"]),
        "excluded": list(plan_v1["excluded"]),
        "order": list(plan_v1["order"]),
        "reasons": dict(plan_v1.get("reasons") or {}),
    }
    if plan_v1.get("fallback"):
        plan["fallback"] = list(plan_v1["fallback"])
    if plan_v1.get("risk_decisions"):
        plan["risk_decisions"] = list(plan_v1["risk_decisions"])
    return plan


def binding_errors(request: dict, plan: dict) -> list[str]:
    """2.0 的跨文档绑定自检（**用 2.0 自己的判据**，不用 1.1 的凑合）。

    1.1 的 `contracts.validate_binding` 只看身份链与 scope；2.0 要求**三项内容身份**
    （kind/value/manifest_digest）逐项一致，外加 R9/R12 的期望字段可达性。
    刻意不重写：判据直接取**权威树里那份随契约被 pin 的检查器**（`check_draft.py` 的
    `binding_errors`），否则又是一份『我们以为的规则』。
    """
    import importlib.util

    checker = contract_trees.tree_for("2.0") / "check_draft.py"
    spec = importlib.util.spec_from_file_location("_v2_binding", checker)
    if not (spec and spec.loader):
        return ["2.0 绑定判据不可用；不静默放行"]
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.binding_errors(request, plan, None)


def self_check(plan: dict) -> list[str]:
    """产出前自检：按**权威 v2 schema** 结构校验（不采信任何一方的判据）。"""
    return contract_trees.validate_against(plan, "plan", "2.0")


if __name__ == "__main__":  # 手工复核用
    import sys

    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print(json.dumps({"supported": sorted(contract_trees.SUPPORTED_TREES)}, ensure_ascii=False))
