"""Apply an already-decided plan after pytest collects each requested file once."""
from __future__ import annotations

import pytest


class PlanOrder:
    def __init__(self, order: list[str]):
        self.order = order
        self.requested = set(order)
        if len(self.requested) != len(order):
            raise pytest.UsageError("执行计划包含重复 nodeid")

    def arguments(self, root: str) -> list[str]:
        files = list(dict.fromkeys(node.split("::", 1)[0] for node in self.order))
        return ["-q", "--rootdir", root, "-p", "no:cacheprovider", *files]

    @pytest.hookimpl(trylast=True)
    def pytest_collection_modifyitems(self, config, items):
        by_id = {item.nodeid: item for item in items}
        missing = self.requested - by_id.keys()
        if missing:
            raise pytest.UsageError(f"计划中的测试未收集到：{sorted(missing)[0]}")
        excluded = [item for item in items if item.nodeid not in self.requested]
        items[:] = [by_id[node] for node in self.order]
        if excluded:
            config.hook.pytest_deselected(items=excluded)
