"""Smart Test Sorter — 函数级回归测试优先级排序工具。

PYTEST_DONT_REWRITE: module CLIs import this initializer before pytest starts.
It contains no assertions; the actual pytest plugin can still be rewritten.
"""

__version__ = "0.1.0"
