"""宿主候选请求入口（TF-0027）：消费 VG 的 candidate_request.json → 统一测试计划。

这是本仓对外（VG:TF-0162）的【正式模块入口】：

    <解释器> -m smart_sorter.plan_request --request <candidate_request.json> --out <plan.json>

它不重新实现任何选择/排序算法——解析并确认目标后，一律调用 TF-0020 的
smart_sorter.plan（build_plan / build_refusal），因此 standalone CLI、pytest 插件与宿主
入口三处的测试集合、顺序、理由完全同源（可用同仓库对拍机械核对）。

## 目标确认（调用计划引擎之前）

| mode | 确认什么 | 失败时的 refusal_code |
| --- | --- | --- |
| candidate | repo.path 是可用的 git 仓库；base/ours/theirs 三条 OID 都能解析；candidate_tree_oid（或缺省时由 candidate_commit_oid 推出的树）能解析；候选目录存在；候选目录若是 git 检出，其 tree 必须等于声明的 tree | target-unconfirmable / candidate-mismatch |
| commit | repo.path 可用；commit_oid 能解析 | target-unconfirmable |
| workspace | repo.path 可用；target.head_oid 必须等于仓库当前 HEAD | candidate-mismatch（"工作树不符"） |

**不重新合并、不退回 STS 源码目录或默认 HEAD**：分析/收集的目录一律取
candidate（候选目录）/ commit 与 workspace（repo.path）。

## 生成规则（写死口径，VG 可直接照此核对）

- `target_identity`（candidate 模式）= `"candidate@" + candidate_tree_oid 前 7 位小写十六进制`
  ——例如 tree OID `ddddddd00011122233344555666777888999abc` → `candidate@ddddddd`。
  与契约夹具 `contracts/vg-sts/v1/samples/pairs/valid/matched/plan.json` 同口径。
  其余模式沿用 revision 的既有指纹：commit=`<hexsha[:10]>`、workspace=`worktree@<head[:10]>[+dirty:n]`。
- `target_identity`（refusal 模式）与同目标成功时的 plan 完全一致，便于"同一目标"跨文档核对。
- `plan_id`（未显式给 `--plan-id` 时）= `"plan-" + sha256(协议版本|request_id|target_identity|rules_id|每个 collected nodeid)[:16]`。
  确定性、无墙钟。同一规范化输入 ⇒ 同一 plan_id；测试全集变了 ⇒ plan_id 也变（计划身份绑定它所规划的内容）。

## 输出与退出码

- stdout：机器可读 JSON——成功是 v1.1 test_plan，无法规划是 v1.1 plan_refusal；
  `--out` 另存一份到文件（VG 用文件消费更方便，stdout 保持同源可核对）。
- stderr：人类日志。
- 退出码：0 产出计划 / 3 产出 plan_refusal（带内"无法规划"）/ 2 用法或输入错误
  （请求文件读不了、不是 JSON、缺 request_id——此时连回执都没法绑定，只能走进程级错误）。
- 自身输出一律回喂 contracts.validate 自检；计划还会做一次 validate_binding（错候选自检），
  不合契约就响亮报错，而**不是**静默放行一个 VG 看不懂的计划。

## 能力与版本说明（当前）

- 产品版本：`smart-test-sorter/0.1.0`；契约协议版本 1.1（受支持集合 {1.0, 1.1}）。
  请求声明 1.0 时产出的 test_plan 回显 1.0（1.1 相对 1.0 只有放宽/新增，故仍合法），
  以满足跨文档绑定对 request/plan/result 版本一致的要求。
- 支持的运行方式：`pytest-nodeids`（计划是数据，绝不含让宿主执行的任意 shell 字符串）。
- **风险增强已实现（TF-0023）**：请求带 `risk.hints` 时逐条裁定——
  版本一致且符号能解析到计划内测试的**采用**（额外纳入该测试并排到最前），
  过期/失配/无符号的**忽略并写明原因**；不带风险则产普通计划。
  `--no-ssi` 可关闭增强，得到同一请求的对照计划（`rules_id` 不带 `+risk` 后缀）。
- 收集：真跑 `<解释器> -m pytest --collect-only`，收集失败/0 用例/超时 → plan_refusal，
  解释器里没有 pytest → refusal_code=`dependency-unavailable`。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path

from smart_sorter import (
    __version__,
    collect,
    contract_trees,
    contracts,
    plan,
    plan_v2,
    revision,
    risk,
    safety,
)

# 退出码口径（与 contracts CLI 一致）：0 成功 / 3 带内"无法规划" / 2 用法或输入错误。
_EXIT_OK = 0
_EXIT_USAGE = 2
_EXIT_REFUSAL = 3


def _force_utf8_output() -> None:
    """让 stdout/stderr 用 UTF-8，避免 Windows 默认 GBK 终端把中文打成乱码。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8")
            except (ValueError, OSError):
                pass


# ---- 生成规则：plan_id / target_identity / 风险忽略 --------------------------


def plan_id_for(
    request_id: str,
    target_identity: str,
    collected: list[str],
    *,
    protocol_version: str = plan.PROTOCOL_VERSION,
    rules_id: str = plan.DEFAULT_RULES_ID,
) -> str:
    """确定性地由"请求身份 + 目标身份 + 规则身份 + 测试全集"推出 plan_id。

    不含时间戳/随机数：同一规范化输入重放得到同一 plan_id（可复算、可对拍），而测试全集
    变化会让 plan_id 变化——计划身份因而绑定它实际规划的内容，结果不会绑到"另一个计划"。
    """
    digest = hashlib.sha256()
    digest.update(
        "|".join([protocol_version, request_id, target_identity, rules_id]).encode("utf-8")
    )
    for node_id in sorted(collected):
        # 用 \x00 分隔，避免 "a" + "bc" 与 "ab" + "c" 拼出同一串摘要。
        digest.update(b"\x00")
        digest.update(node_id.encode("utf-8"))
    return f"plan-{digest.hexdigest()[:16]}"


# ---- 由「仓库 + 目标」合成最小合法请求（shadow / stability 共用） -------------


def build_target_request(
    repo: str,
    target: str = revision.WORKTREE,
    *,
    request_id: str,
    capabilities: tuple[str, ...] = ("selection", "prioritization"),
) -> dict:
    """由「仓库 + 目标版本」合成一份最小但合法的 workspace/commit 请求。

    本产品的本地入口（`shadow` / `stability`）面向的是"给我一个仓库和一个目标版本"，
    用户不该为了跑一次验证去手写 `candidate_request.json`（那是 VG 侧的形状）。所以
    这个函数把目标如实表达成契约字段，再交给 `process_request` 的同一条"确认 + 规划"
    链路——不是绕过它，而是替本地用户把请求填好。**只有这一份实现**，两个入口共用，
    避免"同一个目标在两处被填成两种请求"。

    candidate 模式的 base/ours/theirs 无法从一个目录反推，必须由 VG 的请求给出，
    因此这里明确拒绝（调用方应改用 `plan_request` 消费 VG 的请求文件）。
    """
    source = revision.resolve(repo, target)
    if source.kind == "worktree":
        import git

        head = git.Repo(repo).head.commit.hexsha
        return {
            "protocol_version": "1.1",
            "product_version": f"smart-test-sorter/{__version__}",
            "capabilities": list(capabilities),
            "request_id": request_id,
            "mode": "workspace",
            "repo": {"path": repo},
            "target": {"head_oid": head},
            "identities": {"code_oid": head},
        }
    if source.kind == "commit":
        return {
            "protocol_version": "1.1",
            "product_version": f"smart-test-sorter/{__version__}",
            "capabilities": list(capabilities),
            "request_id": request_id,
            "mode": "commit",
            "repo": {"path": repo},
            "target": {"commit_oid": source.identity},
            "identities": {"code_oid": source.identity},
        }
    raise ValueError(
        "本地入口的 --repo/--target 只能表达 workspace 或 commit 目标"
        "（candidate 模式请改用 python -m smart_sorter.plan_request 消费 VG 的请求文件）"
    )


# ---- 目标确认 ----------------------------------------------------------------


@dataclass
class TargetResolution:
    """目标确认结果。ok=False 时 refusal_code/reason 说明为何不能规划。"""

    ok: bool
    analysis_root: str = ""
    target: object = None
    target_identity: str = ""
    refusal_code: str = ""
    reason: str = ""
    notes: list[str] = field(default_factory=list)
    # 目标**可确认**、但改动面无法界定时的保守回退原因：不拒绝，改成强制全量并把原因写进计划。
    conservative_fallback: list[str] = field(default_factory=list)


def confirm_target(request: dict) -> TargetResolution:
    """按 mode 确认请求所指目标与真实仓库/目录一致，并给出分析根与计划引擎的 target。

    这是 TF-0027 验收第 1、4 条：两侧 OID 与候选目录必须核对；不一致要有结构化 refusal，
    绝不"猜一个目录继续跑"。
    """
    import git

    mode = request.get("mode")
    repo_path = (request.get("repo") or {}).get("path")
    target = request.get("target") or {}

    if not repo_path or not Path(repo_path).is_dir():
        return TargetResolution(
            False, refusal_code="target-unconfirmable",
            reason=f"repo.path 不存在或不是目录：{repo_path!r}",
        )
    try:
        repo = git.Repo(repo_path)
    except (git.exc.InvalidGitRepositoryError, git.exc.NoSuchPathError) as exc:
        return TargetResolution(
            False, refusal_code="target-unconfirmable",
            reason=f"repo.path 不是可用的 git 仓库（{repo_path}）：{exc}",
        )

    if mode == "candidate":
        return _confirm_candidate(repo, repo_path, target)
    if mode == "commit":
        return _confirm_commit(repo, repo_path, target)
    if mode == "workspace":
        return _confirm_workspace(repo, repo_path, target)
    # schema 已把 mode 限定在枚举内；走到这里说明校验被绕过。
    return TargetResolution(
        False, refusal_code="unsupported-input", reason=f"未知变更来源模式 mode={mode!r}",
    )


def _confirm_candidate(repo, repo_path: str, target: dict) -> TargetResolution:
    """候选模式：两条 OID + 目录三者相互核对，身份取候选 tree OID。"""
    import git

    base = target.get("base_oid")
    ours = target.get("ours_oid")
    theirs = target.get("theirs_oid")
    candidate_dir = target.get("candidate_dir")
    declared_tree = target.get("candidate_tree_oid")
    commit_oid = target.get("candidate_commit_oid")

    if not Path(candidate_dir).is_dir():
        return TargetResolution(
            False, refusal_code="candidate-mismatch",
            reason=f"candidate_dir 不存在或不是目录：{candidate_dir!r}（候选目录只作定位，但必须真实可读）",
        )

    try:
        for name, oid in (("base_oid", base), ("ours_oid", ours), ("theirs_oid", theirs)):
            repo.commit(oid)
    except (git.exc.BadName, ValueError, KeyError) as exc:
        return TargetResolution(
            False, refusal_code="target-unconfirmable",
            reason=f"候选模式的 {name} 无法在本仓库解析：{exc}",
        )

    tree_oid = None
    if declared_tree:
        try:
            repo.tree(declared_tree)
            tree_oid = declared_tree.strip().lower()
        except (git.exc.BadName, ValueError, KeyError):
            return TargetResolution(
                False, refusal_code="target-unconfirmable",
                reason=f"candidate_tree_oid 无法在本仓库解析为树对象：{declared_tree!r}",
            )
    elif commit_oid:
        try:
            tree_oid = repo.commit(commit_oid).tree.hexsha
        except (git.exc.BadName, ValueError) as exc:
            return TargetResolution(
                False, refusal_code="target-unconfirmable",
                reason=f"candidate_commit_oid 无法解析：{exc}",
            )
    else:
        return TargetResolution(
            False, refusal_code="unsupported-input",
            reason="候选模式必须给出 candidate_tree_oid 或 candidate_commit_oid 作为内容身份",
        )

    notes: list[str] = []
    dir_tree = _dir_head_tree(candidate_dir)
    if dir_tree is None:
        notes.append(
            "候选目录不是 git 检出，无法把目录内容与 candidate_tree_oid 逐字节核对；"
            "候选内容身份以请求声明的 tree OID 为准（目录仅作定位）"
        )
    elif dir_tree != tree_oid:
        return TargetResolution(
            False, refusal_code="candidate-mismatch",
            reason=(
                f"候选目录内容与其声明的 tree OID 不符：目录 HEAD tree={dir_tree[:12]} "
                f"≠ candidate_tree_oid={tree_oid[:12]}（候选/工作树被换过，拒绝出计划）"
            ),
        )
    else:
        notes.append(f"候选目录 HEAD tree 与 candidate_tree_oid 一致（{tree_oid[:12]}）")

    # HEAD tree 一致**不代表磁盘与声明的身份一致**。三种偏差 tree 核对都看不见：
    # 缺文件（部分物化）、被改文件、以及**未跟踪文件**（后者可能正是会被读到的覆盖文件）。
    #
    # 这三样**不能只当提示**：内容身份是请求声明的 tree，被分析/执行的是磁盘；只要两者能不一致
    # 却仍算"目标确认成功"，就永远存在"同一个 tree 身份下不断变化的磁盘"。所以这里直接拒绝
    # 出计划（refusal_code=candidate-mismatch），让 VG 把候选重新物化成**新的候选树身份**再请求。
    # 用的是契约里已有的枚举值，不扩封闭枚举；也刻意不声称"可保守全量"——磁盘不对应任何一个
    # 明确版本，收集到的东西代表不了任何版本。
    divergence = _working_tree_divergence(candidate_dir)
    if divergence:
        groups: list[str] = []
        if divergence["missing"]:
            groups.append(
                f"缺 {len(divergence['missing'])} 个**被跟踪**的文件："
                + "、".join(divergence["missing"][:5])
                + ("…" if len(divergence["missing"]) > 5 else "")
            )
        if divergence["modified"]:
            groups.append(
                f"有 {len(divergence['modified'])} 个被跟踪文件的内容与 tree 不同："
                + "、".join(divergence["modified"][:5])
                + ("…" if len(divergence["modified"]) > 5 else "")
            )
        if divergence["untracked"]:
            groups.append(
                f"有 {len(divergence['untracked'])} 个未跟踪文件（不在 tree 里）："
                + "、".join(divergence["untracked"][:5])
                + ("…" if len(divergence["untracked"]) > 5 else "")
            )
        if groups:
            return TargetResolution(
                False, refusal_code="candidate-mismatch",
                reason=(
                    "候选目录与声明的 tree OID 在**磁盘层面**不一致（HEAD tree 核对照样通过）："
                    + "；".join(groups)
                    + " ——被分析/执行的是磁盘，因此拒绝出计划："
                    "缺文件可能在导入期就被 open()，未跟踪文件可能正是会被读到的覆盖文件"
                    "（例如「存在即覆盖」的本地配置）。内容身份与磁盘必须一致；"
                    "需要继续请由 VG 把候选重新物化成新的候选树身份后重新请求。"
                ),
            )

    # 被 `.gitignore` 命中的文件单独处理，**刻意不拒绝**（2026-10-02 更正）。
    #
    # 为什么不能拒绝：`ignored` 里绝大多数是**测试运行自己产生的产物**。真实例：VG 的两个
    # 可用候选（glimpser#2006 / #2034）里，跑一次全量就会生成 `data/glimpser.db`（4KB SQLite），
    # 而 `data/` 被项目自己的 .gitignore 命中。若把它当"身份不一致"拒绝，就会**拒掉对方唯一
    # 可用的真实候选**；更要紧的是——**同一个 tree 会因为"之前有没有跑过 pytest"而得到不同判定**，
    # 那等于让计划变得不可复现。
    #
    # 但它也**不能静默忽略**（CORRECTION-PLAN §2 的口径是"失效**或明确不支持**，不能静默忽略"）。
    # 所以这里如实报出来、写清 1.1 的能力边界，并把关闭方式指向 2.0 的内容清单
    # （`content_manifest` + 版本化 `exclusion_policy_id`，草案 R3/R5）。
    #
    # **诚实边界**：这条只进 `notes` ⇒ 落在 **stderr 人类日志**里。1.1 的 plan schema 是
    # `additionalProperties: false` 且没有放自由注记的字段，所以它**不在机器可读的计划里**；
    # 宿主（VG，`sts_host.rs::HostRun::json`）会把 stderr 原样带出成一个 **`log` 文本字段**，
    # 所以它到得了对方手里、但**不是一个被解析的结构化信号**——对方不会因此改判定。
    # 要把这条变成参与判定的字段，只能等 2.0（这也是草案存在的理由之一）。
    # **不要**把它读成"已经按契约告诉了消费方"。
    ignored = divergence["ignored"] if divergence else []
    if ignored:
        notes.append(
            f"⚠️ 候选目录里有 {len(ignored)} 个被 `.gitignore` 命中的文件（不在 tree 里、"
            "git 默认也看不见）："
            + "、".join(ignored[:5])
            + ("…" if len(ignored) > 5 else "")
            + " ——**这类文件 1.1 契约绑定不了**：它们既不在声明的 tree 里，也可能是测试运行"
            "自己生成的产物（例如 SQLite 库），所以**不当成『身份不一致』拒绝**"
            "（否则同一 tree 的判定会随『之前有没有跑过 pytest』而变）。"
            "『存在即覆盖』型的本地配置若属于这一类，在 1.1 下无法与运行产物区分；"
            "要真正绑定请走 2.0 的内容清单（`content_manifest` + 版本化 `exclusion_policy_id`）。"
        )

    source = revision.resolve_candidate(
        repo_path, base, ours, theirs, candidate_dir,
        tree_oid=tree_oid, include_candidate_extras=True,
    )

    # 候选内容身份已确认，但"改动面"还依赖 base 是不是真的合并基点。不是的话**不拒绝**
    # （目标仍然可信），而是强制全量并写清原因：宁可全跑，也不在一个没有意义的改动集上做选择。
    conservative: list[str] = []
    base_problem = revision.candidate_base_problem(repo, base, ours, theirs)
    if base_problem:
        conservative.append(f"候选合并基点不可信：{base_problem}；保守回退全量")
        notes.append(conservative[-1])

    return TargetResolution(
        True,
        analysis_root=candidate_dir,
        target=source,
        target_identity=source.identity,
        notes=notes + [source.detail],
        conservative_fallback=conservative,
    )


def _confirm_commit(repo, repo_path: str, target: dict) -> TargetResolution:
    """commit 模式：只确认 OID 可解析；身份沿用 revision 的 hexsha[:10]。"""
    import git

    commit_oid = target.get("commit_oid")
    try:
        repo.commit(commit_oid)
    except (git.exc.BadName, ValueError, KeyError) as exc:
        return TargetResolution(
            False, refusal_code="target-unconfirmable",
            reason=f"commit_oid 无法解析：{commit_oid!r}（{exc}）",
        )
    source = revision.resolve(repo_path, commit_oid)
    return TargetResolution(
        True, analysis_root=repo_path, target=commit_oid,
        target_identity=source.identity,
    )


def _confirm_workspace(repo, repo_path: str, target: dict) -> TargetResolution:
    """workspace 模式：请求声明的 head_oid 必须与仓库当前 HEAD 一致（工作树不符即拒）。"""
    import git

    declared = target.get("head_oid")
    try:
        actual = repo.head.commit.hexsha
    except (ValueError, git.exc.GitError):
        return TargetResolution(
            False, refusal_code="target-unconfirmable",
            reason=f"仓库没有 HEAD，无法确认 workspace 目标：{repo_path}",
        )
    if not declared or not actual.lower().startswith(str(declared).lower()):
        return TargetResolution(
            False, refusal_code="candidate-mismatch",
            reason=(
                f"请求声明的 target.head_oid={declared!r} 与仓库当前 HEAD={actual[:12]} 不符"
                "（工作树被换过，拒绝出计划）"
            ),
        )
    source = revision.resolve(repo_path, revision.WORKTREE)
    return TargetResolution(
        True, analysis_root=repo_path, target=revision.WORKTREE,
        target_identity=source.identity,
    )


def _dir_head_tree(candidate_dir: str) -> str | None:
    """候选目录若是 git 检出，返回其 HEAD tree 的 hexsha；否则 None（不可核对）。"""
    import git

    try:
        return git.Repo(candidate_dir).head.commit.tree.hexsha
    except (git.exc.InvalidGitRepositoryError, git.exc.NoSuchPathError,
            ValueError, git.exc.GitError):
        return None


def _is_build_noise(path: str) -> bool:
    """构建/环境噪声（`__pycache__/`、`*.pyc`、`.pytest_cache/`、`build/`…）不算"与声明身份不一致"。

    为什么必须滤掉：**跑一次 pytest 就会生成 `__pycache__`**。不滤的话这条 note 每次都响
    ⇒ 变成噪声、被人忽略，等于白报。口径与 `revision.content_digest` 一致——那里也是先剪掉
    这些目录，才敢说"分析根内容没变过"。

    排除表本身是**版本化**的（`revision.NOISE_POLICY_ID`）：改了规则就换 id，别让"哪一版规则
    算出来的干净"变得说不清。
    """
    from smart_sorter import revision  # 复用同一份噪声目录表，避免两处口径漂移

    parts = Path(path.rstrip("/")).parts
    if not parts:
        return False
    if any(part in revision._NOISE_DIRS for part in parts):
        return True
    return revision._is_noise(path)


def _working_tree_divergence(candidate_dir: str) -> dict[str, list[str]] | None:
    """候选目录若是 git 检出，返回它与 HEAD tree 的**磁盘层面**分歧（升序去重）。

    为什么需要这个：候选的**内容身份**是请求声明的 tree OID，而真正被分析/执行的是**磁盘**。
    `_dir_head_tree` 只比 HEAD tree，所以下面三种偏差它**一个都看不见**：

    * `missing`   —— 被跟踪但磁盘上没有（部分物化；真实例：`norman#111` 的 `config.yaml.dist`
                     —— 该文件上游是被跟踪的，只因为它"本 PR 没碰过"才被"只检出改动文件"漏掉）
    * `modified`  —— 被跟踪但内容被改过（工作区改动）
    * `untracked` —— 不在 tree 里、但人就在那儿。**这类最危险**：它可能正是会被读到的**覆盖文件**
                     （同一项目的 `config.yaml` 语义就是"存在即覆盖 `.dist`"），
                     于是测试读到的是 tree 之外的内容，而身份核对一路绿灯。
    * `ignored`   —— **被 `.gitignore` 命中**、因而 ls-files 默认看不见的那些（同样会被读到：
                     `config.yaml` 恰恰常常是被 ignore 的本地覆盖文件）。它们既不在 tree 里、
                     也不进 `--others --exclude-standard`，所以 2026-10-01 之前**完全不可见**
                     （TF-0033）。这里单独列出来，用同一份版本化排除表过滤。

    返回 None 表示该目录不是 git 检出（无从核对，不臆测）。**只读**：不修目录、不猜内容。
    """
    import git

    try:
        repo = git.Repo(candidate_dir)
    except (git.exc.InvalidGitRepositoryError, git.exc.NoSuchPathError,
            ValueError, git.exc.GitError):
        return None
    try:
        # `ls-files --deleted` = 被跟踪但磁盘上没有；
        # `diff --name-only HEAD` = **按内容**比较工作区与 HEAD（修改 + **暂存** + 删除都在内）。
        # 刻意**不用** `git status` 的 ` M`：那是 stat 缓存判据，只改 mtime、内容相同也可能报脏，
        # 会造成"候选目录与声明身份不一致"的**误报**（误报多了这条 note 就没人看）。
        missing = {line.strip() for line in repo.git.ls_files("--deleted").splitlines() if line.strip()}
        untracked = {line.strip() for line in repo.git.ls_files(
            "--others", "--exclude-standard").splitlines() if line.strip()}
        # `--ignored --exclude-standard` 列出**被 .gitignore 命中**的文件：默认口径下它们
        # 既不是 tracked、也不算 untracked，等于隐身（TF-0033）。只读查询，不改目录。
        ignored = {line.strip() for line in repo.git.ls_files(
            "--others", "--ignored", "--exclude-standard").splitlines() if line.strip()}
        changed = {line.strip() for line in repo.git.diff(
            "--name-only", "HEAD").splitlines() if line.strip()}
    except git.exc.GitError:
        return None

    def keep(paths):
        return sorted(p for p in paths if not _is_build_noise(p))

    return {
        "missing": keep(missing),
        "modified": keep(changed - missing),
        "untracked": keep(untracked),
        "ignored": keep(ignored),
    }


def _missing_tracked_files(candidate_dir: str) -> list[str] | None:
    """只取"被跟踪但磁盘上没有"那一组；None 表示不是 git 检出。"""
    divergence = _working_tree_divergence(candidate_dir)
    return None if divergence is None else divergence["missing"]


# ---- 主流程 ------------------------------------------------------------------


def process_request(
    request: dict,
    *,
    test_dir: str = "tests",
    xml_dir: str | None = None,
    plan_id: str | None = None,
    python: str | None = None,
    ssi: bool = True,
    log=lambda message: None,
) -> tuple[str, dict]:
    """Keep success and refusal documents on the requested, supported protocol."""
    kind, doc = _process_request(request, test_dir=test_dir, xml_dir=xml_dir,
                                 plan_id=plan_id, python=python, ssi=ssi, log=log)
    if request.get("protocol_version") == "2.0" and kind == "refusal":
        from smart_sorter.plan_v2 import upgrade_refusal
        doc = upgrade_refusal(doc)
    return kind, doc


def _process_request(
    request: dict,
    *,
    test_dir: str = "tests",
    xml_dir: str | None = None,
    plan_id: str | None = None,
    python: str | None = None,
    ssi: bool = True,
    log=lambda message: None,
) -> tuple[str, dict]:
    """把一个已解析的 request dict 变成 ("plan"|"refusal", 契约文档)。

    纯函数式（除了真跑 pytest 收集与读仓库），便于单测直接构造请求。
    """
    request_id = request.get("request_id")
    protocol_version = request.get("protocol_version")

    # 契约树按**文档自己声明的版本**选（1.1 -> v1、2.0 -> v2），不猜、不静默兼容。
    # 口径与 v1 一致：版本不认识 ⇒ 明确拒绝并回执本生产者支持的版本。
    try:
        contract_trees.tree_for(protocol_version)
    except contract_trees.UnsupportedProtocol as exc:
        refusal = plan.build_refusal(request_id, "unknown-protocol", str(exc))
        return "refusal", refusal

    errors = contract_trees.validate_against(request, "request", protocol_version)
    if errors:
        # 结构不过 ⇒ **直接拒绝**（1.1 的既有行为，逐字保留）。
        # 语义层只在结构过了之后才有意义（字段类型都不对时，跨字段判断是假的）——
        # 这与 `contracts.validate` 的分层口径一致，也避免"结构坏了却被语义判据说没问题"而放行。
        refusal = plan.build_refusal(
            request_id, "unsupported-input",
            f"请求不符合 {protocol_version} 契约：" + "；".join(errors),
        )
        return "refusal", refusal
    sem_errors = _semantic_request_errors(request, protocol_version)
    if sem_errors:
        refusal = plan.build_refusal(
            request_id, "unsupported-input",
            f"请求不符合 {protocol_version} 契约：" + "；".join(sem_errors),
        )
        return "refusal", refusal

    resolution = confirm_target(request)
    if not resolution.ok:
        log(f"目标确认失败（{resolution.refusal_code}）：{resolution.reason}")
        refusal = plan.build_refusal(
            request_id, resolution.refusal_code, resolution.reason,
        )
        return "refusal", refusal
    for note in resolution.notes:
        log(f"目标确认：{note}")

    # "候选自身不可导入" 与 "我们的收集实现有问题" 是两件事，但过去都只能以收集失败的形式出现
    # （真实例 norman#111：PR 改的 connectors.py 仍 import 一个已被 ours 搬走的模块）。
    # 所以先静态看一眼改动集：有没有 import 到分析根里不存在的**首方**模块。
    # 这是**诊断**，不改判定、不进契约；异常一律降级成一行日志，绝不因此挡住规划。
    broken: list[tuple[str, str]] = []
    try:
        import git as _git

        broken = safety.broken_first_party_imports(
            revision.resolve(resolution.analysis_root, resolution.target),
            resolution.analysis_root,
        )
    except (ValueError, OSError, _git.exc.GitError) as exc:
        log(f"断链导入预检跳过（{type(exc).__name__}）：{exc}")
    if broken:
        shown = "、".join(f"`{path}` → `{module}`" for path, module in broken[:3])
        log(f"⚠️ 候选改动集里有 {len(broken)} 处**断链导入**（模块在分析根里不存在）：{shown}")

    # 收集与分析都会读分析根；期间目标再被改动，产出的计划就会把两个版本的事实混在一起。
    # 与 run_plan 同口径：**前后各算一次内容指纹**，不同则不产出计划（收集到的东西不对应
    # 任何一个明确版本，因此也不得声称"可保守全量"）。
    if protocol_version == "2.0":
        mismatch = plan_v2.content_mismatch(request, resolution.analysis_root)
        if mismatch:
            return "refusal", plan.build_refusal(request_id, "candidate-mismatch", mismatch,
                                                 target_identity=resolution.target_identity)
    before_digest = revision.content_digest(resolution.analysis_root)
    collected = collect.collect_nodeids(resolution.analysis_root, test_dir, python=python)
    if not collected.succeeded:
        reason = collected.detail
        if broken:
            shown = "、".join(f"{path} → {module}" for path, module in broken[:3])
            reason += (
                f"；另检出 {len(broken)} 处候选改动集内的**断链导入**（{shown}）——"
                "这通常说明**候选自身不可导入**（例如 PR 相对 ours 已过期、某个模块已被搬走），"
                "而不是收集实现的问题"
            )
        log(f"收集失败（{collected.code}）：{reason}")
        refusal = plan.build_refusal(
            request_id, collected.code, reason,
            target_identity=resolution.target_identity,
            collected_count=len(collected.nodeids),
            collection_succeeded=False,
        )
        return "refusal", refusal

    outcome = risk.evaluate(
        request, root=resolution.analysis_root,
        collected=collected.nodeids, enabled=ssi,
    )
    rules_id = outcome.rules_id()

    doc = plan.build_plan(
        resolution.analysis_root,
        resolution.target,
        collected.nodeids,
        request_id=request_id,
        plan_id=plan_id or "",  # Filled from the final policy identity below.
        xml_dir=xml_dir,
        test_dir=test_dir,
        protocol_version=protocol_version,
        rules_id=rules_id,
        risk_decisions=outcome.decisions,
        risk_selected=outcome.adopted,
        risk_priority=outcome.priority,
        risk_labels=outcome.labels,
        extra_fallback_reasons=resolution.conservative_fallback,
    )

    if not plan_id:
        doc["plan_id"] = plan_id_for(
            request_id, resolution.target_identity, collected.nodeids,
            protocol_version=protocol_version, rules_id=doc["rules_id"],
        )
    decisions = doc.get("risk_decisions", [])
    if decisions:
        adopted = sum(1 for d in decisions if d["decision"] == "adopted")
        log(f"风险提示 {len(decisions)} 条：采用 {adopted} 条、忽略 "
            f"{len(decisions) - adopted} 条（逐条原因见 plan.risk_decisions）")

    # 分析与收集都做完，再确认一次目标没被动过。三种都查：
    #   ① 内容指纹（分析了多久就变没变）；② 目标身份有没有换成别的版本；
    #   ③ **确认本身失败**（目录被换掉、磁盘内容对不上声明）。
    # ③ 与 ② 同罪：确认不了就没有明确版本可言，不能只处理 ②。
    after_digest = revision.content_digest(resolution.analysis_root)
    drift: list[str] = []
    if before_digest != after_digest:
        drift.append("规划期间分析根的 .py 内容发生变化")
    recheck = confirm_target(request)
    if not recheck.ok:
        drift.append(
            f"规划期间目标身份无法确认（{recheck.refusal_code}）：{recheck.reason}"
        )
    elif recheck.target_identity != resolution.target_identity:
        drift.append(
            f"规划期间目标身份变化：{resolution.target_identity} → {recheck.target_identity}"
        )
    if protocol_version == "2.0":
        mismatch = plan_v2.content_mismatch(request, resolution.analysis_root)
        if mismatch:
            drift.append(mismatch)
    if drift:
        reason = (
            "；".join(drift) + "——收集与分析的产物不对应任何一个明确的目标版本"
            "（与 TF-0021 执行入口的运行期间复查同口径）"
        )
        log(f"计划作废：{reason}")
        refusal = plan.build_refusal(
            request_id, "target-unconfirmable", reason,
            target_identity=resolution.target_identity,
            collected_count=len(collected.nodeids),
            # 收集本身成功了，但目标已不可信 ⇒ 不声称可保守全量（宁可让宿主重取一次）。
            collection_succeeded=False,
        )
        return "refusal", refusal

    if protocol_version != "1.1":
        # 2.0 请求 ⇒ 产出 2.0 计划。**决策不变**（selected/order/excluded 逐项相同），
        # 只把"怎么表达"换成 v2 要求的形状（内容身份/环境身份/政策身份/observed_at）。
        before_confirmed = resolution.ok  # 收集前那次确认成功
        try:
            doc = plan_v2.build_v2_plan(
                plan_v1=doc, request=request,
                before_build_confirmed=before_confirmed,
                after_build_confirmed=not drift,   # 上面那段复查没报漂移 ⇒ 确认过
            )
        except ValueError as exc:
            log(f"2.0 升格失败：{exc}")
            return "refusal", plan.build_refusal(
                request_id, "unsupported-input", f"2.0 计划升格失败：{exc}",
                target_identity=resolution.target_identity,
                collected_count=len(collected.nodeids),
            )
        bad = plan_v2.self_check(doc)
        if bad:
            log(f"2.0 计划自检未过：{'; '.join(bad)}")
            return "refusal", plan.build_refusal(
                request_id, "unsupported-input",
                "2.0 计划未过权威 schema 自检：" + "；".join(bad),
                target_identity=resolution.target_identity,
                collected_count=len(collected.nodeids),
            )
    return "plan", doc


def _semantic_request_errors(request: dict, protocol_version: str) -> list[str]:
    """请求的**语义**层校验（结构层已由 `contract_trees.validate_against` 过了）。

    1.1 走 `contracts.validate` 自带的语义层（行为**一字未变**）；
    2.0 用权威树里那份可执行的语义检查（`check_draft.py`，在 tools/ 下、随契约一起被 pin）——
    **不另写一套**，否则又是一份"我们以为的规则"。
    """
    if protocol_version == "1.1":
        return contracts.validate(request, "request")
    try:
        import importlib.util

        checker = (contract_trees.tree_for(protocol_version)
                   / "check_draft.py")
        spec = importlib.util.spec_from_file_location("_v2_semantics", checker)
        if not (spec and spec.loader):
            return []
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.semantic_errors(request, "request")
    except Exception as exc:  # 判据不可用 ⇒ 不静默放行，如实报出
        return [f"2.0 语义判据不可用（{exc}）；不静默放行"]


def build_parser() -> argparse.ArgumentParser:
    """入口参数：宿主显式给解释器 + 模块 + 请求文件，不依赖开发机隐式 PATH。"""
    parser = argparse.ArgumentParser(
        prog="smart_sorter.plan_request",
        description="消费 VG 的 v1 candidate_request.json，产出 v1 test_plan（或 plan_refusal）。",
    )
    parser.add_argument("--request", required=True, help="candidate_request JSON 文件路径")
    parser.add_argument("--out", default=None,
                        help="把机器 JSON 另存到该文件（stdout 仍输出同一份，便于核对）")
    parser.add_argument("--output-only", action="store_true",
                        help="成功计划只写 --out，避免在 stdout 重复大计划；拒绝回执仍输出")
    parser.add_argument("--test-dir", default="tests",
                        help="目标仓库内测试目录名，默认 tests")
    parser.add_argument("--xml-dir", default=None,
                        help="可选历史 JUnit XML 目录（按历史失败率加权排序）")
    parser.add_argument("--plan-id", default=None,
                        help="显式指定 plan_id；省略则按确定性规则由请求/目标/测试全集推出")
    parser.add_argument("--python", default=None,
                        help="跑 pytest 的解释器；默认当前解释器（宿主应显式指定）")
    parser.add_argument("--no-ssi", action="store_true",
                        help="关闭风险增强：风险提示逐条记 ignored(已关闭)，计划退回普通选择与排序；"
                             "用于拿同一请求的对照计划（rules_id 不带 +risk 后缀）")
    return parser


def main(argv: list[str] | None = None) -> int:
    """入口主流程。返回进程退出码：0 计划 / 3 无法规划回执 / 2 用法或输入错误。"""
    _force_utf8_output()
    args = build_parser().parse_args(argv)
    if args.output_only and not args.out:
        return _usage_error("--output-only 需要 --out")

    def log(message: str) -> None:
        print(f"[plan_request] {message}", file=sys.stderr)

    try:
        raw = Path(args.request).read_text(encoding="utf-8")
    except FileNotFoundError:
        return _usage_error(f"请求文件不存在 -> {args.request}")
    except OSError as exc:
        return _usage_error(f"请求文件不可读 -> {args.request}：{exc}")

    try:
        request = json.loads(raw)
    except json.JSONDecodeError as exc:
        return _usage_error(f"请求文件不是合法 JSON -> {args.request}：{exc}")

    if not isinstance(request, dict):
        return _usage_error("请求文件顶层必须是 JSON 对象")

    request_id = request.get("request_id")
    if not isinstance(request_id, str) or not request_id:
        # 没有请求身份，连 plan_refusal 都无法绑定（契约要求 request_id 非空）。
        return _usage_error("请求缺少非空的 request_id：既无法绑定计划，也无法产出可绑定的回执")

    kind, doc = process_request(
        request, test_dir=args.test_dir, xml_dir=args.xml_dir,
        plan_id=args.plan_id, python=args.python, ssi=not args.no_ssi, log=log,
    )

    text = json.dumps(doc, ensure_ascii=False, indent=2)
    if args.out:
        try:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
        except OSError as exc:
            # 宿主给了一个写不出去的目标：按用法/输入错误收场，别把栈甩给宿主。
            return _usage_error(f"无法写出 {args.out}：{exc}")
        log(f"已写出 {args.out}")
    if not args.output_only or kind == "refusal":
        print(text)

    # 自产文档必须过**它自己声明的版本**对应的契约树。1.1 走原路径（行为一字未变），
    # 2.0 走 v2 权威 schema——此前这里固定用 v1，于是 2.0 计划会被自己的入口判成
    # 「出现未声明字段」而退 2（我们自己的 e2e 跑出来的真缺陷）。
    doc_version = doc.get("protocol_version")
    try:
        errors = (contracts.validate(doc, kind) if doc_version == "1.1"
                  else contract_trees.validate_against(doc, kind, doc_version))
    except contract_trees.UnsupportedProtocol as exc:
        log(f"内部错误：产出的 {kind} 声明了没有契约树的版本：{exc}")
        return _EXIT_USAGE
    if errors:
        # 自产文档不合自家契约：这是实现 bug，响亮报错而非静默放行。
        log(f"内部错误：生成的 {kind} 不符合 {doc_version} 契约：{errors}")
        return _EXIT_USAGE

    if kind == "plan":
        # 跨文档绑定自检。1.1 用既有的 `contracts.validate_binding`（1.1 的判据逐字未变）；
        # 2.0 的绑定在 `plan_v2.binding_errors`（比 kind/value/manifest_digest 三项 +
        # R9/R12 的执行身份与环境）——**两版各用自己的判据**，不用"1.1 的判据凑合"。
        if doc_version == "1.1":
            binding = contracts.validate_binding(request, doc)
        else:
            binding = plan_v2.binding_errors(request, doc)
        if binding:
            log(f"内部错误：计划与请求的绑定自检失败（{doc_version}）：{binding}")
            return _EXIT_USAGE
        log(
            f"request={request_id} target={doc['target_identity']} plan={doc['plan_id']} "
            f"collected={len(doc['collected'])} selected={len(doc['selected'])} "
            f"scope={doc['selection_scope']}"
        )
        return _EXIT_OK

    # refusal 分支：**2.0 把 `refusal_code` 改成了 `refusal_kind`**（2.0 里 `refusal_code`
    # 只是可选兼容字段）⇒ 不能无条件读 `refusal_code`。2026-10-04 按 VG 0042 修正：
    # 此前这里写成 `if kind == "plan" and doc_version == "1.1"`，于是 **2.0 成功计划掉进本分支**，
    # 下一行读不存在的键 ⇒ KeyError 退 1——**产物其实已落盘且完全合法**，崩在报告成功的路上。
    reason = doc.get("reason", "")
    code = (doc["refusal_kind"] if doc_version != "1.1"
            else doc.get("refusal_code", "")) or "(未给拒因)"
    log(f"无法规划：{code} — {reason}")
    return _EXIT_REFUSAL


def _usage_error(reason: str) -> int:
    """进程级用法/输入错误：stderr 出人类原因，stdout 出一行机器可读错误对象。"""
    print(f"[plan_request] 错误：{reason}", file=sys.stderr)
    print(json.dumps(
        {"ok": False, "error_kind": "input-error", "reason": reason}, ensure_ascii=False,
    ))
    return _EXIT_USAGE


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
