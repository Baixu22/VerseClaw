"""统一测试计划引擎（TF-0020）：把选择 / 排序 / 回退汇总成一份 v1.1 test_plan。

这是 standalone CLI、pytest 插件、宿主候选请求入口(TF-0027)【共用的唯一计划来源】：
它们都调用本模块的 select_affected + assemble_plan，不各自实现选择判据，从而口径无从
漂移（TF-0020 验收："CLI、pytest 插件及实验输出的一致性可机械核对"）。

计划是【数据】：collected / selected / excluded / order / reasons + 回退原因 + （将来的）
风险采用忽略原因，绝不含让宿主直接执行的任意 shell 字符串。

与 contracts/vg-sts/v1/ 的关键契约点：
  - collected / selected / order 保留【真实参数化 nodeid】(foo[utf-8])；group_key 去掉
    参数化后缀只用于把测试与"按短名 / 文件级算出的选择信号"做分组匹配，绝不充当执行身份。
  - selection_scope=full ⇒ selected == collected 全集；
  - 存在改动却选不出任何测试 ⇒ 保守全量（不空选，避免"跑 0 个"被误当成已验证）；
  - 收集不到测试全集 ⇒ 返回 plan_refusal（带内"无法规划"），不硬凑一个空计划当已验证。

本模块只用标准库 + 既有 smart_sorter 模块，判定是纯函数（select_affected / assemble_plan
不碰 git、不读盘），方便单测直接构造 collected 与信号，无需真实仓库。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from smart_sorter import __version__, revision

# 计划支持的运行方式：目前只有"按精确 nodeid 交给 pytest"。
_RUN_MODES = ["pytest-nodeids"]
# 默认选择/排序规则身份，便于复现同一决策；风险增强(TF-0023)接入后另加后缀。
_DEFAULT_RULES_ID = "smart-select/v2"
# 当前契约协议版本（见 contracts/vg-sts/v1/manifest.json）。
_PROTOCOL_VERSION = "1.1"

# 公开别名：入口模块（plan_request）与测试要引用同一常量，避免各自写死一份字符串漂移。
DEFAULT_RULES_ID = _DEFAULT_RULES_ID
PROTOCOL_VERSION = _PROTOCOL_VERSION
SUPPORTED_RUN_MODES = tuple(_RUN_MODES)


def group_key(node_id: str) -> str:
    """把 pytest 的真实 nodeid 归一成【分组 / 匹配键】——不是执行身份。

    pytest 在 Windows 上也用正斜杠 nodeid；参数化用例带 [param] 后缀。选择信号
    （名称级 / 调用图 / 文件级关键词）都按去参数化的短形式计算，所以匹配时把真实
    nodeid 归一到这个键；但计划里 collected/selected/order 存的始终是【真实 nodeid】，
    契约明确禁止用这个归一键充当执行身份（否则会丢掉 [param] 分辨力）。
    """
    node_id = node_id.replace("\\", "/")
    if "[" in node_id:
        node_id = node_id.split("[", 1)[0]
    return node_id


@dataclass(frozen=True)
class SelectionSignals:
    """选择所需的四路信号，全部按 group_key（去参数化）表达。

    这是把"选择判据"与"从哪来的"解耦：plugin 从 git 现算，宿主入口(TF-0027)从候选目录
    现算，实验脚本可手工构造——但都汇成同一个 SelectionSignals 交给 select_affected，
    保证判据实现只有一份（与 plugin.py 的四项并集完全一致）。

    字段（均为 group_key 形式的集合）：
        name_selected   名称级保守选择命中（call_graph.select_tests_by_name）
        priority_hit    排序模型 / 调用图命中（scorer.prioritize 的 node_id）
        file_selected   文件级基线命中（call_graph.select_tests_file_level，含空匹配→全量兜底）
        changed_test_files  本次增改的测试【文件】路径（该文件下所有测试都必跑）
    """

    name_selected: frozenset[str] = frozenset()
    priority_hit: frozenset[str] = frozenset()
    file_selected: frozenset[str] = frozenset()
    changed_test_files: frozenset[str] = frozenset()


@dataclass
class PlanInputs:
    """assemble_plan 的输入：请求身份 + 收集到的真实 nodeid + 信号 + 回退原因 + 排序。

    order_hint 是 group_key -> 优先级序号（越小越靠前），来自 scorer.prioritize 的名次；
    没有命中的测试排在后面并按 collected 原序稳定。fallback_reasons 非空即全量回退。

    protocol_version 默认本实现产出的 1.1；宿主请求入口会把它改成【与请求声明的版本一致】，
    因为契约的跨文档绑定要求 request/plan/result 的 protocol_version 相同（1.0 请求在 1.1
    实现下产生的 1.0 计划仍完全合法——1.1 相对 1.0 只有放宽/新增）。

    risk_decisions 是逐条风险提示的采用/忽略原因。本版本（TF-0023 未交付）只会写
    decision="ignored"，如实标注"未采用风险增强"，绝不假装已经用了。
    """

    request_id: str
    plan_id: str
    target_identity: str
    collected: list[str]
    signals: SelectionSignals = field(default_factory=SelectionSignals)
    fallback_reasons: list[str] = field(default_factory=list)
    order_hint: dict[str, int] = field(default_factory=dict)
    rules_id: str = _DEFAULT_RULES_ID
    product_version: str = f"smart-test-sorter/{__version__}"
    protocol_version: str = _PROTOCOL_VERSION
    risk_decisions: list[dict] = field(default_factory=list)
    # 风险增强（TF-0023）只做加法：risk_selected 是采用的风险提示额外纳入的测试，
    # risk_priority 是 nodeid -> 排序键（越小越靠前），risk_labels 用于在 reasons 里留痕。
    risk_selected: frozenset[str] = frozenset()
    risk_priority: dict[str, tuple] = field(default_factory=dict)
    risk_labels: dict[str, str] = field(default_factory=dict)


def select_affected(collected: list[str], signals: SelectionSignals) -> set[str]:
    """四路信号取【并集】，返回选中的【真实 nodeid】集合。宁可多跑不可漏选。

    与 plugin.py 的 keep 判据逐条对齐：
      1. 名称级命中（安全网，召回最高）；
      2. 排序模型 / 调用图命中；
      3. 文件级基线命中（其"关键词非空但零命中→全量"兜底已在 file_selected 里体现）；
      4. 所属测试文件本次被增改（changed_test_files）。
    匹配按 group_key 归一，但返回的是 collected 里的原始参数化 nodeid。
    """
    keep: set[str] = set()
    for nid in collected:
        key = group_key(nid)
        file_path = key.split("::", 1)[0]
        if (
            key in signals.name_selected
            or key in signals.priority_hit
            or key in signals.file_selected
            or file_path in signals.changed_test_files
        ):
            keep.add(nid)
    return keep


def _ordered(
    selected: set[str],
    collected: list[str],
    order_hint: dict[str, int],
    risk_priority: dict[str, tuple] | None = None,
) -> list[str]:
    """把 selected 排成确定顺序：先按风险增强的排序键，再按 order_hint 名次，最后按 collected 原序。

    固定输入下稳定可重放（契约要求 order 是 selected 的一个确定排列）。风险键自身是
    (提示序号, -score, collected 序号)，所以"高风险的先跑、同级按分数、再同名次按原序"
    完全确定，没有时间/随机因素。
    """
    pos = {nid: i for i, nid in enumerate(collected)}
    big = len(collected)
    risk = risk_priority or {}

    def key(nid: str) -> tuple:
        base = (order_hint.get(group_key(nid), big), pos.get(nid, big))
        rank = risk.get(nid)
        if rank is None:
            return (1, 0, 0.0, 0, base)
        return (0, rank[0], rank[1], 0, base)

    return sorted(selected, key=key)


def assemble_plan(inputs: PlanInputs) -> dict:
    """把收集结果 + 信号 + 回退原因组装成一份 v1.1 test_plan dict。

    决策顺序（与安全契约一致）：
      1. 有回退原因(fallback_reasons) ⇒ selection_scope=full，selected=collected 全集；
      2. 否则按四路信号并集选出 selected；
      3. 选出的 selected 为空但确有 collected ⇒ 保守全量（补一条"选择为空"回退原因，
         避免空选被误当成已验证）；
      4. 正常 selected ⇒ selection_scope=selected。
    excluded = collected - selected；order 为 selected 的确定排列；reasons 逐项给理由。

    调用方须保证 collected 非空（收集不到全集应改走 build_refusal）；本函数不臆造空计划。
    """
    collected = list(inputs.collected)
    collected_set = set(collected)
    fallback = list(inputs.fallback_reasons)

    if fallback:
        selected = set(collected)
        scope = "full"
    else:
        selected = select_affected(collected, inputs.signals) & collected_set
        if not selected:
            # 有改动却一个测试都没选到：保守全量，不空选。此时已是全集，风险增强无事可做。
            fallback = ["选择结果为空：改动未匹配到任何测试，保守回退全量（不空选）"]
            selected = set(collected)
            scope = "full"
        else:
            # 风险增强只做【加法】（TF-0023）：把采用的风险提示解析到的测试并进来，
            # 绝不删除任何常规判据要保留的测试；提权交给 risk_priority 影响 order。
            selected = selected | (set(inputs.risk_selected) & collected_set)
            scope = "selected"

    excluded = collected_set - selected
    # A conservative full fallback is not an opt-in ordering experiment.
    order = collected if fallback else _ordered(selected, collected, inputs.order_hint, inputs.risk_priority)
    risk_decisions = [dict(decision) for decision in inputs.risk_decisions]
    rules_id = inputs.rules_id
    if fallback:
        rules_id = rules_id.removesuffix("+risk")
        for decision in risk_decisions:
            if decision.get("decision") == "adopted":
                decision.update(decision="ignored", reason="保守全量：保持 pytest 原生顺序，不采用风险增选或排序")
    reasons = _build_reasons(
        collected, selected, inputs.signals, scope, inputs.risk_labels
    )

    plan = {
        "protocol_version": inputs.protocol_version,
        "product_version": inputs.product_version,
        "request_id": inputs.request_id,
        "plan_id": inputs.plan_id,
        "target_identity": inputs.target_identity,
        "rules_id": rules_id,
        "selection_scope": scope,
        "collected": collected,
        "selected": order,  # selected 用有序形式，便于阅读；顺序权威在 order
        "excluded": sorted(excluded),
        "order": order,
        "reasons": reasons,
        "supported_run_modes": list(_RUN_MODES),
    }
    if fallback:
        plan["fallback"] = fallback
    if risk_decisions:
        plan["risk_decisions"] = risk_decisions
    return plan


def _build_reasons(
    collected: list[str],
    selected: set[str],
    signals: SelectionSignals,
    scope: str,
    risk_labels: dict[str, str] | None = None,
) -> dict[str, str]:
    """逐项选择/排除理由，key 为真实 nodeid。full 时统一标注全量回退。

    被风险提示提权的测试会多一个 `risk-adopted(<定位符>)` 说明——理由里必须看得见
    "为什么这个测试被排到前面"，否则风险增强就成了不可解释的黑箱。
    """
    reasons: dict[str, str] = {}
    labels = risk_labels or {}
    for nid in collected:
        if scope == "full":
            reasons[nid] = "full: 全量回退（见 fallback）"
            continue
        key = group_key(nid)
        file_path = key.split("::", 1)[0]
        if nid in selected:
            why = []
            if key in signals.name_selected:
                why.append("name-level")
            if key in signals.priority_hit:
                why.append("call-graph")
            if key in signals.file_selected:
                why.append("file-level")
            if file_path in signals.changed_test_files:
                why.append("changed-test-file")
            if nid in labels:
                why.append(f"risk-adopted({labels[nid]})")
            reasons[nid] = "selected: " + "+".join(why or ["affected"])
        else:
            reasons[nid] = "excluded: 未被任何选择判据命中"
    return reasons


def build_refusal(
    request_id: str,
    refusal_code: str,
    reason: str,
    *,
    target_identity: str | None = None,
    collected_count: int | None = None,
    collection_succeeded: bool = False,
    product_version: str | None = None,
) -> dict:
    """构造 v1.1 plan_refusal dict（无法生成合法计划时的带内回执）。

    安全不变量（与 contracts._semantic_refusal 一致）：只有目标可确认(target_identity
    非空) 且 收集到测试全集(collection_succeeded) 时才允许保守全量；否则如实报告不可全量。

    protocol_version 固定写本实现的 1.1：plan_refusal 是 1.1 新增对象，1.0 里没有它，
    因此回执只能以"生产者的协议版本"出现；而 test_plan 相反，会回显请求声明的版本，
    以满足跨文档绑定对 request/plan/result 版本一致的要求。两者都不做静默兼容。
    """
    confirmable = target_identity is not None
    full_available = confirmable and collection_succeeded
    doc = {
        "protocol_version": _PROTOCOL_VERSION,
        "product_version": product_version or f"smart-test-sorter/{__version__}",
        "request_id": request_id,
        "refusal_code": refusal_code,
        "reason": reason,
        "target_confirmable": confirmable,
        "conservative_full_available": full_available,
    }
    if confirmable:
        doc["target_identity"] = target_identity
    attempted: dict[str, object] = {"succeeded": collection_succeeded}
    if collected_count is not None:
        attempted["collected_count"] = collected_count
    doc["attempted_collection"] = attempted
    return doc


# ---- 与 git/仓库对接：把真实变更算成信号，产出 plan 或 refusal ----------------
#
# 上面的 select_affected / assemble_plan 是纯函数（不碰 git），本段把它们接到
# revision / safety / scorer / call_graph，供 CLI 与宿主入口现算。收集(collected)
# 由调用方给出（pytest 收集或宿主提供），因为"仓库里到底能收集到哪些 nodeid"要真跑
# pytest 才准；本层不假装收集。


def gather_signals(repo_path: str, target: "str | revision.ChangeSource", *,
                   xml_dir: str | None = None,
                   test_dir: str = "tests") -> tuple[SelectionSignals, list[str], dict[str, int], frozenset[str]]:
    """从真实仓库现算选择信号 + 全量回退原因 + 排序名次 + 文件级关键词。

    与 plugin.pytest_collection_modifyitems 的信号来源逐条对齐，避免两处口径漂移。
    返回 (signals, fallback_reasons, order_hint, file_keywords)。file_selected 需要
    collected 才能算"零命中→全量"兜底，故这里只把关键词单独返回，由 build_plan 拿到
    collected 后解析并填入 signals（不把可变状态塞进 frozen dataclass）。
    target 可为 commit-ish 或 revision.WORKTREE。
    """
    from smart_sorter.safety import changed_test_files, full_run_reasons

    fallback_reasons = full_run_reasons(repo_path, target)
    if fallback_reasons:
        return SelectionSignals(), fallback_reasons, {}, frozenset()

    from smart_sorter.call_graph import changed_file_keywords, select_tests_by_name
    from smart_sorter.scorer import prioritize

    name_selected = {group_key(n) for n in select_tests_by_name(repo_path, target)}
    ranked = prioritize(repo_path, target, xml_dir=xml_dir, test_dir=test_dir)
    order_hint = {group_key(nid): i for i, (nid, _score) in enumerate(ranked)}
    file_keywords = frozenset(changed_file_keywords(repo_path, target))
    changed_tests = {p for p in changed_test_files(repo_path, target)}

    signals = SelectionSignals(
        name_selected=frozenset(name_selected),
        priority_hit=frozenset(order_hint),
        file_selected=frozenset(),  # 待 build_plan 拿到 collected 后解析
        changed_test_files=frozenset(changed_tests),
    )
    return signals, fallback_reasons, order_hint, file_keywords


def _resolve_file_selected(collected: list[str], keywords: frozenset[str]) -> set[str]:
    """用 collected 解析文件级选择（含空匹配→全量兜底），返回 group_key 集合。"""
    from smart_sorter.call_graph import select_tests_file_level

    keys = {group_key(n) for n in collected}
    return select_tests_file_level(keys, set(keywords))


def file_level_fallback_reason(collected: list[str], keywords: frozenset[str]) -> str | None:
    """文件级基线【零命中兜底】是否触发；触发则返回一条 fallback 原因，否则 None。

    keywords 非空但 collected 里没有任何 nodeid 含关键词时，select_tests_file_level 的
    `selected or all` 会退化为【全量】。那是"改了源码却找不到同名测试、不敢剔除"的保守
    全量——必须如实标 selection_scope=full 并给出原因，不能伪装成 selected 让 VG 消费者
    误以为是精挑的子集（这正是 verify 抓到的 scope 标签问题）。

    keywords 为空（没有可派生关键词的源码改动）不算此类兜底：那时文件级返回空集，是否
    全量由其它判据决定，不在这里下结论。
    """
    if not keywords:
        return None
    keys = {group_key(n) for n in collected}
    matched = any(kw in k.lower() for k in keys for kw in keywords)
    if matched:
        return None
    kw_list = "、".join(sorted(keywords))
    return f"文件级基线零命中：改动源码（关键词 {kw_list}）未匹配到任何同名测试，保守回退全量"


def build_plan(repo_path: str, target: "str | revision.ChangeSource", collected: list[str], *,
               request_id: str, plan_id: str, xml_dir: str | None = None,
               test_dir: str = "tests", protocol_version: str = _PROTOCOL_VERSION,
               risk_decisions: list[dict] | None = None,
               rules_id: str = _DEFAULT_RULES_ID,
               risk_selected: frozenset[str] | set[str] = frozenset(),
               risk_priority: dict[str, tuple] | None = None,
               risk_labels: dict[str, str] | None = None,
               extra_fallback_reasons: list[str] | None = None) -> dict:
    """端到端：给定仓库 + 变更目标 + 已收集 nodeid，产出一份 v1.1 test_plan。

    collected 必须是【真跑 pytest 收集到的真实 nodeid】（保留参数化后缀）。收集为空
    应由调用方改走 build_refusal（本函数要求 collected 非空，否则抛 ValueError——不
    臆造空计划）。target_identity 取 revision 的目标指纹，报告期与分析期一致可核对。

    target 可以是 commit-ish 字符串、revision.WORKTREE，或一个【已解析的 ChangeSource】
    （TF-0027 候选模式：base/ours/theirs 三条 OID 用一个字符串表达不了）。repo_path 一律
    传"实际要分析/收集的目录"——候选模式即候选目录。

    extra_fallback_reasons 是**调用方**给出的、必须强制全量的原因（例如候选的 base 不是
    合并基点 ⇒ 改动面无法界定，见 revision.candidate_base_problem）。它**无条件**并入
    fallback_reasons：这类原因说的是"连变更集都不可信"，比"关键词没命中"更根本。
    """
    if not collected:
        raise ValueError("collected 为空：应改走 build_refusal 报告无法规划，不产出空计划")

    source = revision.resolve(repo_path, target)

    if extra_fallback_reasons:
        signals, fallback_reasons, order_hint, file_keywords = (
            SelectionSignals(), list(extra_fallback_reasons), {}, frozenset()
        )
    else:
        signals, fallback_reasons, order_hint, file_keywords = gather_signals(
            repo_path, target, xml_dir=xml_dir, test_dir=test_dir
        )
    # 现在有 collected 了，补上文件级选择（含零命中→全量兜底）。
    file_selected = _resolve_file_selected(collected, file_keywords)
    signals = SelectionSignals(
        name_selected=signals.name_selected,
        priority_hit=signals.priority_hit,
        file_selected=frozenset(file_selected),
        changed_test_files=signals.changed_test_files,
    )
    # 文件级零命中兜底要如实标 full，不能伪装成 selected（否则 VG 消费者会把"收窄不了、
    # 只好全跑"误当成"精挑的子集"）。把它并入 fallback_reasons，交给 assemble_plan 统一
    # 走 full 分支。仅当 full_run_reasons 没已经触发全量时才补（避免重复原因）。
    if not fallback_reasons:
        file_fallback = file_level_fallback_reason(collected, file_keywords)
        if file_fallback:
            fallback_reasons = [file_fallback]

    inputs = PlanInputs(
        request_id=request_id,
        plan_id=plan_id,
        target_identity=source.identity,
        collected=collected,
        signals=signals,
        fallback_reasons=fallback_reasons,
        order_hint=order_hint,
        rules_id=rules_id,
        protocol_version=protocol_version,
        risk_decisions=list(risk_decisions or []),
        risk_selected=frozenset(risk_selected),
        risk_priority=dict(risk_priority or {}),
        risk_labels=dict(risk_labels or {}),
    )
    return assemble_plan(inputs)
