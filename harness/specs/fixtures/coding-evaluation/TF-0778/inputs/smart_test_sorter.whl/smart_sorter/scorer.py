"""测试优先级排序引擎。

把前面几个模块的信号汇总成一个分数，对受影响的测试从高到低排序。评分是简单的
加权求和（不是机器学习）——每个因子的含义和权重都写在注释里，本科生能读懂。
"""

from __future__ import annotations

from smart_sorter.ast_diff import get_changed_functions
from smart_sorter.call_graph import find_test_callers, get_affected_tests
from smart_sorter.history import build_failure_history

# ---- 评分权重（硬编码）------------------------------------------------------
# 说明：本工具有两种排序模式，权重分两套（各自之和为 1.0）：
#
# 【一跳模式 use_graph=False】沿用 MVP 的三因子（无调用距离信号）：
_W_FAILURE = 0.6      # 失败率占大头：历史爱挂的测试最可能再抓到 bug
_W_SEVERITY = 0.3     # 变更类型次之：改动"性质"影响风险高低
_W_NAME = 0.1         # 名称重叠加成最小：弱信号，同分时把更相关的往前提
#
# 【调用图模式 use_graph=True】新增 proximity（调用距离）这一强信号后重新归一：
_G_FAILURE = 0.45     # 失败率仍最重要，但让位一部分给距离
_G_SEVERITY = 0.25
_G_NAME = 0.10
_G_PROXIMITY = 0.20   # 调用距离：测试离被改函数越近，越可能直接触发其 bug

# 无历史数据时的默认失败率：给一个较低的基线，避免新测试凭空排到最前。
_DEFAULT_FAILURE_RATE = 0.1

# 无调用距离信息（一跳模式，或图里没查到该测试）时 proximity 的中性取值。
_DEFAULT_PROXIMITY = 0.5

# 变更类型的"严重度"：
#   added(0.8)   —— 新增函数往往带来新行为/新分支，风险最高；
#   modified(0.5)—— 修改已有逻辑，中等风险；
#   deleted(0.3) —— 删除通常是清理，直接触发失败的概率相对低。
_SEVERITY = {"added": 0.8, "modified": 0.5, "deleted": 0.3}


def _proximity(distance: int | None) -> float:
    """把调用距离(跳数)映射成 [0,1] 的接近度：距离越小越接近 1。

    distance=1 -> 1.0；distance=2 -> 0.5；distance=3 -> 0.333……
    无距离信息(None)时返回中性值，不偏袒也不惩罚。
    """
    if distance is None or distance <= 0:
        return _DEFAULT_PROXIMITY
    return 1.0 / distance


def score_tests(
    affected_tests: list[str],
    failure_history: dict[str, float],
    change_types: list[str],
) -> list[tuple[str, float]]:
    """给每个受影响测试打分并按分数降序返回 [(test_name, score)]。

    评分公式：
        score = 0.6 * failure_rate
              + 0.3 * change_severity
              + 0.1 * name_match_bonus

    参数:
        affected_tests: 受影响的测试 node ID 列表。
        failure_history: {test_name: 失败率}，缺失的测试用默认值。
        change_types:   本次 commit 涉及的变更类型列表（如 ["modified","added"]），
                        用来推出一个整体的 change_severity。
    """
    # change_severity 取本次所有变更类型里最高的那个严重度——只要有一个高风险
    # 变更，整批受影响测试都应被相应抬高。没有类型信息时退化为 modified。
    if change_types:
        severity = max(_SEVERITY.get(ct, 0.5) for ct in change_types)
    else:
        severity = _SEVERITY["modified"]

    scored: list[tuple[str, float]] = []
    for test in affected_tests:
        failure_rate = failure_history.get(test, _DEFAULT_FAILURE_RATE)
        name_bonus = _name_match_bonus(test, change_types)

        score = (
            _W_FAILURE * failure_rate
            + _W_SEVERITY * severity
            + _W_NAME * name_bonus
        )
        scored.append((test, round(score, 4)))

    # 主排序键是分数降序；同分时按测试名升序，保证结果稳定可复现。
    scored.sort(key=lambda item: (-item[1], item[0]))
    return scored


def _name_match_bonus(test_name: str, changed_function_names: list[str]) -> float:
    """测试名与任一变更函数名有字符串重叠时给 1.0，否则 0.0。

    例如变更函数 "iter_text"，测试 "test_iter_text_with_chunk_size" 含有该子串，
    说明这个测试很可能就是针对该函数写的，值得额外加成。
    """
    lowered = test_name.lower()
    for fn in changed_function_names:
        # 取函数短名（去掉 Class. 前缀）再比对，避免类名噪声。
        short = fn.split(".")[-1].lower()
        if len(short) >= 3 and short in lowered:
            return 1.0
    return 0.0


def prioritize(
    repo_path: str,
    target: str,
    xml_dir: str | None = None,
    test_dir: str = "tests",
    use_graph: bool = True,
    max_hops: int = 4,
) -> list[tuple[str, float]]:
    """端到端入口：给定 repo + 变更目标，返回排好序的 [(test_name, score)]。

    参数:
        target:    历史 commit-ish，或 revision.WORKTREE（工作区未提交改动）。
        xml_dir:   可选历史 JUnit 目录，用于失败率加权；不给则全用默认失败率。
        use_graph: True(默认) 用过程间调用图 + 多跳可达 + 调用距离(proximity)；
                   False 退回 MVP 的一跳名称匹配（无距离信号）。两种模式权重不同，
                   见模块顶部常量。use_graph 也是消融实验里 Ours-graph vs Ours-1hop
                   的开关。
        max_hops:  调用图模式下反向 BFS 的最大跳数。
    """
    # 收集本次变更：函数短名用于 name_bonus，变更类型用于 severity。
    changed = get_changed_functions(repo_path, target)
    changed_fn_names = [c["function"] for c in changed]
    change_types = [c["change_type"] for c in changed]

    failure_history = build_failure_history(xml_dir) if xml_dir else {}

    if use_graph:
        # 调用图模式：把【一跳精确命中】与【调用图多跳可达】并集起来，兼得精度与召回。
        # 关键：图对运算符分派的 dunder（==/repr()/< 触发 __eq__/__repr__/__lt__）是盲的，
        # 若只用图可达，改这类函数会一个测试都选不到、反而不如一跳。故取并集：
        #   - 一跳命中的测试视为"直接调用"，距离记 1（最相关）；
        #   - 图可达的测试用其 BFS 最短距离；
        #   - 两者都覆盖时取更近的距离。
        from smart_sorter.graph import get_affected_tests_graph

        graph_dist = get_affected_tests_graph(
            repo_path, target, test_dir=test_dir, max_hops=max_hops
        )
        onehop = get_affected_tests(repo_path, target, test_dir=test_dir)

        distances: dict[str, int] = dict(graph_dist)
        for t in onehop:
            distances[t] = min(distances.get(t, 99), 1)  # 一跳=直接调用，距离 1

        affected_tests = sorted(distances.keys())
        return _score_with_names(
            affected_tests, failure_history, change_types, changed_fn_names,
            distances=distances, use_graph=True,
        )

    # 一跳模式：沿用 MVP 路径，无距离信号。
    affected_tests = get_affected_tests(repo_path, target, test_dir=test_dir)
    return _score_with_names(
        affected_tests, failure_history, change_types, changed_fn_names,
        distances=None, use_graph=False,
    )


def _score_with_names(
    affected_tests: list[str],
    failure_history: dict[str, float],
    change_types: list[str],
    changed_fn_names: list[str],
    distances: dict[str, int] | None = None,
    use_graph: bool = False,
) -> list[tuple[str, float]]:
    """score_tests 的内部变体：name_match_bonus 用真正的函数名列表来判断，
    并在 use_graph 时额外计入 proximity（调用距离）分项。

    对外仍暴露简洁的 score_tests(签名与需求文档一致)；prioritize 走这个内部版本。
    """
    if change_types:
        severity = max(_SEVERITY.get(ct, 0.5) for ct in change_types)
    else:
        severity = _SEVERITY["modified"]

    distances = distances or {}

    scored: list[tuple[str, float]] = []
    for test in affected_tests:
        failure_rate = failure_history.get(test, _DEFAULT_FAILURE_RATE)
        name_bonus = _name_match_bonus(test, changed_fn_names)

        if use_graph:
            prox = _proximity(distances.get(test))
            score = (
                _G_FAILURE * failure_rate
                + _G_SEVERITY * severity
                + _G_NAME * name_bonus
                + _G_PROXIMITY * prox
            )
        else:
            score = (
                _W_FAILURE * failure_rate
                + _W_SEVERITY * severity
                + _W_NAME * name_bonus
            )
        scored.append((test, round(score, 4)))

    scored.sort(key=lambda item: (-item[1], item[0]))
    return scored
