"""只读 Web 仪表盘：可视化某次 commit 的变更影响、测试排序与调用子图。

设计原则（与 CLI/插件一致）：
  - 只读，绝不修改目标仓库；
  - Flask 是可选依赖（pyproject 的 [web] extra），核心工具不依赖它；
  - 调用图在前端用 vis-network（CDN）渲染，后端只提供 JSON，无额外 Python 依赖。

启动:
    python -m smart_sorter.webapp --repo D:/verseci/experiment-httpx
然后浏览器打开 http://127.0.0.1:5000
"""

from __future__ import annotations

import argparse
from pathlib import Path

import git
from flask import Flask, jsonify, render_template, request

from smart_sorter.ast_diff import get_changed_files, get_changed_functions
from smart_sorter.graph import build_call_graph, get_affected_tests_graph
from smart_sorter.scorer import prioritize

# 目标仓库路径在启动时注入到 app.config，视图函数从这里取。
_CONFIG_REPO = "REPO_PATH"


def create_app(repo_path: str, xml_dir: str | None = None) -> Flask:
    """构造并配置 Flask app（工厂模式，便于测试注入不同 repo）。"""
    app = Flask(__name__)
    app.config[_CONFIG_REPO] = str(Path(repo_path).resolve())
    app.config["XML_DIR"] = xml_dir

    @app.route("/")
    def index():
        """首页：列出最近改了 .py 的 commit，供选择分析。"""
        commits = _recent_py_commits(app.config[_CONFIG_REPO], limit=20)
        return render_template("index.html", commits=commits,
                               repo=app.config[_CONFIG_REPO])

    @app.route("/analyze")
    def analyze():
        """分析页：某 commit 的变更函数 + 受影响测试(带距离) + 优先级排序。"""
        commit = request.args.get("commit", "").strip()
        if not commit:
            return render_template("analyze.html", error="未提供 commit")
        repo = app.config[_CONFIG_REPO]
        try:
            changed = get_changed_functions(repo, commit)
            distances = get_affected_tests_graph(repo, commit)
            ranked = prioritize(repo, commit, xml_dir=app.config["XML_DIR"],
                                use_graph=True)
        except (git.exc.BadName, ValueError):
            return render_template("analyze.html", error=f"找不到 commit: {commit}")

        # 把距离并进排序结果，供表格显示"调用距离"列。
        rows = [
            {"rank": i, "test": name, "score": round(score, 3),
             "distance": distances.get(name, "-")}
            for i, (name, score) in enumerate(ranked, start=1)
        ]
        # 建议的 pytest 命令：取前 20 个高优先级测试，可直接复制运行。
        suggested = " ".join(name for name, _ in ranked[:20])
        return render_template(
            "analyze.html", commit=commit, changed=changed, rows=rows,
            changed_count=len(changed), affected_count=len(ranked),
            suggested=suggested, error=None,
        )

    @app.route("/api/graph")
    def api_graph():
        """返回该 commit 的调用子图 JSON（供 vis-network 渲染）。

        只返回"能到达被改函数"的可达子图，避免把 1000+ 节点全塞给前端。
        节点标注类型：changed(被改源函数) / source(中间源函数) / test(测试)。
        """
        commit = request.args.get("commit", "").strip()
        repo = app.config[_CONFIG_REPO]
        try:
            payload = _build_graph_payload(repo, commit)
        except (git.exc.BadName, ValueError):
            return jsonify({"error": f"bad commit: {commit}"}), 404
        return jsonify(payload)

    @app.route("/api/benchmark")
    def api_benchmark():
        """读取 experiments/results/benchmark.csv 返回表格 JSON（若存在）。"""
        csv_path = Path(__file__).resolve().parent.parent.parent / \
            "experiments" / "results" / "benchmark.csv"
        if not csv_path.exists():
            return jsonify({"rows": [], "note": "尚未运行 run_benchmark.py"})
        import csv as _csv
        with csv_path.open(encoding="utf-8") as f:
            rows = list(_csv.DictReader(f))
        return jsonify({"rows": rows})

    return app


def _recent_py_commits(repo_path: str, limit: int = 20) -> list[dict]:
    """返回最近若干个"修改了 .py 文件"的 commit 摘要，供首页下拉。"""
    repo = git.Repo(repo_path)
    out: list[dict] = []
    for commit in repo.iter_commits("HEAD", max_count=200):
        if not commit.parents:
            continue
        if get_changed_files(repo_path, commit.hexsha):
            summary = commit.message.splitlines()[0] if commit.message else ""
            out.append({"hash": commit.hexsha[:7], "summary": summary[:70]})
        if len(out) >= limit:
            break
    return out


def _build_graph_payload(repo_path: str, commit_hash: str) -> dict:
    """构造调用子图的 {nodes, edges} JSON。

    做法：从被改函数出发做反向 BFS 并记录 BFS 树的前驱（predecessor，即更靠近被改
    函数的那个调用者的被调用目标）；然后取距离最近的若干测试，沿前驱一路回溯到被改
    函数，把路径上的所有节点与边都收进子图。这样保证子图【连通且带边】，而不是一堆
    孤立的测试节点。
    """
    from collections import deque

    graph = build_call_graph(repo_path)

    changed = get_changed_functions(repo_path, commit_hash)
    changed_qualified = set()
    for c in changed:
        if Path(c["file"]).name.startswith("test_"):
            continue
        module = _rel_to_module(c["file"])
        changed_qualified.add(f"{module}.{c['function']}")

    starts = [q for q in changed_qualified
              if q in graph.node_file or q in graph.reverse_edges]

    # 反向 BFS：记录每个节点最短距离，以及它在 BFS 树里指向的"下游被调用者"（更靠近
    # 被改函数的一侧），用于之后回溯出完整调用路径。
    dist: dict[str, int] = {s: 0 for s in starts}
    downstream: dict[str, str] = {}   # caller -> 它调用的、更靠近 changed 的 callee
    tests_found: list[str] = []
    q: deque[str] = deque(starts)
    while q:
        node = q.popleft()
        if dist[node] >= 6:
            continue
        for caller in graph.reverse_edges.get(node, ()):
            if caller in dist:
                continue
            dist[caller] = dist[node] + 1
            downstream[caller] = node
            q.append(caller)
            if graph.is_test.get(caller):
                tests_found.append(caller)

    # 取距离最近的前 40 个测试，回溯路径收集节点与边。
    tests_found.sort(key=lambda t: dist[t])
    selected = tests_found[:40]

    keep: set[str] = set(starts)
    edges: set[tuple[str, str]] = set()
    for test in selected:
        node = test
        keep.add(node)
        # 沿 downstream 回溯：node -> downstream[node] 正是一条真实调用边。
        while node in downstream:
            nxt = downstream[node]
            edges.add((node, nxt))
            keep.add(nxt)
            node = nxt

    nodes = [{"id": n, "label": _short_label(n),
              "type": _node_type(n, graph, changed_qualified)} for n in keep]
    edge_list = [{"from": a, "to": b} for a, b in edges]
    return {"nodes": nodes, "edges": edge_list,
            "distances": {t: dist[t] for t in selected}}


def _node_type(node: str, graph, changed_qualified: set[str]) -> str:
    """给前端上色用的节点类型标签。"""
    if node in changed_qualified:
        return "changed"
    if graph.is_test.get(node) or "::" in node:
        return "test"
    return "source"


def _short_label(node: str) -> str:
    """节点显示用短标签：测试取 ::后的函数名，源函数取最后两段。"""
    if "::" in node:
        return node.split("::")[-1]
    parts = node.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else node


def _rel_to_module(rel_path: str) -> str:
    """httpx/_client.py -> httpx._client。"""
    p = Path(rel_path).with_suffix("")
    return ".".join(seg for seg in p.parts if seg != "__init__")


def main(argv: list[str] | None = None) -> int:
    """命令行入口：起本地 Flask 服务。"""
    parser = argparse.ArgumentParser(
        prog="smart_sorter.webapp",
        description="Smart Test Sorter 只读 Web 仪表盘",
    )
    parser.add_argument("--repo", required=True, help="目标 git 仓库路径")
    parser.add_argument("--xml-dir", default=None, help="历史 JUnit XML 目录（可选）")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args(argv)

    app = create_app(args.repo, xml_dir=args.xml_dir)
    app.run(host=args.host, port=args.port, debug=args.debug)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
