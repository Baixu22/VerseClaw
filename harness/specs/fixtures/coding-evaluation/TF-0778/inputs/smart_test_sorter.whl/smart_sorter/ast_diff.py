"""AST 级别的 Git Diff 分析。

给定一个 git 仓库和某个【变更目标】（历史 commit，或 WORKTREE 工作区未提交改动），
找出这次改动到底修改了哪些 Python 函数（精确到函数/方法，而不是文件），供后续的
调用链分析和测试排序使用。

变更目标的解析统一交给 revision.ChangeSource，本模块只关心"函数级 diff"这层语义。
只依赖 GitPython 和标准库 ast。
"""

from __future__ import annotations

import ast

from smart_sorter import revision
from smart_sorter.revision import WORKTREE  # noqa: F401  向后兼容的再导出


def get_changed_files(repo_path: str, target: str) -> list[str]:
    """返回变更目标相对基线被【修改】的 .py 文件相对路径列表。

    只关注修改（M）的文件，忽略新增（A）和删除（D）的文件——因为一个全新
    或被删掉的文件没有"函数级"的对比意义，我们关心的是已有代码的变化。

    target 可以是 commit-ish（短哈希/HEAD/tag）或 revision.WORKTREE（工作区未提交改动）。
    """
    source = revision.resolve(repo_path, target)
    if not source.has_baseline:
        # 没有可对比的旧版本（首个提交/空仓库），没有"修改"可言。
        return []
    changed = [
        e.path
        for e in source.diff_entries()
        if e.change_type == "M" and e.path.endswith(".py")
    ]
    return sorted(changed)


def extract_functions(source_code: str) -> dict[str, tuple[int, int]]:
    """解析源码，返回 {函数名: (起始行号, 结束行号)}。

    只提取两类函数：
      1. 顶层函数              -> "func_name"
      2. 顶层类里的方法        -> "ClassName.method_name"
    嵌套在函数内部的函数会被忽略，保持结果简单可读。
    """
    tree = ast.parse(source_code)
    functions: dict[str, tuple[int, int]] = {}

    for node in tree.body:
        # 顶层函数（含 async 函数）
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions[node.name] = (node.lineno, _end_line(node))
        # 顶层类：再往里看一层，收集它直接定义的方法
        elif isinstance(node, ast.ClassDef):
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    qualified = f"{node.name}.{item.name}"
                    functions[qualified] = (item.lineno, _end_line(item))

    return functions


def _end_line(node: ast.AST) -> int:
    """取节点的结束行号；Python 3.8+ 的 ast 节点都带 end_lineno。"""
    return getattr(node, "end_lineno", None) or node.lineno


def get_changed_functions(repo_path: str, target: str) -> list[dict]:
    """组合上面两个函数，输出这次变更里函数级别的变更列表。

    返回格式：
        [{"file": "httpx/_client.py",
          "function": "Client.request",
          "change_type": "modified" | "added" | "deleted"}, ...]

    判定方式（对每个被修改的 .py 文件）：
      - 新版本里有、旧版本里没有的函数  -> added
      - 旧版本里有、新版本里没有的函数  -> deleted
      - 两个版本都有、但函数体源码不同  -> modified

    这里比较"函数体源码文本"而不是单纯的行号，是为了避免：文件上方插入几行
    导致下方所有函数行号整体平移、从而被误判为全部修改。文本对比更准。

    target 可以是 commit-ish 或 revision.WORKTREE；新旧内容由 ChangeSource 提供
    （worktree 模式下"新内容"来自工作区磁盘，与调用图口径一致）。
    """
    source = revision.resolve(repo_path, target)
    if not source.has_baseline:
        return []

    results: list[dict] = []
    for rel_path in get_changed_files(repo_path, target):
        old_src = source.read_old(rel_path)
        new_src = source.read_new(rel_path)

        # 源码语法错误（极少见）时跳过该文件，不让整体分析崩掉。
        try:
            old_funcs = extract_functions(old_src) if old_src else {}
            new_funcs = extract_functions(new_src) if new_src else {}
        except SyntaxError:
            continue

        old_lines = old_src.splitlines()
        new_lines = new_src.splitlines()

        for name, span in new_funcs.items():
            if name not in old_funcs:
                results.append(_entry(rel_path, name, "added"))
            elif _func_text(new_lines, span) != _func_text(old_lines, old_funcs[name]):
                results.append(_entry(rel_path, name, "modified"))

        for name in old_funcs:
            if name not in new_funcs:
                results.append(_entry(rel_path, name, "deleted"))

    return results


def _entry(file: str, function: str, change_type: str) -> dict:
    """构造一条统一格式的变更记录。"""
    return {"file": file, "function": function, "change_type": change_type}


def _func_text(lines: list[str], span: tuple[int, int]) -> str:
    """按 (起始行, 结束行) 从源码行里截出这个函数的文本（行号从 1 开始）。"""
    start, end = span
    return "\n".join(lines[start - 1:end])
