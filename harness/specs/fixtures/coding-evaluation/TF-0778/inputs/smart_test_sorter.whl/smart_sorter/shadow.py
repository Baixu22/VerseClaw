"""影子验证入口（TF-0013）：出计划 → 跑选中集 → **同一目标版本跑全量对拍** → 范围明确的报告。

本地和 CI 用的是同一条命令：

    <解释器>/python -m smart_sorter.shadow --repo <目标仓库> [--target WORKTREE|<commit>] \
        [--test-dir tests] [--mode shadow|full] [--out report.json] [--timeout SEC] [--xml-dir DIR]

它也能直接消费宿主的候选请求（`VG:TF-0170` 在 `from-vg/handoffs/0005` 里要的形状）——
目标身份与**候选目录**都从请求里取，计划仍走 `plan_request` 的同一条链路：

    <解释器>/python -m smart_sorter.shadow --request <candidate_request.json> \
        [--test-dir tests] [--mode shadow|full] [--out report.json]

候选模式下报告额外保证：**两份 `execution_result` 的 `target_identity` 都等于
`plan.target_identity`**（即 `candidate@<candidate_tree_oid[:7] 小写>`）。请求所声明的目标确认不了、
或候选内容与声明的 tree 已经不一致 ⇒ 走 refusal 回执（退出码 3），绝不猜一个目录照跑；
候选在两次运行之间被动过（`validity != valid`）⇒ 判 `not-comparable`，不拼结论。

## 它回答什么问题

"这次选择到底漏没漏？"——只在**同一个目标版本**上，把「按计划跑」和「全量跑」的结果放在一起比：

- 全量里失败、而选中集**根本没跑**的测试 = **漏选**（missed_failures）；
- 选中集跑了**且失败** = 选择抓到了（caught_failures；只"跑到"不算——见下）；
- 两次运行**互相矛盾**的测试（一个失败、另一个通过）分别记在
  `selected_failed_full_passed` 与 `full_failed_selected_passed`，合并成 `contradictory_runs`：
  **不改判结论**，但它们是"顺序依赖 / 时过时挂"的证据，不列出来就会被 `no-missed-failures` 掩盖；
- 两次运行的 target_identity 必须一致、都等于**计划声明的目标**（candidate 模式下即候选内容身份）、
  各自有效，且全量那次真的跑完，否则**不可比**（verdict=not-comparable）：报告会**清空**
  `missed_failures` / `caught_failures` 这些"漏没漏"的字段（宁可不给结论，也不给不能用的结论），
  只留范围与失败计数等事实；

## 不稳定测试不许混进"回归结论"（TF-0014）

"全量里失败"**不等于**"选择漏了一次回归"：如果那条测试本身**时过时挂**（或者它那次失败
其实是环境/夹具/收集错误、是被取消/超时），那它既不能算"漏选抓到了"，也不能算"没漏"。
这时入口给出 `verdict=missed-failures-indeterminate`（退出码 3，**判不了**）而不是
`missed-failures`，并把这些失败逐条列进 `comparison.missed_failures_indeterminate`。

降级需要**证据**，不会凭空发生，来源有两个（都要显式给）：

```bash
--stability <stability-report.json>   # python -m smart_sorter.stability 产出的重复运行证据
--history-xml-dir <junit-xml 目录>     # 历史 JUnit：失败率严格在 (0,1) 之间 ⇒ 历史不一致
```

两条规矩写死：

1. **没有证据就不降级**——不在证据里的失败照旧算确定的漏选（宁可多报，不替失败找借口）。
2. **降级只降"确定"，不升"通过"**——降级后的结论是"判不了"（退出码 3），绝不是
   `no-missed-failures`；也绝不会把失败改写成通过、或据此剔除/跳过任何测试。

这正是 TF-0014「记录不稳定测试与运行错误，避免混入回归结论」在影子验证上的落地。

这正是 TF-0012 「影子模式保存计划与同一目标版本上的全量结果，按相同版本核对漏选」的入口，
也是 TF-0013 三条验收（干净安装入口 / 报告绑定目标·计划·实跑·未跑 / 全量对拍与按需全量）的落地。

## 两条运行模式

| 模式 | 行为 |
| --- | --- |
| `--mode shadow`（默认） | 先按计划跑选中集，再在**同一目标**上跑全量，产出对拍报告 |
| `--mode full` | 只跑全量（按需全量模式，用于周期性完整检查与"关掉选择"的对照） |

**两次运行的状态是分开记的**：报告里各自是一份完整的 `execution_result`，
周期性全量发现问题**不会**倒算成"先前那次选择是对的"——每次运行的有效性/完成度各自成立。

## 报告不是新的对外协议

`smart-test-sorter/shadow-report/v1` 是**本产品自己的验证产物**，不进 VG—STS 契约：
后者只有 request/plan/result/refusal 四个对象，权威仍在 `contracts/vg-sts/v1/`。
报告里内嵌的两份 `execution_result` 仍是契约对象（由 run_plan 的同一份实现产出）。

## 退出码

| 退出码 | 含义 |
| --- | --- |
| `0` | 报告已产出：shadow 模式下**无漏选**；full 模式下全量跑完且有效 |
| `1` | 报告已产出：**抓到漏选**（全量失败里有选中集没跑、且**没有**不稳定证据的测试） |
| `3` | 报告已产出但**判不了**：不可比（结果失效/不完整/两次运行目标不一致）、
       漏选只剩不稳定证据（missed-failures-indeterminate）或无法规划 |
| `2` | 用法或输入错误 |

## 诚实边界

- shadow 模式要跑**两遍** pytest（选中集 + 全量），耗时约为全量的 1.x 倍；这是对拍的代价。
- `--timeout` 与 run_plan 同源：协作式（在测试之间检查），不打断单个超长测试。
- 漏选**如实记录**：本工具的用途正是把漏选暴露出来，而不是证明选择不会漏。
- 不稳定证据同样**只降不升**：`missed-failures-indeterminate` 不会被当成"没有漏选"。
- candidate 模式下，候选目录里**未提交**的改动不会改变声明的 tree（目标确认只比 HEAD tree）：
  能看见它的是报告里的 `analysis_content_digest`（请求带了 `identities.worktree_content_digest`
  时消费方可以直接比对）；运行**期间**被改动则由 `validity=invalid` 兜住并判 `not-comparable`。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from smart_sorter import (__version__, contract_trees, contracts, plan_request,
                        revision, run_plan, stability)

_EXIT_OK = 0
_EXIT_MISSED = 1
_EXIT_USAGE = 2
_EXIT_INCOMPARABLE = 3

REPORT_SCHEMA = "smart-test-sorter/shadow-report/v1"


def _build_request(repo: str, target: str, request_id: str) -> dict:
    """由「仓库 + 目标」合成一份最小但合法的 workspace/commit 请求。

    实现在 `plan_request.build_target_request`（stability 入口共用同一份），这里只是
    保留本模块的旧名字，避免外部引用被无声改掉。
    """
    return plan_request.build_target_request(repo, target, request_id=request_id)


def load_flakiness(
    stability_reports: list[str] | None, history_dir: str | None, log=lambda message: None
) -> dict:
    """汇总"哪些测试的失败不能当确定回归证据"（TF-0014）——**尚未**按目标版本过滤。

    只有**显式给**的证据（稳定性报告 / 历史 JUnit）才进这个集合：没有证据的失败照旧算
    确定的漏选。稳定性报告里"什么都没观测到"的判决（not-run/under-observed/cancelled…）
    不算证据（见 `stability.load_evidence`）。历史 JUnit 只能分清 pass/fail，且跨版本失败
    可能来自真实修复，所以它同样只用于降级，永不用于把失败改判为通过。

    目标版本的过滤在 `bind_evidence` 里做（那里才知道本次的 `target_identity`）。
    """
    by_source: list[dict] = []
    sources: list[str] = []
    if stability_reports:
        merged = stability.load_evidence(list(stability_reports))
        by_source = list(merged["by_source"])
        sources.extend(merged["sources"])
        log(
            f"稳定性证据：{sum(len(e['not_definite']) for e in by_source)} 条"
            f"（来自 {len(by_source)} 份报告），待按目标版本核对"
        )
    history_not_definite: dict[str, str] = {}
    if history_dir:
        history_not_definite = stability.flaky_from_history(history_dir)
        sources.append(f"junit-history:{history_dir}")
        log(f"历史 JUnit：{len(history_not_definite)} 条测试历史不一致（失败率在 0 与 1 之间）")
    return {
        "by_source": by_source,
        "sources": sources,
        "history_not_definite": history_not_definite,
        "history_dir": history_dir,
    }


def bind_evidence(evidence: dict, target_identity: str, log=lambda message: None) -> dict:
    """只接受**目标版本与本次一致**的稳定性证据，其余一律拒绝并逐条记下理由。

    不这么做的后果很实际：工作区身份是 `worktree@<HEAD>+dirty:N`，上一次会话留下的报告
    身份不同，却能把这一次的失败降级成"判不了"——那就等于让**别的版本**的观测给当前的
    失败开脱（TF-0014 的验收第 3 条明确不许）。历史 JUnit 不带目标版本、本来就是跨版本
    的历史，所以单列成 `unbound_history` 如实标注（仍只用于降级）。
    """
    accepted: dict[str, str] = {}
    rejected: dict[str, str] = {}
    for entry in evidence.get("by_source") or []:
        path = entry.get("path", "?")
        source_target = entry.get("target_identity")
        if not source_target:
            rejected[path] = "证据没有 target_identity，无法核对它属于哪个目标版本"
        elif source_target != target_identity:
            rejected[path] = f"证据的目标版本 {source_target} ≠ 本次目标 {target_identity}"
        else:
            accepted.update(entry.get("not_definite") or {})
    for path, reason in rejected.items():
        log(f"拒绝该稳定性证据：{path} —— {reason}")
    unbound = dict(evidence.get("history_not_definite") or {})
    accepted.update(unbound)
    return {
        "not_definite": accepted,
        "sources": list(evidence.get("sources") or []),
        "rejected_sources": rejected,
        "unbound_history": unbound,
        "history_dir": evidence.get("history_dir"),
    }


def _bad_tests(result: dict) -> set[str]:
    """一次运行里 outcome 为 failed/error 的 nodeid 集合。"""
    return {
        node_id
        for node_id, outcome in (result.get("outcomes") or {}).items()
        if isinstance(outcome, dict) and outcome.get("outcome") in ("failed", "error")
    }


def _rules_id_of(plan_doc: dict) -> str:
    """从计划里取规则身份，**1.1 与 2.0 各按自己的形状**。

    2.0 把 `rules_id` 移进 `policy_identity`（并加了 `policy_version`）——见 v2 的 R8。
    刻意不写成 `plan_doc.get("rules_id") or plan_doc["policy_identity"]["rules_id"]`：
    那样"字段拼错/缺失"会**静默**取到另一个字段，正是"报告里看不出是哪个口径"的来源。
    """
    if plan_doc.get("protocol_version") == "1.1":
        return plan_doc["rules_id"]
    policy = plan_doc.get("policy_identity") or {}
    return policy.get("rules_id", "")


def compare(plan_doc: dict, selected: dict | None, full: dict, *,
            flakiness: dict | None = None) -> dict:
    """把「按计划跑」与「全量跑」放在一起对拍。纯函数，便于单测。

    `flakiness` 是可选的"不能当确定回归证据"的集合（TF-0014，来自 stability 报告或历史
    JUnit）。缺省为空 ⇒ 行为与引入不稳定证据之前**完全一致**：所有失败都算确定的漏选。
    """
    not_definite: dict[str, str] = dict((flakiness or {}).get("not_definite") or {})
    full_bad = _bad_tests(full)
    full_executed = list(full.get("executed") or [])
    collected = list(plan_doc.get("collected") or [])
    selected_plan = list(plan_doc.get("selected") or [])

    # 可比性：两次运行必须指向同一目标，且都有效、全量那次真的跑完。
    reasons: list[str] = []
    plan_target = plan_doc.get("target_identity")
    if selected is not None and selected.get("target_identity") != full.get("target_identity"):
        reasons.append(
            "两次运行的 target_identity 不一致："
            f"{selected.get('target_identity')} vs {full.get('target_identity')}"
        )
    for label, doc in (("选中集", selected), ("全量", full)):
        if doc is None:
            continue
        # 两份事实都必须锚在**计划声明的目标**上：candidate 模式下这就是候选内容身份，
        # 少了这一条，"两次运行都在同一个候选上"就只是口头承诺（VG 的 0005 第 2 条）。
        if plan_target and doc.get("target_identity") != plan_target:
            reasons.append(
                f"{label}运行的目标身份不指向计划目标："
                f"{doc.get('target_identity')} ≠ plan.target_identity={plan_target}"
            )
        if doc.get("validity") != "valid":
            reasons.append(f"{label}运行 validity={doc.get('validity')}：{doc.get('invalid_reason')}")
        # 「有效」还不够：**必须跑完**才算一份可对拍的事实——两条臂同口径。
        # 旧实现只查全量臂，于是选中臂零执行/没跑完时，"全量没有失败"照样被读成
        # "没漏选"；可那只是**没测**（审计用契约合法的输入构造过这一幕）。
        # 判 not-comparable 之后，trial 会把这条样本记成 undecidable，不拿它凑启用门槛。
        if doc.get("completeness") != "complete":
            reasons.append(
                f"{label}运行 completeness={doc.get('completeness')}：{doc.get('incomplete_reason')}"
            )

    comparison: dict = {
        "comparable": not reasons,
        "incomparable_reasons": reasons,
        "plan_target_identity": plan_target,
        "runs_match_plan_target": not any("不指向计划目标" in r for r in reasons),
        "collected_count": len(collected),
        "selected_count": len(selected_plan),
        "deselected": sorted(set(collected) - set(selected_plan)),
        "full_failed_or_error": sorted(full_bad),
        "full_executed_count": len(full_executed),
    }
    if selected is not None:
        selected_executed = set(selected.get("executed") or [])
        selected_bad = set(_bad_tests(selected))
        # 漏选 = 全量里失败、而且选中集连跑都没跑到的测试。
        missed = sorted(full_bad - selected_executed)
        # "抓到" = 选中集**跑了且失败**（与模块 docstring 的口径一致）。
        # 曾用的是 `full_bad & selected_executed`（只要求"跑到"），会把"全量失败、选中集却通过"
        # 的测试也计成抓到；那其实是顺序依赖/不稳定的信号，不该算捕获。真实样本上就撞到过
        # （glimpser 候选：全量 39 条失败里有 2 条在选中集通过，`caught_failures` 因此虚高到 39）。
        caught = sorted(full_bad & selected_bad)
        # 反向矛盾（全量失败、选中集跑了却通过）：**不**改判结论，但必须列出来——它说明结果
        # 与执行顺序/状态有关。此前只报了反方向的 `selected_failed_full_passed`。
        full_failed_selected_passed = sorted((full_bad & selected_executed) - selected_bad)
        # 有证据说明"时过时挂 / 是运行错误"的那些：**不能**当确定的漏选证据（TF-0014）。
        missed_indeterminate = [n for n in missed if n in not_definite]
        comparison.update({
            "selected_executed_count": len(selected_executed),
            "selected_failed_or_error": sorted(selected_bad),
            "missed_failures": [n for n in missed if n not in not_definite],
            "missed_failures_indeterminate": missed_indeterminate,
            "caught_failures": caught,
            "caught_failures_indeterminate": [n for n in caught if n in not_definite],
            "not_definite_evidence": {
                n: not_definite[n] for n in missed + caught if n in not_definite
            },
            # 工具自己看到的自相矛盾（两个方向都列，合起来说明"跑一次一个结果"）：
            # ① 按计划跑失败、全量跑却通过；② 全量失败、选中集跑了却通过。**不**改判结论，
            # 但不列出来，这种现实就会被 no-missed-failures 掩盖。
            "selected_failed_full_passed": sorted(selected_bad - full_bad),
            "full_failed_selected_passed": full_failed_selected_passed,
            "contradictory_runs": sorted((selected_bad - full_bad) | set(full_failed_selected_passed)),
            # 选择省下的测试数；计划本身就是全量回退时省不下任何东西（scope=full）。
            "selection_saved_tests": (
                0 if plan_doc.get("selection_scope") == "full"
                else max(0, len(collected) - len(selected_plan))
            ),
        })
        if not comparison["comparable"]:
            # 不可比 ⇒ **不给出**"漏没漏"的结论：两份事实没锚在同一个目标版本上，
            # 列出来只会被断章取义（宁可空着，也不给一个不能用的结论）。
            for key in ("missed_failures", "missed_failures_indeterminate", "caught_failures",
                        "caught_failures_indeterminate", "selected_failed_full_passed",
                        "full_failed_selected_passed", "contradictory_runs"):
                comparison[key] = []
            comparison["failure_conclusions_withheld"] = (
                "not-comparable：两次运行没有锚在同一个目标版本上，"
                "因此不给出漏选/捕获结论（上述字段已清空）"
            )

    if not comparison["comparable"]:
        comparison["verdict"] = "not-comparable"
    elif selected is None:
        comparison["verdict"] = "full-only"
    elif comparison["missed_failures"]:
        comparison["verdict"] = "missed-failures"
    elif comparison.get("missed_failures_indeterminate"):
        # 只剩下不稳定/运行错误造成的失败 ⇒ 既不能说漏了，也不能说没漏：判不了。
        comparison["verdict"] = "missed-failures-indeterminate"
    else:
        comparison["verdict"] = "no-missed-failures"
    return comparison


def _refusal_error(doc: dict) -> dict:
    """无法规划 ⇒ 交给 CLI 按"带内回执"处理（退出码 3，与 plan_request 的语义一致）。"""
    return {
        "ok": False,
        "error_kind": doc.get("refusal_code", "input-error"),
        "reason": doc.get("reason", "无法生成计划"),
        "refusal": doc,
    }


def run_shadow(
    repo: str,
    *,
    target: str = revision.WORKTREE,
    test_dir: str = "tests",
    mode: str = "shadow",
    timeout_s: int | None = None,
    xml_dir: str | None = None,
    plan_id: str | None = None,
    stability_reports: list[str] | None = None,
    history_dir: str | None = None,
    isolated: bool = True,
    log=lambda message: None,
) -> tuple[str, dict]:
    """由「仓库 + 目标」跑一次影子验证（workspace / commit 目标）。"""
    # 统一成绝对路径：后面收集/执行会 chdir，相对路径会让"分析根"跟着 cwd 漂。
    repo = str(Path(repo).resolve())
    # 证据先读：文件不认识就在跑 pytest 之前响亮失败，不白等两轮执行。
    evidence = load_flakiness(stability_reports, history_dir, log)
    request = _build_request(repo, target, request_id=f"shadow-{mode}")
    kind, plan_doc = plan_request.process_request(
        request, test_dir=test_dir, xml_dir=xml_dir, plan_id=plan_id, log=log
    )
    if kind != "plan":
        return "error", _refusal_error(plan_doc)
    return _execute_pair(
        plan_doc, root=repo, request=request, mode=mode, test_dir=test_dir,
        timeout_s=timeout_s, evidence=evidence, isolated=isolated, log=log,
        extra={
            "request_source": "<由 --repo/--target 合成>",
            "target_mode": request.get("mode"),
            "analysis_root": repo,
        },
    )


def run_shadow_for_request(
    request: dict,
    *,
    request_path: str | None = None,
    test_dir: str = "tests",
    mode: str = "shadow",
    timeout_s: int | None = None,
    xml_dir: str | None = None,
    plan_id: str | None = None,
    stability_reports: list[str] | None = None,
    history_dir: str | None = None,
    isolated: bool = True,
    log=lambda message: None,
) -> tuple[str, dict]:
    """消费一份 v1 `candidate_request`，在**同一个候选目录**上跑出可比的两份事实。

    这是 `VG:TF-0170` 在 `from-vg/handoffs/0005` 里要的形状：

        python -m smart_sorter.shadow --request <candidate_request.json> --out report.json

    目标身份从请求里取（candidate 模式即 `candidate@<candidate_tree_oid[:7]>`），计划仍走
    `plan_request` 的同一条"确认 + 规划"链路，两段执行都在 `resolution.analysis_root`（候选目录）上。
    请求声明的目标确认不了、或候选内容与声明的 tree 已经不一致 ⇒ 走 refusal 回执（退出码 3），
    绝不"猜一个目录照跑"；候选在两次运行之间被动过 ⇒ `run_plan` 判 `invalid` ⇒ 报告 `not-comparable`。
    """
    evidence = load_flakiness(stability_reports, history_dir, log)
    if not isinstance(request, dict):
        return "error", {
            "ok": False, "error_kind": "input-error", "reason": "候选请求顶层必须是 JSON 对象",
        }
    # 请求校验走 `contract_trees` 单点（2026-10-04）。原先这里写死 `contracts.validate`
    # （**只认 v1**）⇒ 一份合法的 2.0 请求会被判成『出现未声明字段 content_manifest／
    # 缺少必填字段 code_oid』而退 2。与 run_plan / stability 那几处同类。
    req_version = request.get("protocol_version")
    try:
        contract_trees.tree_for(req_version)
    except contract_trees.UnsupportedProtocol as exc:
        return "error", {
            "ok": False, "error_kind": "input-error",
            "reason": f"候选请求的协议版本不受支持：{exc}",
        }
    errors = (contracts.validate(request, "request") if req_version == "1.1"
              else contract_trees.validate_against(request, "request", req_version))
    if errors:
        return "error", {
            "ok": False, "error_kind": "input-error",
            "reason": f"候选请求不符合 {req_version} 契约：" + "；".join(errors),
        }
    # 分析根只能来自目标确认（candidate 模式 = target.candidate_dir），不退回当前目录、不猜 HEAD。
    resolution = plan_request.confirm_target(request)
    if not resolution.ok:
        _, refusal = plan_request.process_request(
            request, test_dir=test_dir, xml_dir=xml_dir, plan_id=plan_id, log=log
        )
        return "error", _refusal_error(refusal)
    root = resolution.analysis_root
    log(f"候选目标已确认：{resolution.target_identity}（分析根 {root}）")

    kind, plan_doc = plan_request.process_request(
        request, test_dir=test_dir, xml_dir=xml_dir, plan_id=plan_id, log=log
    )
    if kind != "plan":
        return "error", _refusal_error(plan_doc)
    return _execute_pair(
        plan_doc, root=root, request=request, mode=mode, test_dir=test_dir,
        timeout_s=timeout_s, evidence=evidence, isolated=isolated, log=log,
        extra={
            "request_source": request_path or "<内存中的请求>",
            "target_mode": request.get("mode"),
            "analysis_root": root,
        },
    )


def _execute_pair(
    plan_doc: dict,
    *,
    root: str,
    request: dict | None,
    mode: str,
    test_dir: str,
    timeout_s: int | None,
    evidence: dict,
    extra: dict,
    isolated: bool = True,
    log=lambda message: None,
) -> tuple[str, dict]:
    """计划就绪之后的共同部分：绑证据 → 跑两段 → 组装报告。

    两种输入（`--repo` 合成请求 / `--request` 直通候选请求）都走这里，所以"报告绑定什么、
    怎么对拍"只有一份实现。

    **两条臂各自一个独立解释器进程**（TF-0037，默认开）：过去两条臂在同一个进程里顺序跑
    `pytest.main()`，模块缓存、已 import 的被测包与 pytest 插件全局状态会互相污染——
    而"顺序依赖 / 共享状态"的测试正是靠这类污染串味的，于是"两次独立运行"只是口头承诺。
    每次跑完在 `runs.<臂>.isolated` 里如实标出这条臂是不是独立进程跑的。
    """
    log(
        f"计划就绪：target={plan_doc['target_identity']} plan={plan_doc['plan_id']} "
        f"collected={len(plan_doc['collected'])} selected={len(plan_doc['selected'])} "
        f"scope={plan_doc['selection_scope']}"
    )
    # 现在才知道本次的 target_identity：证据必须与它一致才生效（跨版本的不算数）。
    flakiness = bind_evidence(evidence, plan_doc["target_identity"], log)

    selected_result = None
    if mode == "shadow":
        log("按计划跑选中集……")
        kind, selected_result = run_plan.execute_plan(
            plan_doc, root=root, test_dir=test_dir, timeout_s=timeout_s, full=False,
            request=request, isolated=isolated, log=log,
        )
        if kind != "result":
            return "error", selected_result

    log("跑全量对拍……")
    kind, full_result = run_plan.execute_plan(
        plan_doc, root=root, test_dir=test_dir, timeout_s=timeout_s, full=True,
        request=request, isolated=isolated, log=log,
    )
    if kind != "result":
        return "error", full_result

    comparison = compare(plan_doc, selected_result, full_result, flakiness=flakiness)
    report = {
        "schema": REPORT_SCHEMA,
        "product_version": f"smart-test-sorter/{__version__}",
        "mode": mode,
        # 两条臂是不是各自独立进程跑的（TF-0037）。"独立对照"必须是可核的事实，不是口头承诺。
        "arms_are_isolated_processes": isolated,
        # **逐臂**的同一事实。刻意放在报告层、**不塞进 `runs.<臂>` 里那份 execution_result**：
        # 内嵌的两份是契约文档，v1 的 schema 是 `additionalProperties: false`，加一个 `isolated`
        # 字段会让它们**不再合契约**（实测：`result: 出现未声明字段 'isolated'`），
        # 也破坏"两份 execution_result **原样**内嵌"这条承诺。
        # 报告本身是产品自己的产物（不进 VG—STS 契约），所以加在这一层是安全的。
        "arm_isolation": {
            "selected": isolated if mode == "shadow" else None,
            "full": isolated,
            "note": "两条臂**各自**是否在独立解释器进程里执行；null 表示该臂本次没跑。",
        },
        # ---- 绑定：目标版本 + 计划 + 两次运行的实际范围 --------------------------
        "target_identity": plan_doc["target_identity"],
        "plan_id": plan_doc["plan_id"],
        "request_id": plan_doc["request_id"],
        # **1.1 的 `rules_id` 在 2.0 里搬进了 `policy_identity`**（R8：政策身份必须带版本）。
        # 影子报告是**本产品自己的产物**（不进 VG—STS 契约），所以对外仍叫 `rules_id`，
        # 但取值要按版本读，否则 2.0 计划会在这里 KeyError。
        "rules_id": _rules_id_of(plan_doc),
        "selection_scope": plan_doc["selection_scope"],
        "plan_fallback": list(plan_doc.get("fallback") or []),
        "collected": list(plan_doc["collected"]),
        "selected": list(plan_doc["selected"]),
        "excluded": list(plan_doc["excluded"]),
        "order": list(plan_doc["order"]),
        "risk_decisions": list(plan_doc.get("risk_decisions") or []),
        # 两次运行各自是一份完整结果：状态分开记，全量发现问题不倒算成先前选择正确。
        "runs": {
            "selected": selected_result,
            "full": full_result,
        },
        "scope_summary": {
            "executed_selected": list(selected_result["executed"]) if selected_result else [],
            "not_executed_selected": list(selected_result["not_executed"]) if selected_result else [],
            "executed_full": list(full_result["executed"]),
            "not_executed_full": list(full_result["not_executed"]),
        },
        "timing": {
            "selected_duration_s": (selected_result or {}).get("duration_s"),
            "full_duration_s": full_result["duration_s"],
        },
        # 跑之前分析根的内容指纹：让消费方能核"这两份事实到底跑在哪个内容上"。
        # candidate 模式下，候选目录里**未提交**的改动不会改变声明的 tree（confirm_target 只比
        # HEAD tree），所以这个指纹是唯一能看见它的东西；请求里带了
        # `identities.worktree_content_digest` 时，消费方可以直接比对。
        "analysis_content_digest": revision.content_digest(root),
        # ---- 不稳定证据（TF-0014）：哪些失败不能算确定的回归证据，理由逐条写出 ------
        "flakiness": {
            "evidence_sources": list(flakiness.get("sources") or []),
            "not_definite": dict(flakiness.get("not_definite") or {}),
            # 目标版本对不上、或没写目标版本的稳定性报告：**拒绝**它们，并写明为什么。
            "rejected_sources": dict(flakiness.get("rejected_sources") or {}),
            # 历史 JUnit 不带目标版本，属于跨版本的历史证据，单列出来如实标注。
            "unbound_history": dict(flakiness.get("unbound_history") or {}),
            "note": (
                "没在证据里的失败照旧算确定的漏选（不替失败找借口）；稳定性证据还必须与本次"
                "target_identity 一致才生效，跨版本的一律拒绝并记在 rejected_sources 里。"
                "被降级的失败结论是「判不了」（verdict=missed-failures-indeterminate、退出码 3），"
                "不是「没漏选」；本报告不据此剔除、跳过或重试任何测试。"
            ),
        },
        "comparison": comparison,
    }
    # 这次是怎么来的、在哪跑的：把输入来源与分析根如实记进报告（两种输入共用同一套报告结构）。
    report.update(extra)
    return "report", report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="smart_sorter.shadow",
        description="影子验证：出计划 → 跑选中集 → 同一目标跑全量对拍 → 范围明确的报告。",
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--repo", default=None,
                        help="目标仓库路径（workspace / commit 目标，内部合成请求）")
    source.add_argument("--request", default=None,
                        help="v1 candidate_request JSON（VG 的请求形状）：目标身份与候选目录都从它取")
    parser.add_argument("--target", default=revision.WORKTREE,
                        help="分析目标（只用于 --repo）：WORKTREE（默认，工作区未提交改动）或某个 commit-ish")
    parser.add_argument("--test-dir", default="tests", help="仓库内测试目录名，默认 tests")
    parser.add_argument("--mode", choices=["shadow", "full"], default="shadow",
                        help="shadow=选中集+全量对拍（默认）；full=只跑全量（按需全量模式）")
    parser.add_argument("--out", default=None, help="把报告 JSON 写到该文件（stdout 仍输出同一份）")
    parser.add_argument("--timeout", type=int, default=None,
                        help="每段执行的协作式预算秒数（在测试之间检查）")
    parser.add_argument("--xml-dir", default=None, help="可选历史 JUnit XML 目录（按失败率加权排序）")
    parser.add_argument("--plan-id", default=None, help="显式指定 plan_id（默认按规则确定性推出）")
    parser.add_argument("--stability", action="append", default=None, metavar="REPORT",
                        help="稳定性报告（可重复给）：其中的 flaky/运行错误失败不算确定的漏选")
    parser.add_argument("--history-xml-dir", default=None,
                        help="可选历史 JUnit XML 目录：失败率在 0 与 1 之间的测试不算确定的漏选")
    parser.add_argument("--same-process", dest="isolated", action="store_false", default=True,
                        help="两条臂在同一个解释器进程里跑（默认各自独立进程；只用于对照/排查）")
    return parser


def main(argv: list[str] | None = None) -> int:
    plan_request._force_utf8_output()
    args = build_parser().parse_args(argv)

    def log(message: str) -> None:
        print(f"[shadow] {message}", file=sys.stderr)

    if args.request:
        try:
            request_doc = json.loads(Path(args.request).read_text(encoding="utf-8"))
        except FileNotFoundError:
            return _usage_error(f"候选请求文件不存在 -> {args.request}")
        except (OSError, json.JSONDecodeError) as exc:
            return _usage_error(f"候选请求文件读不了 -> {args.request}：{exc}")
        try:
            kind, report = run_shadow_for_request(
                request_doc, request_path=args.request, test_dir=args.test_dir, mode=args.mode,
                timeout_s=args.timeout, xml_dir=args.xml_dir, plan_id=args.plan_id,
                stability_reports=args.stability, history_dir=args.history_xml_dir,
                isolated=args.isolated, log=log,
            )
        except (ValueError, OSError) as exc:
            return _usage_error(str(exc))
    else:
        if not Path(args.repo).is_dir():
            return _usage_error(f"目标仓库不存在或不是目录 -> {args.repo}")
        try:
            kind, report = run_shadow(
                args.repo, target=args.target, test_dir=args.test_dir, mode=args.mode,
                timeout_s=args.timeout, xml_dir=args.xml_dir, plan_id=args.plan_id,
                stability_reports=args.stability, history_dir=args.history_xml_dir,
                isolated=args.isolated, log=log,
            )
        except (ValueError, OSError) as exc:
            return _usage_error(str(exc))

    if kind == "error":
        if report.get("error_kind") == "input-error":
            return _usage_error(report["reason"])
        # 无法规划：仍然给出一份可读的错误对象，退出码 3（与 plan_request 的回执语义一致）。
        text = json.dumps(report, ensure_ascii=False, indent=2)
        if args.out:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
        print(text)
        log(f"无法规划：{report['reason']}")
        return _EXIT_INCOMPARABLE

    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out:
        try:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
        except OSError as exc:
            return _usage_error(f"无法写出 {args.out}：{exc}")
        log(f"已写出 {args.out}")
    print(text)

    verdict = report["comparison"]["verdict"]
    comparison = report["comparison"]
    log(
        f"verdict={verdict} target={report['target_identity']} "
        f"collected={len(report['collected'])} selected={len(report['selected'])} "
        f"漏选={len(comparison.get('missed_failures') or [])} "
        f"判不了(不稳定)={len(comparison.get('missed_failures_indeterminate') or [])} "
        f"耗时 选中 {(report['timing']['selected_duration_s'] or 0):.2f}s / 全量 {report['timing']['full_duration_s']:.2f}s"
    )
    if verdict in ("not-comparable", "missed-failures-indeterminate"):
        # 判不了不等于是好事，也不等于是坏事：它不该被当成"没有漏选"（退出码因此不是 0）。
        return _EXIT_INCOMPARABLE
    if verdict == "missed-failures":
        return _EXIT_MISSED
    return _EXIT_OK


def _usage_error(reason: str) -> int:
    print(f"[shadow] 错误：{reason}", file=sys.stderr)
    print(json.dumps(
        {"ok": False, "error_kind": "input-error", "reason": reason}, ensure_ascii=False,
    ))
    return _EXIT_USAGE


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
