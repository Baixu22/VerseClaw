"""函数 -> 测试用例 的调用链追踪。

Stage 0 的 ast_diff 能告诉我们"哪些函数变了"，本模块负责回答下一个问题：
"哪些测试用例会碰到这些函数"。

MVP 采用【名称匹配】的静态启发式：不做完整类型推断，只看测试函数体里出现的
调用名字是否命中目标函数名。会有误报，但足够简单、够快，适合毕设 MVP。
"""

from __future__ import annotations

import ast
from collections.abc import Iterable
from pathlib import Path

from smart_sorter.ast_diff import get_changed_functions

# 扫描源码时要跳过的目录（虚拟环境、缓存、依赖、版本控制等）。
_SKIP_DIRS = {".venv", "venv", "__pycache__", "node_modules", ".git", ".tox", "build", "dist"}


def _iter_py_files(root: Path):
    """遍历 root 下所有 .py 文件，跳过隐藏目录和 _SKIP_DIRS。"""
    for path in root.rglob("*.py"):
        # 只看相对 root 的部分：仓库本身位于隐藏目录下（如 ~/.cache）时不能被整体跳过。
        rel_dirs = path.relative_to(root).parts[:-1]
        if set(rel_dirs) & _SKIP_DIRS:
            continue
        if any(p.startswith(".") for p in rel_dirs):
            continue
        yield path


def _module_name(project_root: Path, file_path: Path) -> str:
    """把文件路径转成点分模块名，例如 httpx/_client.py -> httpx._client。"""
    rel = file_path.relative_to(project_root).with_suffix("")
    parts = [p for p in rel.parts if p != "__init__"]
    return ".".join(parts)


def build_function_index(project_path: str) -> dict[str, str]:
    """扫描整个项目，建立 {函数全限定名: 文件相对路径} 的索引。

    全限定名格式：
        顶层函数     -> "httpx._api.get"
        类方法       -> "httpx._client.Client.request"

    返回的文件路径用相对 project_path 的 POSIX 风格（正斜杠），方便跨平台展示。
    """
    root = Path(project_path).resolve()
    index: dict[str, str] = {}

    for file_path in _iter_py_files(root):
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except (SyntaxError, UnicodeDecodeError):
            # 单个文件解析失败不影响整体索引构建。
            continue

        module = _module_name(root, file_path)
        rel_posix = file_path.relative_to(root).as_posix()

        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                index[f"{module}.{node.name}"] = rel_posix
            elif isinstance(node, ast.ClassDef):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        index[f"{module}.{node.name}.{item.name}"] = rel_posix

    return index


def _short_name(qualified: str) -> str:
    """取全限定名的最后一段，即真正的函数/方法名。

    "Client.request" -> "request"；"parse_header_links" -> "parse_header_links"。
    """
    return qualified.split(".")[-1]


def _called_names(func_node: ast.AST) -> set[str]:
    """收集一个函数体内所有【被调用】的名字。

    对每个 Call 节点，看它的 func：
        client.request(...)  -> Attribute，取 .attr = "request"
        request(...)         -> Name，取 .id = "request"
    只关心"被调用的那个名字"，这正是 MVP 名称匹配需要的信号。
    """
    names: set[str] = set()
    for node in ast.walk(func_node):
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Attribute):
                names.add(func.attr)
            elif isinstance(func, ast.Name):
                names.add(func.id)
    return names


def _referenced_names(func_node: ast.AST) -> set[str]:
    """收集函数体内所有【被引用】的标识符：Name.id 与 Attribute.attr。

    比 _called_names 更宽——不要求出现在 Call.func 里。用于【名称级保守选择】：
    很多真实测试并不【直接调用】被改函数，而是把它当值传递、做类型判断或按属性
    读取，这些在一跳的 _called_names（只看 Call.func）里全是盲点：
        fn = handler; fn()        -> handler 被引用，Call.func 是 fn 不是 handler
        isinstance(x, Money)      -> Money 是实参 Name，未作为被调用者
        register(my_view)         -> my_view 作为参数传入，未被调用
        @my_decorator             -> 装饰器名被引用
    只要测试体里出现了与被改元素同名的标识符，就把它纳入"必须运行"，宁可多跑
    也不静默漏选。这条比一跳调用匹配召回更高、更保守，正是调用图的安全网。
    """
    names: set[str] = set()
    for node in ast.walk(func_node):
        if isinstance(node, ast.Name):
            names.add(node.id)
        elif isinstance(node, ast.Attribute):
            names.add(node.attr)
    return names


def _changed_target_names(changed_functions: list[dict]) -> list[str]:
    """把 get_changed_functions 的结果压成"要匹配的目标短名"列表。

    只取【被测源码】里变更的函数（排除测试文件本身），并且对类方法额外补上
    【类名】——测试通常不会写 client.__init__()，而是实例化/引用 Client(...)，
    所以类名也是一个有效的匹配目标。get_affected_tests 与名称级保守选择共用它。
    """
    targets: list[str] = []
    for c in changed_functions:
        if Path(c["file"]).name.startswith("test_"):
            continue
        func = c["function"]
        targets.append(func)
        if "." in func:
            targets.append(func.split(".")[0])  # 类名也作为匹配目标
    return targets


def find_test_callers(
    project_path: str,
    target_functions: list[str],
    test_dir: str = "tests",
) -> dict[str, list[str]]:
    """在测试目录里找出调用了目标函数的测试用例。

    参数:
        target_functions: 目标函数名列表，可以是短名 "request" 或
                          限定名 "Client.request"，内部统一取短名做匹配。
    返回:
        {测试 node ID: [命中的目标函数(短名)列表]}
        node ID 用 pytest 格式，如 "tests/test_auth.py::test_digest_auth"。
        类内测试方法格式为 "tests/test_x.py::TestClass::test_method"。
    """
    root = Path(project_path).resolve()
    test_root = (root / test_dir).resolve()
    if not test_root.exists():
        return {}

    # 目标函数的短名集合（去重）。
    targets = {_short_name(t) for t in target_functions}
    if not targets:
        return {}

    result: dict[str, list[str]] = {}

    for file_path in _iter_py_files(test_root):
        if not file_path.name.startswith("test_"):
            continue
        try:
            tree = ast.parse(file_path.read_text(encoding="utf-8"))
        except (SyntaxError, UnicodeDecodeError):
            continue

        rel = file_path.relative_to(root).as_posix()

        # 收集测试函数：既包括模块级 test_*，也包括 TestXxx 类里的 test_* 方法。
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
                _match_one(rel, None, node, targets, result)
            elif isinstance(node, ast.ClassDef) and node.name.startswith("Test"):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name.startswith("test_"):
                        _match_one(rel, node.name, item, targets, result)

    return result


def _match_one(
    rel_path: str,
    class_name: str | None,
    func_node: ast.AST,
    targets: set[str],
    result: dict[str, list[str]],
) -> None:
    """判断单个测试函数是否命中目标；命中则写入 result（pytest node ID 为 key）。"""
    called = _called_names(func_node)
    hits = sorted(called & targets)
    if not hits:
        return
    if class_name:
        node_id = f"{rel_path}::{class_name}::{func_node.name}"
    else:
        node_id = f"{rel_path}::{func_node.name}"
    result[node_id] = hits


def get_affected_tests(
    repo_path: str,
    target: str,
    test_dir: str = "tests",
) -> list[str]:
    """端到端：给定变更目标，返回受影响的测试 node ID 列表（已去重、已排序）。

    流程：get_changed_functions -> 提取被改函数名 -> find_test_callers。
    只用【源码里】变更的非测试函数作为目标，避免"测试改了自己"这种噪声。
    target 可以是 commit-ish 或 revision.WORKTREE。
    """
    changed = get_changed_functions(repo_path, target)
    target_functions = _changed_target_names(changed)
    callers = find_test_callers(repo_path, target_functions, test_dir=test_dir)
    return sorted(callers.keys())


def _file_keyword_variants(stem: str) -> set[str]:
    """由文件名主干派生用于子串匹配的关键词变体，鲁棒应对单复数命名差异。

    模块 `_urls.py` 的测试常放在 `test_url.py`（单数）里——直接用 "urls" 做子串匹配
    会漏（"urls" 不是 "url" 的子串）。这里同时产出去尾 s 的单数形式，让 "url" 能命中
    "test_url.py"。只保留长度 ≥3 的关键词，避免过短词造成噪声命中。
    """
    variants = {stem}
    if stem.endswith("s"):
        variants.add(stem[:-1])
    return {k for k in variants if len(k) >= 3}


def path_keywords(rel_path: str) -> set[str]:
    """由仓库相对路径派生【文件级关键词】：文件名主干去掉前导下划线 + 单数形式（长度 ≥3）。

    例如 httpx/_content.py -> {"content"}、httpx/_urls.py -> {"urls","url"}。
    这是"按文件名找同名测试"这条基线唯一的派生口径，`changed_file_keywords`（选择）与
    `risk`（风险提示的路径定位）都复用它，避免两处各写一份、口径漂移。
    """
    return _file_keyword_variants(Path(rel_path).stem.lstrip("_").lower())


def changed_file_keywords(repo_path: str, target: str) -> set[str]:
    """从本次变更的【非测试源码文件】派生文件级关键词（去前导下划线的文件名主干及其单数形式）。

    例如 httpx/_content.py -> {"content"}、httpx/_urls.py -> {"urls","url"}。用于文件级
    保守选择：凡 node id 含这些关键词的测试都保留。这是 testmon 之前业界最常用的文件级
    RTS 基线，召回口径与被改函数是否被【静态可见地】调用无关——因此能兜住"测试经动态
    派发（如 mock transport、client 请求管线）间接触发被改函数、静态调用图与名称级都
    看不到"的情况。

    与文件级基线安全率的关系：把它并入 --smart-select 的保留判据【只是必要条件】。
    真正保证"选择结果 ⊇ 文件级基线、安全率不弱于文件级"的是 select_tests_file_level
    的【空匹配→全量】兜底——本函数只产出关键词，兜底逻辑在那里。

    target 可以是 commit-ish 或 revision.WORKTREE。
    """
    changed = get_changed_functions(repo_path, target)
    keywords: set[str] = set()
    for c in changed:
        rel = c["file"]
        if Path(rel).name.startswith("test_"):
            continue
        keywords |= path_keywords(rel)
    return keywords


def select_tests_file_level(
    test_ids: Iterable[str], file_keywords: set[str]
) -> set[str]:
    """文件级基线选择（复刻 testmon 之前业界最常用的文件级 RTS，含空匹配→全量兜底）。

    这是 --smart-select 与评测脚本【共用】的唯一文件级实现，语义与 run_benchmark 的
    strategy_file_level / safety_study 的 select_file_level 完全一致：

      - file_keywords 为空（本次没有可派生关键词的源码文件改动）-> 返回空集，
        把"要不要跑"完全交给其它判据（名称级 / 调用图 / changed_test_files / 全量兜底）；
      - file_keywords 非空但【没有任何测试命中】-> 返回【全部测试】（`selected or all`）：
        文件级基线在"改了源码却找不到同名测试"时不敢剔除，退化为全量。这一步正是让
        --smart-select 的保留集成为文件级基线【真超集】、从而安全率不弱于文件级的关键；
      - 否则 -> 返回 node id 含任一关键词的测试集合。

    只做子串匹配，不解析调用关系——这正是文件级基线"与被改函数是否被静态可见地调用
    无关"的召回来源，能兜住运算符分派 / mock transport / 动态派发等静态分析看不到的
    同模块测试。
    """
    all_ids = set(test_ids)
    if not file_keywords:
        return set()
    selected = {tid for tid in all_ids if any(kw in tid.lower() for kw in file_keywords)}
    return selected or all_ids


def select_tests_by_name(repo_path: str, target: str) -> set[str]:
    """名称级保守选择：返回体内【引用】了任一被改元素同名标识符的测试 node ID 集合。

    这是 --smart-select 的安全网（参考 NameRTS 思路）：调用图只用于【排序】，
    要不要【剔除】一个测试则由这条更宽、更保守的名称级判据决定。它比
    get_affected_tests（只看 Call）召回更高——能覆盖把函数当值传递、类型判断、
    装饰器引用等静态调用图看不到的情况，从而把"可能漏测"降到最低。

    target 可以是 commit-ish 或 revision.WORKTREE。

    与 find_test_callers 的两点区别：
      1. 用 _referenced_names（Name + Attribute）而非 _called_names（仅 Call.func）；
         被改类方法会连同【类名】一起作为匹配目标。
      2. 扫描【整个仓库】里所有 test_*.py（按文件名识别，不限某个 tests/ 目录）——
         与 build_call_graph 的口径一致，保证名称级选择是调用图可达集的保守【超集】，
         而不会因为测试不在 tests/ 下就反而漏掉。
    """
    changed = get_changed_functions(repo_path, target)
    target_names = _changed_target_names(changed)
    return select_tests_referencing(repo_path, target_names)


def select_tests_referencing(
    repo_path: str, target_functions: list[str]
) -> set[str]:
    """名称级保守选择的内核：给定目标函数名（短名或 Class.method），返回体内
    【引用】了任一目标同名短名标识符的测试 node ID 集合。

    从 target_functions 里各取短名、过滤掉 <3 字符的噪声名，然后扫描整仓所有
    test_*.py，凡 _referenced_names（Name + Attribute）与目标短名有交集的测试即选中。
    select_tests_by_name 从 git commit 推出目标名后委托本函数；评测脚本则可直接
    传入变异体的被改函数名，两条路径共享同一份保守判据，保证实验与生产口径一致。
    """
    targets = {_short_name(t) for t in target_functions}
    # 短名太短（<3 字符）容易误命中噪声（如变量 x）；与 name_bonus 保持一致地过滤。
    targets = {t for t in targets if len(t) >= 3}
    if not targets:
        return set()

    root = Path(repo_path).resolve()
    selected: set[str] = set()
    for file_path in _iter_py_files(root):
        if not file_path.name.startswith("test_"):
            continue
        try:
            tree = ast.parse(file_path.read_text(encoding="utf-8"))
        except (SyntaxError, UnicodeDecodeError):
            continue
        rel = file_path.relative_to(root).as_posix()
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
                if _referenced_names(node) & targets:
                    selected.add(f"{rel}::{node.name}")
            elif isinstance(node, ast.ClassDef) and node.name.startswith("Test"):
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name.startswith("test_"):
                        if _referenced_names(item) & targets:
                            selected.add(f"{rel}::{node.name}::{item.name}")
    return selected
