"""过程间调用图（inter-procedural call graph）与多跳可达性分析。

这是"毕设版"相对 MVP 的核心算法升级。MVP 的 call_graph.find_test_callers 只做
【一跳名称匹配】——只看测试函数体里直接出现的调用名，抓不到
    test → helper() → 被改函数
    test → httpx.get() → Client.request() → 被改函数
这类间接调用。本模块把它升级为：
    1. 构建全项目的过程间调用图（谁调用了谁）；
    2. 从"被改函数"出发做【反向 BFS】，得到每个测试到被改函数的最短调用距离；
    3. 距离既用于判定"是否受影响"，也作为排序的强信号（越近越优先）。

仍然只用标准库 ast + 复用 call_graph 的索引，不引入 jedi 等静态分析库。

术语——"节点 id"：
    源码函数用【全限定名】，如 "httpx._client.Client.request"；
    测试函数用【pytest node id】，如 "tests/test_auth.py::test_digest_auth"。
测试函数只可能是"调用者"（没人会调用 test_*），所以永远不需要把节点 id 当作
被解析的调用目标——调用目标一定是全限定名。这条不变量让两种命名和平共存。
"""

from __future__ import annotations

import ast
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

from smart_sorter.ast_diff import get_changed_functions
from smart_sorter.call_graph import _iter_py_files, _module_name

# 一个短名若解析到超过这么多候选目标，视为"过于普通"（如 get/init）而跳过，
# 避免调用图被噪声边淹没、导致所有测试距离都变得很近。
_MAX_CANDIDATES_PER_NAME = 8

# 反向 BFS 的默认最大跳数：超过则不再扩展，防止可达集膨胀成"全量"。
_DEFAULT_MAX_HOPS = 4


@dataclass
class _FileImports:
    """一个文件里的 import 情况，用于把调用点解析到全限定名。"""
    # 模块别名：`import httpx` -> {"httpx": "httpx"}；`import httpx as hx` -> {"hx": "httpx"}
    module_aliases: dict[str, str] = field(default_factory=dict)
    # 符号导入：`from httpx import get` -> {"get": "httpx.get"}
    symbol_imports: dict[str, str] = field(default_factory=dict)


@dataclass
class CallGraph:
    """过程间调用图。

    节点有两类命名（见模块 docstring 的不变量）：
      - 源码/辅助函数用全限定名 "pkg.mod.Class.method"；
      - 测试函数用 pytest node id "tests/test_x.py::test_foo"。
    边表示"调用"关系：caller -> callee，callee 一定是全限定名。
    """
    edges: dict[str, set[str]] = field(default_factory=dict)          # caller -> {callee}
    reverse_edges: dict[str, set[str]] = field(default_factory=dict)  # callee -> {caller}
    node_file: dict[str, str] = field(default_factory=dict)           # node -> 文件相对路径
    is_test: dict[str, bool] = field(default_factory=dict)            # node -> 是否测试函数

    def add_edge(self, caller: str, callee: str) -> None:
        """登记一条 caller -> callee 边（同时维护反向边）。"""
        if caller == callee:
            return  # 忽略自递归
        self.edges.setdefault(caller, set()).add(callee)
        self.reverse_edges.setdefault(callee, set()).add(caller)

    def subgraph_nodes(self) -> set[str]:
        """图中出现过的所有节点（调用者 + 被调用者）。"""
        nodes = set(self.node_file)
        nodes.update(self.edges)
        for callees in self.edges.values():
            nodes.update(callees)
        return nodes


def _parse_imports(
    tree: ast.Module, current_module: str, *, is_package: bool = False
) -> _FileImports:
    """解析一个文件顶层的 import 语句，供调用点解析使用。

    支持：
      import httpx                 -> module_aliases["httpx"]  = "httpx"
      import httpx as hx           -> module_aliases["hx"]     = "httpx"
      from httpx import get, post  -> symbol_imports["get"]    = "httpx.get"
      from . import _utils         -> module_aliases["_utils"] = "<pkg>._utils"
      from ._client import Client  -> symbol_imports["Client"] = "<pkg>._client.Client"
    相对导入用 current_module 推算所属包。只解析顶层 import（函数内的局部 import 少见，
    MVP 不处理）。
    """
    imports = _FileImports()
    # For __init__.py, current_module names the package itself, not a child module.
    pkg_parts = current_module.split(".") if is_package else current_module.split(".")[:-1]

    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                bound = alias.asname or alias.name.split(".")[0]
                imports.module_aliases[bound] = alias.name if alias.asname else bound
        elif isinstance(node, ast.ImportFrom):
            module = _resolve_from_module(node, pkg_parts)
            for alias in node.names:
                bound = alias.asname or alias.name
                if module:
                    imports.symbol_imports[bound] = f"{module}.{alias.name}"
                    # `from pkg import submod` 时，submod 也可能被当模块用
                    imports.module_aliases.setdefault(bound, f"{module}.{alias.name}")
    return imports


def _resolve_from_module(node: ast.ImportFrom, pkg_parts: list[str]) -> str:
    """把 ImportFrom 的模块名解析成绝对点分路径（处理相对 import 的层级）。"""
    if node.level == 0:
        return node.module or ""
    # 相对 import：level=1 表示当前包，level=2 表示上一级包……
    base = pkg_parts[: len(pkg_parts) - (node.level - 1)] if node.level > 1 else pkg_parts
    if node.module:
        return ".".join([*base, node.module])
    return ".".join(base)


def _build_symbol_table(index: dict[str, str]) -> dict[str, set[str]]:
    """由 {全限定名: 文件} 索引反推 {短名: {以该短名结尾的全限定名集合}}。

    例如 "httpx._client.Client.request" 的短名是 "request"。用于调用点在
    import 别名解析失败时的回退匹配。
    """
    table: dict[str, set[str]] = {}
    for qualified in index:
        short = qualified.split(".")[-1]
        table.setdefault(short, set()).add(qualified)
    return table


def _build_class_table(project_path: str) -> dict[str, set[str]]:
    """扫描项目，建立 {类短名: {类的全限定名集合}}，用于解析构造函数调用。

    例如 httpx/_client.py 里的 class Client -> {"Client": {"httpx._client.Client"}}。
    """
    root = Path(project_path).resolve()
    table: dict[str, set[str]] = {}
    for file_path in _iter_py_files(root):
        try:
            tree = ast.parse(file_path.read_text(encoding="utf-8"))
        except (SyntaxError, UnicodeDecodeError):
            continue
        module = _module_name(root, file_path)
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                table.setdefault(node.name, set()).add(f"{module}.{node.name}")
    return table


def _resolve_call(
    func: ast.expr,
    imports: _FileImports,
    known: set[str],
    symbol_table: dict[str, set[str]],
    class_table: dict[str, set[str]],
) -> set[str]:
    """把一个 Call 的 func 表达式解析成候选被调用者（全限定名集合）。

    解析优先级（从高置信到低置信）：
      1. import 别名/符号能直接指向 known 里的全限定名 -> 单条高置信边；
      2. 构造函数调用 ClassName(...) -> 指向该类的 __init__；
      3. 回退到"短名匹配"（可能一对多），但若候选过多（过于普通的名字）则丢弃，
         以免调用图被噪声边淹没。
    """
    high_conf: set[str] = set()      # 直接命中 known 的高置信目标
    fallback_name: str | None = None  # 需要走短名回退的名字

    if isinstance(func, ast.Name):
        name = func.id
        if name in imports.symbol_imports and imports.symbol_imports[name] in known:
            high_conf.add(imports.symbol_imports[name])
        elif name in class_table:
            high_conf |= _ctor_targets(class_table[name], known)
        else:
            fallback_name = name

    elif isinstance(func, ast.Attribute):
        attr = func.attr
        value = func.value
        # module.attr 且 module 是已知 import 别名 -> 先试直接全限定名
        if isinstance(value, ast.Name) and value.id in imports.module_aliases:
            direct = f"{imports.module_aliases[value.id]}.{attr}"
            if direct in known:
                high_conf.add(direct)
            elif attr in class_table:
                # module.ClassName(...) 形式的构造函数调用，如 httpx.Request(...)。
                # 裸名 Request(...) 已由上面的 ast.Name 分支经 class_table 解析；
                # 属性形式同样常见（httpx.Client()/pd.DataFrame()），这里补齐，
                # 否则"测试经公共外观类构造 -> __init__ -> 内部函数"的调用链会在
                # 第一跳断裂，导致多跳可达把这类测试全部漏掉。
                high_conf |= _ctor_targets(class_table[attr], known)
            else:
                fallback_name = attr  # 如 httpx.get 是 re-export，回退短名
        else:
            fallback_name = attr  # obj.method()，obj 类型未知，走短名

    if high_conf:
        return high_conf

    if fallback_name is not None:
        candidates = symbol_table.get(fallback_name, set())
        # 名字过于普通（匹配太多）时丢弃，用距离度量无法拯救的噪声在此掐断。
        if 0 < len(candidates) <= _MAX_CANDIDATES_PER_NAME:
            return set(candidates)
    return set()


def _ctor_targets(class_qualifieds: set[str], known: set[str]) -> set[str]:
    """构造函数调用的目标：类的 __init__（若在 known 里）。"""
    targets = set()
    for cls in class_qualifieds:
        init = f"{cls}.__init__"
        if init in known:
            targets.add(init)
    return targets


def _node_defs(tree: ast.Module):
    """产出一个模块里的函数定义节点，附带其"限定前缀"。

    产出 (prefix, func_node)：
      - 顶层函数     prefix = ""            -> 全名 = module.func
      - 类方法       prefix = "Class"       -> 全名 = module.Class.method
    """
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            yield ("", node)
        elif isinstance(node, ast.ClassDef):
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    yield (node.name, item)


def build_call_graph(project_path: str, test_dir: str = "tests") -> CallGraph:
    """构建整个项目的过程间调用图。

    步骤：
      1. 复用 build_function_index 得到 {全限定名: 文件} -> 派生短名符号表；
      2. 逐文件解析 import，逐函数遍历调用点、解析成候选被调用者并建边；
      3. 测试函数（test_*）作为调用者，用 pytest node id 作节点名。
    """
    from smart_sorter.call_graph import build_function_index

    root = Path(project_path).resolve()
    index = build_function_index(project_path)          # 全限定名 -> 文件
    known = set(index)                                  # 所有已知源码/测试函数
    symbol_table = _build_symbol_table(index)
    class_table = _build_class_table(project_path)

    graph = CallGraph()
    # 先登记非测试的已知节点及其文件。测试函数【不】用全限定名登记——它们会在下面
    # 以 pytest node id 形式作为调用者登记，避免同一个测试出现两种命名的重复节点。
    for qualified, rel in index.items():
        if _looks_like_test(rel, qualified):
            continue
        graph.node_file[qualified] = rel
        graph.is_test[qualified] = False

    for file_path in _iter_py_files(root):
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source)
        except (SyntaxError, UnicodeDecodeError):
            continue

        module = _module_name(root, file_path)
        rel = file_path.relative_to(root).as_posix()
        imports = _parse_imports(tree, module, is_package=file_path.name == "__init__.py")
        is_test_file = file_path.name.startswith("test_")

        for prefix, func in _node_defs(tree):
            caller = _caller_node_id(rel, module, prefix, func.name, is_test_file)
            graph.node_file.setdefault(caller, rel)
            graph.is_test.setdefault(caller, is_test_file and func.name.startswith("test_"))

            for call in _iter_calls(func):
                for callee in _resolve_call(
                    call.func, imports, known, symbol_table, class_table
                ):
                    graph.add_edge(caller, callee)

    return graph


def _looks_like_test(rel_path: str, qualified: str) -> bool:
    """索引里的某个全限定名是否属于测试函数（文件名 test_* 且函数名 test_*）。"""
    fname = rel_path.rsplit("/", 1)[-1]
    short = qualified.split(".")[-1]
    return fname.startswith("test_") and short.startswith("test_")


def _caller_node_id(
    rel: str, module: str, prefix: str, func_name: str, is_test_file: bool
) -> str:
    """给调用者算节点 id：测试函数用 pytest node id，其余用全限定名。"""
    if is_test_file and func_name.startswith("test_"):
        if prefix:
            return f"{rel}::{prefix}::{func_name}"
        return f"{rel}::{func_name}"
    # 源码/辅助函数用全限定名
    if prefix:
        return f"{module}.{prefix}.{func_name}"
    return f"{module}.{func_name}"


def _iter_calls(func_node: ast.AST):
    """产出一个函数体内的所有 Call 节点。"""
    for node in ast.walk(func_node):
        if isinstance(node, ast.Call):
            yield node


def affected_tests_with_distance(
    graph: CallGraph,
    changed_functions: list[str],
    max_hops: int = _DEFAULT_MAX_HOPS,
) -> dict[str, int]:
    """从被改函数出发做反向 BFS，返回 {测试 node id: 最短调用距离}。

    距离 = 从测试函数到被改函数的最短调用路径长度（边数）。距离 1 表示测试直接
    调用了被改函数；距离 2 表示隔着一层 helper；以此类推。max_hops 限制扩展深度。

    changed_functions 传入的是全限定名（如 "httpx._client.Client.request"）；只保留
    图里确实存在的作为 BFS 起点。
    """
    # BFS 起点：被改函数中确实是图节点的那些，起始距离 0。
    dist: dict[str, int] = {}
    queue: deque[str] = deque()
    for fn in changed_functions:
        if fn in graph.node_file or fn in graph.reverse_edges:
            dist[fn] = 0
            queue.append(fn)

    result: dict[str, int] = {}
    while queue:
        node = queue.popleft()
        d = dist[node]
        if d >= max_hops:
            continue
        for caller in graph.reverse_edges.get(node, ()):
            if caller in dist and dist[caller] <= d + 1:
                continue
            dist[caller] = d + 1
            queue.append(caller)
            if graph.is_test.get(caller):
                # 记录测试到被改函数的最短距离（BFS 保证首次到达即最短）。
                if caller not in result or result[caller] > d + 1:
                    result[caller] = d + 1

    return result


def get_affected_tests_graph(
    repo_path: str,
    target: str,
    test_dir: str = "tests",
    max_hops: int = _DEFAULT_MAX_HOPS,
) -> dict[str, int]:
    """端到端：给定变更目标，用调用图求 {受影响测试 node id: 调用距离}。

    结合 get_changed_functions（变更的源码函数）与 build_call_graph，返回按距离
    可排序的映射。变更的测试文件自身不作为 BFS 起点（避免"测试改了自己"噪声）。
    target 可以是 commit-ish 或 revision.WORKTREE。
    """
    changed = get_changed_functions(repo_path, target)

    graph = build_call_graph(repo_path, test_dir=test_dir)

    # 把变更函数（非测试文件）转成图里的全限定名起点。ast_diff 给的是
    # "文件相对路径 + 函数名(可能带 Class.)"，这里拼成 module.[Class.]func。
    starts: list[str] = []
    for c in changed:
        rel = c["file"]
        if Path(rel).name.startswith("test_"):
            continue
        module = _rel_to_module(rel)
        starts.append(f"{module}.{c['function']}")

    return affected_tests_with_distance(graph, starts, max_hops=max_hops)


def _rel_to_module(rel_path: str) -> str:
    """把文件相对路径转点分模块名：httpx/_client.py -> httpx._client。"""
    p = Path(rel_path).with_suffix("")
    parts = [seg for seg in p.parts if seg != "__init__"]
    return ".".join(parts)
