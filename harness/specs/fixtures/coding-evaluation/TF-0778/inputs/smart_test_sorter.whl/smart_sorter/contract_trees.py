# -*- coding: utf-8 -*-
"""契约树选择：v1 与 v2 各一棵，**按文档自己声明的 protocol_version 选**，不猜。

为什么单点：1.1 与 2.0 的 schema 在 `contracts/vg-sts/v1` 与 `contracts/vg-sts/v2`，
而 `load_schema(kind, root)` 已经带了 root 旁路（TF-0040 起草时加的）。缺的只是
"一个文档该用哪棵树"这条判据——散在各处写 `if version == "2.0"` 就会漂。

**这条判据本身也要可测**：版本不认识 ⇒ 显式拒绝，**不做静默兼容**（沿用 v1 的既有口径）。
"""
from __future__ import annotations

import sys
from pathlib import Path

from smart_sorter.contracts import _find_contract_root

#: 已定稿的协议版本 → 契约树目录名。**只有已定稿的版本在这里**；
#: 草案（v2-draft）**故意不在**——产品不消费未定稿的契约。
SUPPORTED_TREES: dict[str, str] = {
    "1.0": "v1",
    "1.1": "v1",
    "2.0": "v2",
}

#: 我们自己能**生产**的版本（能消费 ≠ 能生产）。
#: 1.1 是当前唯一两侧都通的；2.0 的生产路径从 TF-0040 定稿后才开始。
PRODUCIBLE: frozenset[str] = frozenset({"1.0", "1.1", "2.0"})


class UnsupportedProtocol(Exception):
    """请求/计划的 protocol_version 没有对应的契约树（或我们不生产它）。"""


def tree_for(version: object, *, producing: bool = False) -> Path:
    """按版本取契约树目录。

    `producing=True` 时额外要求该版本在我们**能生产**的集合里——
    用于"我要产出这份文档"的场景（不能消费却能产出，那不叫支持）。
    """
    v = version if isinstance(version, str) else None
    if v is None or v not in SUPPORTED_TREES:
        raise UnsupportedProtocol(
            f"协议版本 {version!r} 不受支持（支持 {sorted(SUPPORTED_TREES)}），"
            f"拒绝而非静默兼容"
        )
    if producing and v not in PRODUCIBLE:
        raise UnsupportedProtocol(
            f"协议版本 {v!r} 我们能消费但**还不能生产**（可生产 {sorted(PRODUCIBLE)}）"
        )
    root = _find_contract_root(SUPPORTED_TREES[v])
    if not (root / "manifest.json").is_file():
        raise UnsupportedProtocol(f"契约树缺失：{root}")
    return root


def validate_against(doc: object, kind: str, version: object) -> list[str]:
    """按文档自己声明的版本选树并做**结构**校验。"""
    from smart_sorter import contracts

    return contracts.validate_schema(doc, kind, root=tree_for(version))


if __name__ == "__main__":  # 手工复核用
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    for v in ("1.0", "1.1", "2.0", "9.9", None):
        try:
            print(f"  {v!r:8} -> {tree_for(v)}")
        except UnsupportedProtocol as exc:
            print(f"  {v!r:8} -> 拒绝：{exc}")
