"""不稳定测试与运行错误的记录（TF-0014）——不把"曾经挂过"当成确定的合并回归。

## 它解决什么问题

一次 pytest 运行给出的是**一次**事实；而"这个测试挂过"有两种完全不同的成因：

- 每次跑都挂 → 确定的失败，可以当作回归证据；
- 有时挂有时过 → **不稳定**（flaky）。把它当"确定的失败"会让人去改一个根本没坏的提交；
  反过来把它的失败当"没事"又会漏掉真问题——两种都不诚实。正确做法是**如实记为不确定**，
  连同样本一起记下来，并**保留**这个测试（不自动剔除、不自动跳过）。

同一层次的还有**运行错误**：夹具/环境报错、收集失败、被取消/超时。它们都不是"测试断言失败"，
但同样会让一次运行变红。TF-0014 的验收第 1 条要求这三类**分别记录**——本模块把它们分成
`assertion-failure` / `environment-error` / `collection-error` / `cancelled` 四种逐测试观测类型。

## 入口

```bash
# 用仓库 + 目标版本：内部走 plan_request 的同一条"确认 + 规划"链路，再重复执行 N 次
python -m smart_sorter.stability --repo <仓库> [--target WORKTREE|<commit>] \
    [--test-dir tests] [--repeat N] [--full] [--timeout SEC] [--out report.json]
# 或者消费一份已有计划
python -m smart_sorter.stability --plan <plan.json> --cwd <分析根> [--repeat N] [--full]
```

`--full` 表示重复观测计划的 `collected` 全集（而不是 `order` 选中集）——**要判断一个测试
稳不稳定，必须先真的反复跑到它**；被选择排除的测试只有用 `--full` 才观测得到。

## 报告不是新的对外协议

`schema = smart-test-sorter/stability-report/v1` 是**本产品自己的验证产物**，不进 VG—STS 契约：
契约里只有 request/plan/result/refusal 四个对象，`execution_result` 的 `additionalProperties`
是 false，没有地方放"重复运行不一致"这件事。所以本报告把每次重复的 `execution_result`
**原样内嵌**（它们仍是合法契约对象），不稳定证据只活在本报告里。

## 退出码

| 退出码 | 含义 |
| --- | --- |
| `0` | 报告已产出：所有重复都有效且跑完，每个测试的观测**一致**、**没有确定失败**、也没有运行错误 |
| `1` | 报告已产出：检出**确定失败**（每次都断言失败）、**不稳定**或**运行错误** |
| `3` | 报告已产出但**判不了**：有运行无效/未跑完，或有测试没被每次重复观测到 |
| `2` | 用法或输入错误 |

优先级 `3 > 1 > 0`：先承认"这次观测不足以作结论"，再谈有没有确定失败/不稳定。
注意 `0` 的苛刻条件：一个测试每次都断言失败时退出码是 **1**，不是 0——"一致"不等于"没问题"。

## 诚实边界（写清，不夸大）

- 重复次数由调用方给（默认 3）。`N` 次一致**不等于**"这个测试稳定"，只说明**这 N 次**一致；
  报告里 `samples` 与 `repeats` 都写出来，读的人自己判断样本够不够。
- 判定"不稳定"只依据**同一目标版本**（`target_identity`）下的观测；跨版本的历史失败可能来自
  真实的修复/回归，不能直接当不稳定。`--history-xml-dir` 给的历史证据因此**只用于降级**
  （把"确定的回归证据"降为"不确定"），**永不**用来把失败洗成通过。
- 本模块不负责"自动重跑直到通过"这类重试策略：重试会掩盖真实的确定性失败，本产品不做。
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from smart_sorter import (__version__, collect, contract_trees, contracts, history,
                        plan_request, run_plan)

SCHEMA = "smart-test-sorter/stability-report/v1"

_EXIT_OK = 0
_EXIT_INSTABILITY = 1
_EXIT_USAGE = 2
_EXIT_UNDECIDABLE = 3

DEFAULT_REPEATS = 3

# ---- 逐测试单次观测的类型（验收第 1 条：三类失败分别记录） ---------------------

KIND_PASSED = "passed"
KIND_SKIPPED = "skipped"
KIND_ASSERTION = "assertion-failure"      # 测试断言失败（call 阶段 failed）
KIND_ENVIRONMENT = "environment-error"    # 夹具/setup-teardown 报错（环境问题，不是断言）
KIND_COLLECTION = "collection-error"      # 收集阶段失败：测试根本没被收集/加载
KIND_CANCELLED = "cancelled"              # 未跑完（取消/超时/预算耗尽/被中止）
KIND_NOT_RUN_INVALID = "not-run-invalid"  # 计划失效（目标漂移/计划过期）⇒ 拒绝执行
KIND_NOT_RUN = "not-run"                  # 跑完了但这条就是没跑到（异常路径）
KIND_UNKNOWN = "unknown"

_OBSERVATION_LABELS = {
    KIND_PASSED: "通过",
    KIND_SKIPPED: "跳过",
    KIND_ASSERTION: "断言失败",
    KIND_ENVIRONMENT: "环境/夹具失败",
    KIND_COLLECTION: "收集失败",
    KIND_CANCELLED: "未跑完（取消/超时/中止）",
    KIND_NOT_RUN_INVALID: "计划失效未执行",
    KIND_NOT_RUN: "未执行",
    KIND_UNKNOWN: "无法判读",
}

# ---- 多次观测汇合后的判决 ----------------------------------------------------

V_STABLE_PASS = "stable-pass"
V_STABLE_SKIP = "stable-skip"
V_STABLE_FAIL = "stable-fail"
V_FLAKY = "flaky"
V_ENVIRONMENT = "environment-error"
V_COLLECTION = "collection-error"
V_CANCELLED = "cancelled"
V_NOT_RUN_INVALID = "not-run-invalid"
V_NOT_RUN = "not-run"
V_INDETERMINATE = "indeterminate"
V_UNDER_OBSERVED = "under-observed"

#: 这些判决**都不能**当成"确定的合并回归证据"（可能挂、可能没挂、或者根本不是断言失败）。
NOT_DEFINITE_VERDICTS = frozenset({
    V_FLAKY, V_ENVIRONMENT, V_COLLECTION, V_CANCELLED, V_STABLE_SKIP,
    V_NOT_RUN_INVALID, V_NOT_RUN, V_INDETERMINATE, V_UNDER_OBSERVED,
})

#: 只有这些判决是"确实观测到了某种非断言失败"，才可以据此把别人的确定失败**降级**。
#: `cancelled` / `not-run` / `not-run-invalid` / `under-observed` 属于"什么都没观测到"，
#: 拿它们给失败开脱就等于"没有证据也降级"——本产品不做（见 load_evidence）。
POSITIVE_EVIDENCE_VERDICTS = frozenset({V_FLAKY, V_INDETERMINATE, V_ENVIRONMENT, V_COLLECTION})

#: 只有它算确定证据：每次都断言失败。
DEFINITE_VERDICT = V_STABLE_FAIL

_VERDICT_LABELS = {
    V_STABLE_PASS: "每次重复都通过",
    V_STABLE_SKIP: "每次重复都跳过（没有真正执行过）",
    V_STABLE_FAIL: "每次重复都断言失败（确定的失败）",
    V_FLAKY: "重复运行结果不一致（时过时挂）",
    V_ENVIRONMENT: "每次都是环境/夹具失败，不是断言失败",
    V_COLLECTION: "每次都收集失败，测试根本没被加载",
    V_CANCELLED: "每次都被取消/超时，没跑到",
    V_NOT_RUN_INVALID: "计划失效而未被执行（结果不成立）",
    V_NOT_RUN: "跑完了但这条测试未被观测到",
    V_INDETERMINATE: "观测混杂（既有通过也有运行错误等），判不了",
    V_UNDER_OBSERVED: "重复次数内没有每次都观测到这条测试",
}


def observe(run: dict, node_id: str, repeat: int) -> dict:
    """从一份 execution_result 里取出"第 repeat 次重复中这条测试发生了什么"。

    判定顺序写死：**先看逐测试事实**（有就是有），再看运行级的三类失败——
    收集失败 > 计划失效 > 未跑完（取消/超时）> 其余未执行。顺序反了就会把
    "计划失效导致全都没跑"错记成"每条测试各自没跑到"。
    """
    facts = (run.get("outcomes") or {}).get(node_id)
    if isinstance(facts, dict):
        outcome = facts.get("outcome")
        kind = {
            "passed": KIND_PASSED,
            "failed": KIND_ASSERTION,
            "error": KIND_ENVIRONMENT,
            "skipped": KIND_SKIPPED,
        }.get(outcome, KIND_UNKNOWN)
        return {
            "run": repeat,
            "kind": kind,
            "outcome": outcome,
            "phases": list(facts.get("phases") or []),
            "duration_s": round(float(facts.get("duration_s") or 0.0), 6),
        }

    categories = run.get("failure_categories") or {}
    if int(categories.get("collection") or 0) > 0:
        kind = KIND_COLLECTION
    elif run.get("validity") != "valid":
        kind = KIND_NOT_RUN_INVALID
    elif run.get("completeness") != "complete":
        kind = KIND_CANCELLED
    else:
        kind = KIND_NOT_RUN
    return {"run": repeat, "kind": kind, "outcome": None, "phases": [], "duration_s": 0.0}


def verdict_for(observations: list[dict], repeats: int) -> str:
    """把同一条测试的多次观测汇合成一个判决。纯函数，规则一眼可查。"""
    kinds = [o["kind"] for o in observations]
    # 一次观测都没有（或少于声称的重复次数）⇒ 判"没观测够"。
    # 注意 `0 < 0` 是 False：不特判空列表的话，"零重复"会被真空地判成"每次都通过"。
    if not kinds or len(kinds) < repeats:
        return V_UNDER_OBSERVED
    distinct = set(kinds)
    if distinct == {KIND_SKIPPED}:
        # 每次都跳过 ⇒ 从没真正执行过，不能算"每次重复都通过"。
        return V_STABLE_SKIP
    if distinct <= {KIND_PASSED, KIND_SKIPPED}:
        return V_STABLE_PASS
    if distinct == {KIND_ASSERTION}:
        return V_STABLE_FAIL
    if distinct == {KIND_ENVIRONMENT}:
        return V_ENVIRONMENT
    if distinct == {KIND_COLLECTION}:
        return V_COLLECTION
    if distinct == {KIND_CANCELLED}:
        return V_CANCELLED
    if distinct == {KIND_NOT_RUN_INVALID}:
        return V_NOT_RUN_INVALID
    if distinct == {KIND_NOT_RUN}:
        return V_NOT_RUN
    # 时过时挂：最典型的不稳定，也包含"过 + 运行错误"这种混杂。
    if KIND_ASSERTION in distinct and distinct & {KIND_PASSED, KIND_SKIPPED}:
        return V_FLAKY
    return V_INDETERMINATE


def _reason(node_id: str, verdict: str, observations: list[dict], repeats: int) -> str:
    counts: dict[str, int] = {}
    for obs in observations:
        counts[obs["kind"]] = counts.get(obs["kind"], 0) + 1
    detail = "、".join(
        f"{_OBSERVATION_LABELS.get(kind, kind)}×{count}"
        for kind, count in sorted(counts.items())
    )
    base = f"{_VERDICT_LABELS[verdict]}（{repeats} 次重复：{detail or '无观测'}）"
    if verdict == V_STABLE_FAIL:
        return base + " ⇒ 可作为确定的回归证据"
    if verdict in NOT_DEFINITE_VERDICTS:
        return base + " ⇒ **不能**当作确定的合并回归证据"
    return base


def classify_runs(
    plan_doc: dict,
    runs: list[dict],
    *,
    expected: list[str],
    repeats: int | None = None,
    recorded_at: str | None = None,
    history_dir: str | None = None,
) -> dict:
    """把 N 份 execution_result 汇成一份稳定性报告（纯函数，便于单测）。"""
    repeats = len(runs) if repeats is None else repeats
    tests: dict[str, dict] = {}
    for node_id in expected:
        observations = [observe(run, node_id, index + 1) for index, run in enumerate(runs)]
        verdict = verdict_for(observations, repeats)
        tests[node_id] = {
            "verdict": verdict,
            "reason": _reason(node_id, verdict, observations, repeats),
            "samples": observations,
            "counts": _count_kinds(observations),
            # 不自动丢弃：不稳定/报错的测试仍然留在计划与收集集合里。
            "retain": True,
        }

    # 历史不一致（JUnit 里失败率在 0 与 1 之间）只做"降级"：把本来会被当成确定证据的那条
    # 改成"不确定"，绝不把失败洗成通过、也绝不把通过改成失败。
    historical = flaky_from_history(history_dir) if history_dir else {}
    # 只降级**本次真的观测过**的测试：历史里提到的、计划外的测试不能凭空进报告
    # （否则它们会出现在保留清单、甚至把 instability 判成 True）。
    history_only = {n: r for n, r in historical.items() if n not in tests}
    for node_id in sorted(set(historical) & set(tests)):
        reason = historical[node_id]
        record = tests[node_id]
        record["history_note"] = reason
        if record["verdict"] not in NOT_DEFINITE_VERDICTS:
            record["verdict"] = V_INDETERMINATE
            record["reason"] = f"{record['reason']}；{reason}"

    verdict_counts: dict[str, int] = {}
    for record in tests.values():
        verdict_counts[record["verdict"]] = verdict_counts.get(record["verdict"], 0) + 1

    definite = sorted(n for n, r in tests.items() if r["verdict"] == DEFINITE_VERDICT)
    not_evidence = [
        {"nodeid": node_id, "verdict": tests[node_id]["verdict"], "reason": tests[node_id]["reason"]}
        for node_id in sorted(tests)
        if tests[node_id]["verdict"] in NOT_DEFINITE_VERDICTS
    ]

    instability = any(
        r["verdict"] in {V_FLAKY, V_INDETERMINATE, V_UNDER_OBSERVED} for r in tests.values()
    )
    run_errors = any(
        any(o["kind"] in {KIND_ENVIRONMENT, KIND_COLLECTION, KIND_CANCELLED, KIND_NOT_RUN_INVALID}
            for o in r["samples"])
        for r in tests.values()
    )
    runs_clean = bool(runs) and all(
        run.get("validity") == "valid" and run.get("completeness") == "complete" for run in runs
    )
    # 空观测（没有重复、或计划里一条可执行 nodeid 都没有）绝不能算"干净"：
    # "什么都没看"与"看了都没问题"是两件事，后者才配退出码 0。
    undecidable = (
        (not runs)
        or (not expected)
        or (not runs_clean)
        or any(
            r["verdict"] in {V_UNDER_OBSERVED, V_NOT_RUN, V_NOT_RUN_INVALID}
            for r in tests.values()
        )
    )

    report: dict = {
        "schema": SCHEMA,
        "product_version": f"smart-test-sorter/{__version__}",
        "recorded_at": recorded_at or _utc_now(),
        "target_identity": plan_doc["target_identity"],
        "plan_id": plan_doc["plan_id"],
        "request_id": plan_doc["request_id"],
        "rules_id": (plan_doc["policy_identity"]["rules_id"]
                     if plan_doc.get("protocol_version") == "2.0" else plan_doc["rules_id"]),
        "selection_scope": plan_doc["selection_scope"],
        "repeats": repeats,
        "observed": list(expected),
        "observed_scope": plan_doc.get("_observed_scope", "selected"),
        "tests": tests,
        "summary": {
            "tests": len(expected),
            "repeats": repeats,
            "runs_valid_and_complete": runs_clean,
            "verdict_counts": verdict_counts,
            "instability_detected": instability,
            "run_errors_detected": run_errors,
            "definite_failures": len(definite),
            "not_definite": len(not_evidence),
            "undecidable": undecidable,
        },
        "regression_evidence": {
            "definite_failures": definite,
            "definite_failures_rule": (
                "只有【每次重复都断言失败】才算确定的失败；单次失败、时过时挂、"
                "环境/收集/取消类失败都不算。"
            ),
            "not_evidence": not_evidence,
            "retention": {
                "policy": "never-auto-discard",
                "retained": sorted(tests),
                "note": (
                    "不稳定/报错的测试一律保留在计划与收集集合里（retain=true）："
                    "本模块只记录不稳定，不据此剔除、跳过或重试测试。"
                ),
            },
        },
        "history": {
            "source": history_dir,
            "not_definite": historical,
            "outside_plan": history_only,
            "note": (
                "JUnit 历史只能分清 pass/fail（不区分断言与环境错误），且跨版本的失败可能来自"
                "真实修复/回归。因此历史只用于**降级**为「不确定」，永不用于把失败改判为通过。"
                if history_dir else None
            ),
        },
        "runs": runs,
        "contract_note": (
            "本报告是本产品自己的验证产物（不进 VG—STS 契约）：契约 execution_result 只有"
            "单次运行的事实，没有地方放「重复运行不一致」；这里把每次重复的 execution_result "
            "原样内嵌，契约仍逐份成立。"
        ),
    }
    if plan_doc.get("_observed_scope") == "full":
        report["scope_note"] = "观测的是计划的 collected 全集（--full）：被选择排除的测试也因此被观测到。"
    return report


def _count_kinds(observations: list[dict]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for obs in observations:
        counts[obs["kind"]] = counts.get(obs["kind"], 0) + 1
    return counts


def flaky_from_history(xml_dir: str) -> dict[str, str]:
    """从 JUnit 历史里找出"既有失败也有通过"的测试，返回 nodeid -> 原因。

    失败率严格落在 (0, 1) 之间才叫历史不一致：0 是全过（没有证据）、1 是全败
    （是确定的失败，不是不稳定）。只有一个 XML 时永远拿不到 flaky——样本不够。
    """
    rates = history.build_failure_history(xml_dir)
    out: dict[str, str] = {}
    for node_id, rate in sorted(rates.items()):
        if 0.0 < rate < 1.0:
            out[node_id] = (
                f"历史 JUnit 里失败率 {rate:.0%}（既非全过也非全败）⇒ 历史不一致，"
                "其失败不作为确定的合并回归证据"
            )
    return out


def _read_json_object(path: str) -> dict:
    """读一个 JSON 文件并要求顶层是对象；不是就响亮报错（本模块不接受"看不懂就当空"）。"""
    doc = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(doc, dict):
        raise ValueError(f"{path} 顶层必须是 JSON 对象（实际 {type(doc).__name__}）")
    return doc


def load_evidence(paths: list[str]) -> dict:
    """读若干稳定性报告，返回**带来源与目标版本**的证据。

    shadow 用它把"全量里失败"降级，但资格很严：

    1. 只有**确实观测到某种非断言失败**的判决才算证据（`POSITIVE_EVIDENCE_VERDICTS`：
       flaky / indeterminate / environment-error / collection-error）；
       `not-run` / `not-run-invalid` / `under-observed` / `cancelled` 都是"什么都没观测到"，
       拿它们给失败开脱等于"没有证据也降级"。
    2. 每条来源都带自己的 `target_identity`，调用方（shadow）再按"同一目标版本"过滤：
       跨版本的证据不能给当前失败开脱。
    """
    by_source: list[dict] = []
    merged: dict[str, str] = {}
    sources: list[str] = []
    for path in paths:
        doc = _read_json_object(path)
        if doc.get("schema") != SCHEMA:
            raise ValueError(
                f"{path} 不是 {SCHEMA}（实际 {doc.get('schema')!r}）；"
                "拒绝用不认识的文件给失败开脱"
            )
        tests = doc.get("tests") or {}
        if not isinstance(tests, dict):
            raise ValueError(f"{path} 的 tests 必须是对象（实际 {type(tests).__name__}）")
        sources.append(str(path))
        found: dict[str, str] = {}
        for node_id, record in tests.items():
            if not isinstance(record, dict):
                raise ValueError(f"{path} 的 tests[{node_id!r}] 必须是对象")
            verdict = record.get("verdict")
            if verdict in POSITIVE_EVIDENCE_VERDICTS:
                reason = f"{verdict}（证据：{path}）"
                found[node_id] = reason
                merged[node_id] = reason
        by_source.append({
            "path": str(path),
            "target_identity": doc.get("target_identity"),
            "not_definite": found,
        })
    return {"not_definite": merged, "sources": sources, "by_source": by_source}


def run_stability(
    plan_doc: dict,
    *,
    root: str,
    test_dir: str = "tests",
    repeats: int = DEFAULT_REPEATS,
    timeout_s: int | None = None,
    full: bool = False,
    request: dict | None = None,
    recorded_at: str | None = None,
    history_dir: str | None = None,
    log=lambda message: None,
) -> tuple[str, dict]:
    """每次用独立解释器执行固定计划，避免复用已消耗的参数或插件状态。"""
    expected = list(plan_doc["collected"] if full else plan_doc["order"])
    runs: list[dict] = []
    for index in range(repeats):
        log(f"第 {index + 1}/{repeats} 次执行（{'collected 全集' if full else 'order 选中集'}，{len(expected)} 个）……")
        kind, doc = run_plan.execute_plan(
            plan_doc, root=root, test_dir=test_dir, timeout_s=timeout_s,
            full=full, request=request, isolated=True, log=log,
        )
        if kind != "result":
            return "error", doc
        runs.append(doc)

    observed = dict(plan_doc)
    observed["_observed_scope"] = "full" if full else "selected"
    report = classify_runs(
        observed, runs, expected=expected, repeats=repeats,
        recorded_at=recorded_at, history_dir=history_dir,
    )
    report["fresh_interpreter_per_repeat"] = True
    return "report", report


def run_from_repo(
    repo: str,
    *,
    target: str,
    test_dir: str = "tests",
    repeats: int = DEFAULT_REPEATS,
    timeout_s: int | None = None,
    full: bool = False,
    xml_dir: str | None = None,
    history_dir: str | None = None,
    plan_id: str | None = None,
    recorded_at: str | None = None,
    log=lambda message: None,
) -> tuple[str, dict]:
    """由「仓库 + 目标」出计划再重复观测（计划仍由 plan_request 的同一链路产出）。"""
    repo = str(Path(repo).resolve())
    request = plan_request.build_target_request(repo, target, request_id="stability")
    kind, plan_doc = plan_request.process_request(
        request, test_dir=test_dir, xml_dir=xml_dir, plan_id=plan_id, log=log
    )
    if kind != "plan":
        return "error", {
            "ok": False,
            "error_kind": plan_doc.get("refusal_code", "input-error"),
            "reason": plan_doc.get("reason", "无法生成计划"),
            "refusal": plan_doc,
        }
    return run_stability(
        plan_doc, root=repo, test_dir=test_dir, repeats=repeats, timeout_s=timeout_s,
        full=full, request=request, recorded_at=recorded_at, history_dir=history_dir, log=log,
    )


def exit_code_for(report: dict) -> int:
    """退出码口径：判不了(3) > 有确定失败/不稳定/运行错误(1) > 干净(0)。

    注意 `0` 的条件很苛刻：一个测试每次都断言失败时退出码是 **1**——
    "观测一致"不等于"没问题"，否则只看 `$?` 的调用方会在**恰好存在确定回归证据**时看到绿灯。
    """
    summary = report["summary"]
    if summary["undecidable"]:
        return _EXIT_UNDECIDABLE
    if (
        summary["definite_failures"]
        or summary["instability_detected"]
        or summary["run_errors_detected"]
    ):
        return _EXIT_INSTABILITY
    return _EXIT_OK


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="smart_sorter.stability",
        description="重复执行同一目标版本的测试计划，记录不稳定测试与运行错误（不改判失败、不丢弃测试）。",
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--repo", default=None, help="目标仓库路径（内部出计划后重复观测）")
    source.add_argument("--plan", default=None, help="已有 test_plan JSON（与 --cwd 一起用）")
    parser.add_argument("--cwd", default=None, help="分析根（--plan 模式必给）；nodeid 相对它")
    parser.add_argument("--target", default="WORKTREE",
                        help="--repo 模式的分析目标：WORKTREE（默认）或某个 commit-ish")
    parser.add_argument("--test-dir", default="tests", help="仓库内测试目录名，默认 tests")
    parser.add_argument("--repeat", type=int, default=DEFAULT_REPEATS,
                        help=f"重复执行次数，默认 {DEFAULT_REPEATS}（必须 ≥1）")
    parser.add_argument("--full", action="store_true",
                        help="观测计划的 collected 全集（要判断被选择排除的测试稳不稳定就得用它）")
    parser.add_argument("--timeout", type=int, default=None,
                        help="每次执行的协作式预算秒数（在测试之间检查）")
    parser.add_argument("--out", default=None, help="把报告 JSON 写到该文件（stdout 仍输出同一份）")
    parser.add_argument("--recorded-at", default=None, help="显式指定报告时间戳（UTC ISO），便于可复现证据")
    parser.add_argument("--xml-dir", default=None, help="可选历史 JUnit XML 目录（只参与排序加权）")
    parser.add_argument("--history-xml-dir", default=None,
                        help="可选历史 JUnit XML 目录：其中的历史不一致只用于把失败降级为不确定")
    return parser


def main(argv: list[str] | None = None) -> int:
    plan_request._force_utf8_output()
    args = build_parser().parse_args(argv)

    def log(message: str) -> None:
        print(f"[stability] {message}", file=sys.stderr)

    if args.repeat < 1:
        return _usage_error(f"--repeat 必须 ≥1（给的是 {args.repeat}）")

    try:
        if args.repo:
            if not Path(args.repo).is_dir():
                return _usage_error(f"目标仓库不存在或不是目录 -> {args.repo}")
            kind, doc = run_from_repo(
                args.repo, target=args.target, test_dir=args.test_dir, repeats=args.repeat,
                timeout_s=args.timeout, full=args.full, xml_dir=args.xml_dir,
                history_dir=args.history_xml_dir, recorded_at=args.recorded_at, log=log,
            )
        else:
            root = str(Path(args.cwd or ".").resolve())
            if not Path(root).is_dir():
                return _usage_error(f"分析根不存在或不是目录 -> {root}")
            try:
                plan_doc = json.loads(Path(args.plan).read_text(encoding="utf-8"))
            except FileNotFoundError:
                return _usage_error(f"计划文件不存在 -> {args.plan}")
            except (OSError, json.JSONDecodeError) as exc:
                return _usage_error(f"计划文件不可读 -> {args.plan}：{exc}")
            if not isinstance(plan_doc, dict):
                return _usage_error("计划文件顶层必须是 JSON 对象")
            # 版本门走 `contract_trees` 单点（2026-10-04）。原先这里写死
            # `contracts.SUPPORTED_PROTOCOL_VERSIONS`（只认 1.0/1.1）⇒ 2.0 计划被拒；
            # 与 `run_plan`/`plan_request` 那两处同类。**版本路由不许散落在各入口。**
            plan_version = plan_doc.get("protocol_version")
            try:
                contract_trees.tree_for(plan_version, producing=True)
            except contract_trees.UnsupportedProtocol as exc:
                return _usage_error(
                    f"计划的协议版本 {plan_version!r} 不受支持（本实现支持 "
                    f"{sorted(contract_trees.SUPPORTED_TREES)}），拒绝而非静默兼容：{exc}"
                )
            plan_errors = (contracts.validate(plan_doc, "plan") if plan_version == "1.1"
                           else contract_trees.validate_against(plan_doc, "plan", plan_version))
            if plan_errors:
                return _usage_error(f"计划不符合 {plan_version} 契约：" + "；".join(plan_errors))
            kind, doc = run_stability(
                plan_doc, root=root, test_dir=args.test_dir, repeats=args.repeat,
                timeout_s=args.timeout, full=args.full, recorded_at=args.recorded_at,
                history_dir=args.history_xml_dir, log=log,
            )
    except (ValueError, OSError) as exc:
        return _usage_error(str(exc))

    if kind == "error":
        if doc.get("error_kind") == "input-error":
            return _usage_error(doc["reason"])
        text = json.dumps(doc, ensure_ascii=False, indent=2)
        if args.out:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
        print(text)
        log(f"无法观测：{doc['reason']}")
        return _EXIT_UNDECIDABLE

    text = json.dumps(doc, ensure_ascii=False, indent=2)
    if args.out:
        try:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
        except OSError as exc:
            return _usage_error(f"无法写出 {args.out}：{exc}")
        log(f"已写出 {args.out}")
    print(text)

    summary = doc["summary"]
    log(
        f"target={doc['target_identity']} plan={doc['plan_id']} repeats={doc['repeats']} "
        f"tests={summary['tests']} 不稳定={summary['instability_detected']} "
        f"运行错误={summary['run_errors_detected']} 确定失败={summary['definite_failures']} "
        f"不确定={summary['not_definite']}"
    )
    return exit_code_for(doc)


def _usage_error(reason: str) -> int:
    print(f"[stability] 错误：{reason}", file=sys.stderr)
    print(json.dumps(
        {"ok": False, "error_kind": "input-error", "reason": reason}, ensure_ascii=False,
    ))
    return _EXIT_USAGE


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
