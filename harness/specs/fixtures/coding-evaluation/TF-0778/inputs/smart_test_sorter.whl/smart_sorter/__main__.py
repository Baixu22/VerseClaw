"""让 `python -m smart_sorter ...` 可运行。"""

from __future__ import annotations

from smart_sorter.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
