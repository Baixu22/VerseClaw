"""统一的变更来源（change source）：把"分析哪一版改动"抽象成一个对象。

STS 早期只能分析【历史 commit】（parent.diff(commit)），但调用图/函数索引始终从
【当前工作区磁盘】构建。二者口径可能不一致，且用户"刚改完还没 commit"就想选测试的
日常场景无法覆盖。本模块统一两种目标：

  - commit 模式：分析某次历史提交相对其父提交的改动（old=父树, new=commit 树）。
    等价于旧的 parent.diff(commit)，向后兼容。
  - worktree 模式（哨兵 WORKTREE）：分析【工作区未提交改动】相对 HEAD——staged +
    unstaged + untracked（old=HEAD 树, new=磁盘文件）。这正是调用图所基于的版本，
    因此 worktree 模式下 diff 与依赖图口径天然一致。
  - candidate 模式（resolve_candidate）：分析 VG 已【物化】的候选合并目录——old=base 树，
    new=候选目录磁盘。变更集取【两侧改动并集】base→ours ∪ base→theirs ∪ 候选额外变化，
    绝不只比合并提交的第一父（那会漏掉另一侧）。候选额外的冲突解决改动（含两侧都没碰过的
    文件）按"候选目录磁盘 vs base 树"逐文件复算。

ast_diff 与 safety 的 git 读取都收敛到这里，不再各自 parent.diff(commit)。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path, PurePosixPath

import git

# 目标哨兵：分析工作区未提交改动（相对 HEAD），而非某个具体 commit。
WORKTREE = "WORKTREE"

# ---- candidate 模式的【目标身份口径】（TF-0027 写死，VG 按此核对绑定）--------
#
# 候选内容身份由候选 tree OID 唯一确定（候选目录只作定位）。计划/结果/无法规划回执里
# 的 target_identity 一律写作：
#
#     candidate@<candidate_tree_oid 的前 7 位小写十六进制>
#
# 例如 tree OID ddddddd000111222333444555666777888999abc -> "candidate@ddddddd"。
# 与契约夹具 contracts/vg-sts/v1/samples/pairs/valid/matched/plan.json 完全一致，
# 因此 VG 可以把绑定核对从"只有 request_id 一条锚点"升级为
#   plan.target_identity == candidate_identity(request.target.candidate_tree_oid)
CANDIDATE_IDENTITY_PREFIX = "candidate@"
CANDIDATE_TREE_OID_CHARS = 7


def candidate_identity(tree_oid: str) -> str:
    """candidate 模式的目标身份：'candidate@' + tree OID 前 7 位【小写】十六进制。

    只取 7 位是契约夹具定的口径（短到够用、长到足够避免碰撞），大小写统一小写，
    使同一候选在任何平台/任何输入写法下产生同一个 target_identity 字符串。
    """
    return f"{CANDIDATE_IDENTITY_PREFIX}{tree_oid.strip().lower()[:CANDIDATE_TREE_OID_CHARS]}"

# 未跟踪文件里要忽略的构建产物/环境目录。pytest 一跑就会生成 __pycache__/*.pyc，
# 若把它们当成"未提交改动"，worktree 模式会因"非 Python 文件改动"动辄回退全量，
# 使 --smart-select 形同虚设。这些目录本就该在 .gitignore 里，但不能假设用户配了；
# 与 call_graph._SKIP_DIRS 同源（那边扫描源码时也跳过它们）。
_NOISE_DIRS = {
    ".venv", "venv", "__pycache__", "node_modules", ".git",
    ".tox", ".pytest_cache", ".mypy_cache", "build", "dist",
    # 以下是"跑一次测试/装一次包就会长出来"的常见产物目录（2026-10-01 随 TF-0033 补齐）：
    # 不补齐就会在"没写 .gitignore"的项目上把干净的候选误判成不一致。
    ".nox", ".ruff_cache", ".hypothesis", ".benchmarks", "htmlcov",
    ".eggs", "site-packages",
}
_NOISE_SUFFIXES = {".pyc", ".pyo", ".pyd"}
#: 目录名带这些后缀的也算噪声（`*.egg-info/`、`*.dist-info/`）——按**路径里任意一段**判。
_NOISE_DIR_SUFFIXES = {".egg-info", ".dist-info"}
#: 单文件形态的生成物/覆盖率产物。
_NOISE_FILES = {".coverage", "coverage.xml", "junit.xml", "pip-wheel-metadata"}
# 生成物/环境噪声的**版本化身份**：排除规则本身也是有版本的行为，改了它就得能被指出来。
NOISE_POLICY_ID = "noise-dirs/v2"


@dataclass(frozen=True)
class DiffEntry:
    """一条文件级变更。change_type 用 git 的单字母口径，与 GitPython 对齐。

    'A' 新增 / 'M' 修改 / 'D' 删除 / 'R' 重命名。path 取新路径（删除时取旧路径）。
    """

    change_type: str
    path: str


class ChangeSource:
    """一个已解析的变更来源。上层通过它拿 diff 与新旧文件内容，不关心底层是 commit
    还是工作区。

    字段:
        kind         "commit" | "worktree" | "candidate"
        identity     结果指纹：commit 用 hexsha[:10]；worktree 用
                     "worktree@<HEAD[:10]>[+dirty:<n>]"；candidate 用
                     "candidate@<tree_oid[:7]>"（见 candidate_identity）。让"结果对应哪一版"
                     可追溯，并让 VG 能用固定口径核对绑定。
        has_baseline 是否存在可对比的旧版本。首个提交 / 空仓库为 False——上层据此按
                     "首个提交"回退全量，而不是把空 diff 误当成"没有改动、可安全跳过"。
        detail       人类可读的补充说明（如候选的 base/ours/theirs 与变更数）。只用于
                     describe()/日志，不参与身份判定。
    """

    def __init__(
        self,
        repo: git.Repo,
        kind: str,
        identity: str,
        has_baseline: bool,
        old_commit: git.Commit | None,
        new_commit: git.Commit | None,
        entries: list[DiffEntry],
        disk_root: str | None = None,
        detail: str = "",
    ) -> None:
        self._repo = repo
        self.kind = kind
        self.identity = identity
        self.has_baseline = has_baseline
        self._old_commit = old_commit  # 读旧内容的树；无 baseline 时为 None
        self._new_commit = new_commit  # commit 模式读新内容的树；worktree/candidate 模式为 None（读磁盘）
        self._entries = entries
        # 读"新内容"的磁盘根：worktree 模式为 None（用 repo 工作区）；candidate 模式为
        # VG 物化好的候选目录，因此候选文件可能不在 repo 工作区里。
        self._disk_root = disk_root
        self.detail = detail

    def diff_entries(self) -> list[DiffEntry]:
        """本次变更的文件级列表（已按路径排序、去重）。"""
        return list(self._entries)

    def read_old(self, path: str) -> str:
        """读旧版本某文件内容；不存在（如新增文件）或无 baseline 时返回空串。"""
        if self._old_commit is None:
            return ""
        return _read_tree(self._old_commit, path)

    def read_new(self, path: str) -> str:
        """读新版本某文件内容。

        commit 模式从 commit 树读；worktree/candidate 模式从【磁盘】读（这正是调用图所见
        的版本）。candidate 模式的磁盘根是 VG 物化的候选目录。文件不存在（如删除）返回空串。
        """
        if self._new_commit is not None:
            return _read_tree(self._new_commit, path)
        # worktree / candidate 模式：从磁盘读。
        root = self._disk_root or self._repo.working_tree_dir
        abs_path = Path(root) / path
        try:
            return abs_path.read_text(encoding="utf-8", errors="replace")
        except (FileNotFoundError, IsADirectoryError, OSError):
            return ""


def resolve(repo_path: str, target: "str | ChangeSource") -> ChangeSource:
    """把 (repo, target) 解析成 ChangeSource。

    target 为 WORKTREE 哨兵 -> 工作区模式；为 ChangeSource -> 原样返回（调用方已经解析
    好了，例如 TF-0027 的候选模式：base/ours/theirs 三条 OID 无法用一个字符串表达，
    因此由入口先 resolve_candidate，再把 ChangeSource 一路传给 safety/call_graph/scorer）；
    否则按 commit-ish 解析（短哈希、HEAD、tag…）。

    这条直通使"变更目标"在整条选择链上只有一个表示，宿主入口与 standalone CLI 走
    完全相同的下游代码——不存在给候选模式另写一套选择算法的可能。
    """
    if isinstance(target, ChangeSource):
        return target
    repo = git.Repo(repo_path)
    if target == WORKTREE:
        return _resolve_worktree(repo)
    return _resolve_commit(repo, target)


def describe(source: ChangeSource) -> str:
    """人类可读的目标描述，用于 CLI/插件头部，让用户知道"在分析哪一版"。"""
    if source.kind == "worktree":
        # identity 形如 "worktree@<HEAD>[+dirty:n]"，这里只取 HEAD 短哈希部分。
        base = source.identity.split("@", 1)[-1].split("+", 1)[0]
        return f"工作区未提交改动（基于 HEAD {base}）"
    if source.kind == "candidate":
        extra = f"；{source.detail}" if source.detail else ""
        return f"候选合并目录（{source.identity}{extra}）"
    return f"提交 {source.identity}"


def resolve_candidate(
    repo_path: str,
    base: str,
    ours: str,
    theirs: str,
    candidate_dir: str,
    *,
    tree_oid: str,
    include_candidate_extras: bool = True,
) -> ChangeSource:
    """candidate 模式：分析 VG 已【物化】的候选合并目录。

    这是 TF-0019/TF-0027 的候选来源，供 VG 通过 TF-0026 契约传入 base/ours/theirs 三个 OID
    与一个已物化好的候选工作目录。STS 只在该指定目录上分析/收集，绝不重新合并、不退回 STS
    源码目录或默认 HEAD。

    变更集 = 【两侧改动并集】base→ours ∪ base→theirs，**再加候选额外变化**：

    * 两侧并集是与"只比合并提交第一父"最关键的区别——只比一侧会把另一侧的改动整段漏掉；
    * 候选额外变化 = 候选目录磁盘上存在、但两侧并集没提到的文件，且其内容与 base 树不同
      （base 里没有 => 新增；base 里有但内容不同 => 修改）。冲突解决时动到"两侧都没碰过的
      文件"这种情况只有靠这一步才能看见。识别按磁盘遍历 + 与 base blob 比较（Python 源码统一 CRLF/LF），可独立
      复算，不依赖 VG 私有元数据。

    参数:
        tree_oid:  候选内容身份（candidate_tree_oid，或由 candidate_commit_oid 推出的树 OID）。
                   **必填**——候选目录只是定位，内容身份必须用 tree OID 唯一确定，否则
                   plan/result 的 target_identity 无从核对。
        include_candidate_extras: 是否扫描候选目录识别额外变化（默认开）。宿主入口开启；
                   只想做"两侧并集"的窄用例（如单元测试）可关掉。

    read_old 取 base 树，read_new 取候选目录磁盘（候选对冲突的额外解决改动体现在磁盘内容里，
    因此按并集里的文件读磁盘即得到实际候选版本）。

    能力边界（如实声明）：本函数能识别候选目录相对 base 的额外**新增/修改**，但候选目录若被
    VG 物化成**部分目录**，缺失文件不会被误报为删除（只遍历磁盘实际存在的文件）；候选目录与
    tree OID 的**内容等价性**是否可核对取决于该目录是否为该 repo 的 git worktree——
    这由宿主入口（plan_request.confirm_target）判定，不在本函数臆测。
    """
    repo = git.Repo(repo_path)
    base_commit = repo.commit(base)
    ours_commit = repo.commit(ours)
    theirs_commit = repo.commit(theirs)

    # 两侧并集：base→ours ∪ base→theirs。合并去重、按路径排序，输出稳定。
    union = _merge_entries(
        _entries_from_diff(base_commit.diff(ours_commit))
        + _entries_from_diff(base_commit.diff(theirs_commit))
    )
    extras: list[DiffEntry] = []
    if include_candidate_extras:
        extras = _candidate_extra_entries(base_commit, union, candidate_dir)
    entries = _merge_entries(union + extras)

    identity = candidate_identity(tree_oid)
    detail = (
        f"base={base[:10]} ours={ours[:10]} theirs={theirs[:10]} "
        f"tree={tree_oid.strip().lower()[:CANDIDATE_TREE_OID_CHARS]} "
        f"union_files={len(union)} candidate_extra_files={len(extras)} changed={len(entries)}"
    )
    return ChangeSource(
        repo,
        "candidate",
        identity,
        has_baseline=True,
        old_commit=base_commit,
        new_commit=None,          # 新内容读候选目录磁盘
        entries=entries,
        disk_root=candidate_dir,  # 候选目录可能不在 repo 工作区内
        detail=detail,
    )


def candidate_base_problem(repo, base: str, ours: str, theirs: str) -> str | None:
    """声明的 `base` 是否**就是** ours/theirs 的合并基点；不是就返回可读原因，是则 None。

    为什么这要单独判：候选的改动集是 `base→ours ∪ base→theirs`。只有 base 真的是合并基点时，
    这个并集才等于"这次候选带来的改动"。两种偏差都会让改动面失去意义：

    * base 比真正的合并基点**更旧**（仍是共同祖先）⇒ 并集混进更早的历史改动；
    * base **不是**共同祖先（例如指到另一条分支上）⇒ 并集没有明确含义。

    两者都**无法界定改动面**。按本仓一贯口径：目标身份仍可信 ⇒ 不拒绝，而是**保守全量**，
    并在 fallback 原因里写清这次为什么界定不了（见 `plan_request` 的 `conservative_fallback`）。

    参数都是可解析的 OID（可解析性由调用方在更早一步确认）。
    """
    base_commit = repo.commit(base)
    merge_bases = {c.hexsha for c in repo.merge_base(ours, theirs)}
    if base_commit.hexsha in merge_bases:
        return None
    if not merge_bases:
        return (
            f"ours_oid={ours[:12]} 与 theirs_oid={theirs[:12]} 没有共同祖先，"
            f"合并基点无从定义（请求声明的 base_oid={base[:12]}）⇒ 改动面无法界定"
        )
    actual = sorted(merge_bases)[0][:12]
    if repo.is_ancestor(base_commit, ours) and repo.is_ancestor(base_commit, theirs):
        return (
            f"请求声明的 base_oid={base[:12]} 是两侧的共同祖先、但**不是合并基点**"
            f"（真正的合并基点是 {actual}）⇒ base→两侧的并集会混进更早的历史改动，改动面无法界定"
        )
    return (
        f"请求声明的 base_oid={base[:12]} 不是 ours/theirs 的共同祖先"
        f"（真正的合并基点是 {actual}）⇒ base→两侧的并集没有明确含义，改动面无法界定"
    )


def _candidate_extra_entries(
    base_commit: git.Commit, union: list[DiffEntry], candidate_dir: str
) -> list[DiffEntry]:
    """候选目录相对 base 的额外新增/修改（两侧并集之外的文件）。

    只遍历候选目录里【磁盘上真实存在】的 .py 文件，因此候选目录不完整也不会误报删除。
    噪声目录（.venv/__pycache__/.git/...）按 _is_noise 跳过，且遍历时就剪枝。
    """
    known = {e.path for e in union}
    root = Path(candidate_dir)
    if not root.is_dir():
        return []
    out: list[DiffEntry] = []
    for abs_path in _iter_py_files_pruned(root):
        rel = abs_path.relative_to(root).as_posix()
        if rel in known:
            continue
        try:
            disk = abs_path.read_bytes()
        except OSError:
            continue
        old = _read_blob_bytes(base_commit, rel)
        if old is None:
            out.append(DiffEntry("A", rel))
        # Python source and the v2 content identity both normalize CRLF to LF.
        # A normal Windows checkout must not turn every unchanged module into an extra edit.
        elif old.replace(b"\r\n", b"\n") != disk.replace(b"\r\n", b"\n"):
            out.append(DiffEntry("M", rel))
    return sorted(out, key=lambda e: e.path)


def _iter_py_files_pruned(root: Path):
    """遍历 root 下所有 .py 文件；遇到噪声目录直接剪枝（不进去 Walk）。"""
    stack = [root]
    while stack:
        current = stack.pop()
        try:
            children = list(current.iterdir())
        except OSError:
            continue
        for child in children:
            if child.is_dir():
                if child.name in _NOISE_DIRS or child.name.startswith("."):
                    continue
                stack.append(child)
            elif child.suffix == ".py":
                yield child


def content_digest(root: str) -> str:
    """分析根下所有 .py 文件内容的指纹（sha256，按相对路径排序、跳过噪声目录）。

    用于执行入口回答"运行期间目标变了没有"：执行前后各算一次，不同即结果不再对应当前目标
    版本（契约要求这种情况不得算完整通过）。只读 .py，且剪掉 __pycache__/.venv/.git 等目录，
    所以 pytest 自己产生的字节码缓存不会造成假漂移。返回空串表示 root 不存在/不可读。
    """
    import hashlib

    base = Path(root)
    if not base.is_dir():
        return ""
    digest = hashlib.sha256()
    files = sorted(
        (p.relative_to(base).as_posix(), p) for p in _iter_py_files_pruned(base)
    )
    for rel, path in files:
        digest.update(rel.encode("utf-8"))
        digest.update(b"\x00")
        try:
            digest.update(path.read_bytes())
        except OSError:
            digest.update(b"<unreadable>")
        digest.update(b"\x00")
    return digest.hexdigest()


def _read_blob_bytes(commit: git.Commit, path: str) -> bytes | None:
    """读某 commit 树下某文件的原始字节；不存在或不是 blob 时返回 None。"""
    try:
        obj = commit.tree / path
    except KeyError:
        return None
    data = getattr(obj, "data_stream", None)
    if data is None:  # 路径指向子树（子模块等），不是文件
        return None
    return data.read()


# ---- 内部：两种模式的解析 ----------------------------------------------------


def _resolve_commit(repo: git.Repo, target: str) -> ChangeSource:
    """commit 模式：old=父树, new=commit 树。等价于旧的 parent.diff(commit)。"""
    commit = repo.commit(target)
    identity = commit.hexsha[:10]
    if not commit.parents:
        # 首个提交：无父版本可对比。
        return ChangeSource(repo, "commit", identity, False, None, commit, [])
    parent = commit.parents[0]
    entries = _entries_from_diff(parent.diff(commit))
    return ChangeSource(repo, "commit", identity, True, parent, commit, entries)


def _resolve_worktree(repo: git.Repo) -> ChangeSource:
    """worktree 模式：old=HEAD 树, new=磁盘。diff = 跟踪文件(HEAD vs 工作区) + 未跟踪文件。"""
    try:
        head = repo.head.commit
    except (ValueError, git.exc.GitError):
        # 空仓库：还没有任何提交，没有可对比的 HEAD。
        untracked = _untracked_entries(repo)
        return ChangeSource(repo, "worktree", "worktree@<empty>", False, None, None, untracked)

    # 跟踪文件：HEAD 树 vs 工作区（含 staged + unstaged）。None = 工作区。
    tracked = _entries_from_diff(head.diff(None))
    untracked = _untracked_entries(repo)
    entries = _merge_entries(tracked + untracked)

    dirty = len(entries)
    suffix = f"+dirty:{dirty}" if dirty else ""
    identity = f"worktree@{head.hexsha[:10]}{suffix}"
    return ChangeSource(repo, "worktree", identity, True, head, None, entries)


def _untracked_entries(repo: git.Repo) -> list[DiffEntry]:
    """未跟踪文件按新增（A）处理，但过滤掉构建产物/环境噪声（见 _NOISE_DIRS）。"""
    return [
        DiffEntry("A", path)
        for path in repo.untracked_files
        if not _is_noise(path)
    ]


def _is_noise(path: str) -> bool:
    """判断一个仓库相对路径是否属于应忽略的构建产物/环境目录或文件。

    判定按**路径里的每一段**（不只文件名）：`smart_sorter.egg-info/PKG-INFO` 这种
    "目录名带后缀、文件名无关"的情况也要被挡住。
    """
    p = PurePosixPath(path.replace("\\", "/"))
    parts = p.parts
    if set(parts[:-1]) & _NOISE_DIRS:
        return True
    if p.name in _NOISE_DIRS or p.name in _NOISE_FILES:
        return True
    if any(part.endswith(tuple(_NOISE_DIR_SUFFIXES)) for part in parts):
        return True
    return p.suffix in _NOISE_SUFFIXES


def _entries_from_diff(diffs) -> list[DiffEntry]:
    """把 GitPython 的 Diff 列表转成 DiffEntry。change_type 取首字母（R100->R）。

    删除取旧路径 a_path，其余取新路径 b_path。"""
    out: list[DiffEntry] = []
    for d in diffs:
        ct = (d.change_type or "M")[0]
        path = d.a_path if ct == "D" else (d.b_path or d.a_path)
        if path:
            out.append(DiffEntry(ct, path))
    return out


def _merge_entries(entries: list[DiffEntry]) -> list[DiffEntry]:
    """按路径去重（同路径保留首个 change_type），并按路径排序，输出稳定。"""
    by_path: dict[str, DiffEntry] = {}
    for e in entries:
        by_path.setdefault(e.path, e)
    return [by_path[p] for p in sorted(by_path)]


def _read_tree(commit: git.Commit, path: str) -> str:
    """从某 commit 树读文件文本；不存在时返回空串。"""
    try:
        blob = commit.tree / path
    except KeyError:
        return ""
    return blob.data_stream.read().decode("utf-8", errors="replace")
