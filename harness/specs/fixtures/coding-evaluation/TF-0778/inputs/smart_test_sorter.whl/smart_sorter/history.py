"""历史失败数据：解析 pytest 的 JUnit XML，统计每个测试的历史失败率。

失败率是排序引擎里权重最高的因子——"经常挂的测试更值得先跑"是回归测试
优先级排序里被反复验证的经验规律。这里只用标准库 xml.etree，不引入 lxml。

本模块还提供**耗时估计**（`build_duration_history`）。它是"耗感知排序"的必要前置：
要按预计耗时排序，就得先有"预知耗时"这件事。注意：

* `parse_junit_xml` 一直就在返回逐测试 `duration`，但**至今没有任何排序消费者**——
  在拿到真实决策依据之前，产品排序行为**不**改（见 `experiments/tf0028_eval/cost_aware_gate.py`：
  三个数据集上耗感知重排有正有负，两个池上明确有害）。
* 耗时估计**只做"有数据才算"**：没见过的测试不进返回值，由调用方决定兜底策略；
  不给"默认耗时"是为了让"缺数据"在调用点可见，而不是被一个魔数悄悄抹平。
"""

from __future__ import annotations

import statistics
import xml.etree.ElementTree as ET
from pathlib import Path


def parse_junit_xml(xml_path: str) -> list[dict]:
    """解析单个 JUnit XML 报告，返回每个测试用例的结果。

    返回格式：
        [{"test_name": "tests/test_x.py::test_foo",
          "status": "passed" | "failed",
          "duration": 1.23}, ...]

    JUnit 里 <testcase> 的子节点若是 <failure> 或 <error> 记为 failed，
    <skipped> 也不算失败（记为 passed，因为它没暴露问题），其余视为 passed。
    """
    tree = ET.parse(xml_path)
    root = tree.getroot()

    results: list[dict] = []
    # <testsuites> 下可能直接是 <testcase>，也可能包一层 <testsuite>，都要覆盖。
    for testcase in root.iter("testcase"):
        classname = testcase.get("classname", "")
        name = testcase.get("name", "")
        node_id = _to_node_id(classname, name)

        failed = any(child.tag in ("failure", "error") for child in testcase)
        status = "failed" if failed else "passed"

        try:
            duration = float(testcase.get("time", "0") or 0)
        except ValueError:
            duration = 0.0

        results.append({"test_name": node_id, "status": status, "duration": duration})

    return results


def _to_node_id(classname: str, name: str) -> str:
    """把 JUnit 的 (classname, name) 还原成 pytest 的 node ID，与调用链分析对齐。

    JUnit 里 classname 是点分路径，可能带类名，例如：
        "tests.test_x"                          -> 模块级测试
        "tests.test_x.TestFoo"                  -> 类内测试
    name 可能带参数化后缀，例如 "test_bar[a-b]"。

    还原规则：
      - 点分段里【首个以大写字母开头】的段起，视为类名（pytest 约定 TestXxx）；
        之前的段是模块路径 -> 拼成 "tests/test_x.py"。
      - 参数化后缀 [..] 去掉，让同一函数的所有参数用例聚合，且能匹配调用链产出的
        node ID（后者不含参数后缀）。
    最终形如 "tests/test_x.py::test_bar" 或 "tests/test_x.py::TestFoo::test_bar"。
    """
    # 去掉参数化后缀
    base_name = name.split("[", 1)[0]

    if not classname:
        return base_name

    parts = classname.split(".")
    # 找到第一个"类名段"（首字母大写）；它及其后都是类名，之前的是模块路径。
    split_at = len(parts)
    for i, seg in enumerate(parts):
        if seg[:1].isupper():
            split_at = i
            break

    module_parts = parts[:split_at]
    class_parts = parts[split_at:]

    module_path = "/".join(module_parts) + ".py" if module_parts else ""
    segments = [module_path] if module_path else []
    segments.extend(class_parts)
    segments.append(base_name)
    return "::".join(segments)


def build_failure_history(xml_dir: str) -> dict[str, float]:
    """扫描目录下所有 JUnit XML（代表多次 CI 运行），算出每个测试的失败率。

    失败率 = 失败次数 / 总运行次数，范围 [0.0, 1.0]。
    没有任何历史记录的测试不会出现在返回值里（调用方用默认值兜底）。
    """
    xml_root = Path(xml_dir)
    runs: dict[str, list[bool]] = {}  # test_name -> [是否失败, ...]

    for xml_file in sorted(xml_root.glob("*.xml")):
        try:
            cases = parse_junit_xml(str(xml_file))
        except ET.ParseError:
            # 损坏的 XML 跳过，不影响其它报告。
            continue
        for case in cases:
            runs.setdefault(case["test_name"], []).append(case["status"] == "failed")

    history: dict[str, float] = {}
    for name, outcomes in runs.items():
        if outcomes:
            history[name] = sum(outcomes) / len(outcomes)
    return history


def build_duration_history(xml_dir: str, *, aggregate: str = "median") -> dict[str, float]:
    """扫描目录下所有 JUnit XML，给出每个测试的**预计耗时（秒）**。

    这是"耗感知排序"缺的那块原语：`parse_junit_xml` 一直在返回 `duration`，但没有任何消费者。
    这里把它聚合成一个稳定的估计量。

    参数:
        aggregate: 同一条测试出现在多份报告里时怎么合并——
            "median"（默认）：中位数，抗单次抖动（推荐；CI 上一次被调度挤压不该改变排序）；
            "mean"：算术平均；
            "max"：最坏情况，偏保守（要按"最大可能耗时"规划预算时用）。

    **语义（写死）**：
      - 只有在报告里**真的出现过**的测试才进返回值 ⇒ 调用方能看见"哪些没有估计"；
      - 负耗时当 0 处理（JUnit 里偶见异常值）；无法解析的 XML 跳过，不影响其它报告；
      - 一条测试在所有报告里都是 0 秒时，**仍然返回 0.0**（不丢键），
        因为"它确实很快"与"我们没有它的数据"是两件事，调用方要能区分。
    """
    if aggregate not in ("median", "mean", "max"):
        raise ValueError(f"未知的 aggregate={aggregate!r}（只支持 median/mean/max）")

    xml_root = Path(xml_dir)
    samples: dict[str, list[float]] = {}

    for xml_file in sorted(xml_root.glob("*.xml")):
        try:
            cases = parse_junit_xml(str(xml_file))
        except ET.ParseError:
            continue
        for case in cases:
            samples.setdefault(case["test_name"], []).append(max(0.0, float(case["duration"])))

    reducer = {"median": statistics.median, "mean": statistics.mean, "max": max}[aggregate]
    return {name: round(reducer(values), 6) for name, values in samples.items() if values}
