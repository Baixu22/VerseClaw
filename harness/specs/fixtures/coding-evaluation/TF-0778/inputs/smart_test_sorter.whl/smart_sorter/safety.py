"""安全兜底：判断一次变更是否超出函数级分析的能力范围、必须跑全量。

函数级选择只在"改动完全落在函数/方法体内"时可信。以下情况一律回退全量：
  - 首个提交 / 空仓库（无基线可对比）；
  - 改了非 Python 文件（配置、依赖锁、数据文件等），文档类除外；
  - 删除 / 重命名 .py 文件，或新增非测试 .py 文件；
  - 改了 conftest.py / __init__.py / setup.py / 等全局入口；
  - **改动模块不是叶子**：有别的**非测试**模块（直接或间接）导入它 —— 此时其它模块会经
    "公开 API / 请求管线 / 动态派发"把影响带到我们看不见的测试里（TF-0028 在真实 httpx 的
    mutation 真值集上量到：非叶子模块的改动有 44% 会被现有的名称级/文件级/调用图信号漏掉，
    而漏掉的测试 100% 落在"导入了被改模块所在包"的文件里）。这类改动的影响面无法用静态
    信号界定，所以保守回退全量；只有叶子模块（没有任何非测试模块导入它）才允许函数级选择。
  - 改了模块级或类级代码（import、常量、装饰器、类属性……）；
  - 源码无法解析。

变更目标（历史 commit 或 WORKTREE 工作区未提交改动）统一经 revision.ChangeSource
解析，本模块只做"是否安全可选"的判定。
"""

from __future__ import annotations

import ast
from pathlib import Path, PurePosixPath

from smart_sorter import revision

# 只有明确的文档格式才豁免全量。特意【不】把 .txt 算作文档：requirements.txt /
# constraints.txt 是依赖锁文件，改了它必须全量，否则依赖升级会静默逃过安全网。
# docs/ 目录下的任意文本仍按文档处理（见 _DOC_DIRS）。
_DOC_SUFFIXES = {".md", ".rst"}
_DOC_DIRS = {"docs", "doc"}
_GLOBAL_PY = {"conftest.py", "__init__.py", "setup.py", "noxfile.py"}
_DYNAMIC_PACKAGE_LOADERS = {"register_plugins", "iter_modules", "walk_packages"}
_DYNAMIC_IMPORT_CALLS = {
    "__import__", "builtins.__import__", "importlib.import_module",
    "importlib.util.spec_from_file_location", "importlib.machinery.SourceFileLoader",
    "pkgutil.iter_modules", "pkgutil.walk_packages",
    "importlib.metadata.entry_points", "importlib_metadata.entry_points",
    "pkg_resources.iter_entry_points",
}


def is_test_file(path: str) -> bool:
    name = PurePosixPath(path).name
    return name.startswith("test_") or name.endswith("_test.py")


def _is_doc(path: str) -> bool:
    p = PurePosixPath(path)
    return p.suffix.lower() in _DOC_SUFFIXES or bool(set(p.parts[:-1]) & _DOC_DIRS)


def _blank_function_bodies(source: str) -> str:
    """去掉顶层函数和类方法的定义（含装饰器以外的部分），只留模块/类级代码。"""
    tree = ast.parse(source)
    lines = source.splitlines()
    spans: list[tuple[int, int]] = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            spans.append((node.lineno, node.end_lineno or node.lineno))
        elif isinstance(node, ast.ClassDef):
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    spans.append((item.lineno, item.end_lineno or item.lineno))
    for start, end in spans:
        for i in range(start - 1, end):
            lines[i] = ""
    return "\n".join(line.rstrip() for line in lines if line.strip())


def _module_name(rel_path: str) -> str:
    """相对路径 -> 点分模块名（复用 graph 的口径，保证与调用图一致）。"""
    from smart_sorter import graph

    return graph._rel_to_module(rel_path)


def _direct_import_targets(tree: ast.Module, module: str, *, is_package: bool) -> set[str]:
    """一个源文件**直接**导入的模块名（绝对点分），正确处理相对导入。

    相对路径与调用图共用解析器。安全边界必须覆盖局部/条件导入；from pkg import x
    同时记录 pkg 和 pkg.x（x 可能是子模块），不把没有静态边误当成没有依赖。
    """
    from smart_sorter.graph import _resolve_from_module
    # `__init__.py` 本身**就是**包：相对导入相对它自己展开；普通模块相对其所在包展开。
    pkg_parts = module.split(".") if is_package else module.split(".")[:-1]
    targets: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                targets.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            target = _resolve_from_module(node, pkg_parts)
            if target:
                targets.add(target)
                targets.update(f"{target}.{a.name}" for a in node.names if a.name != "*")
    return targets


def _module_level_imports(tree: ast.Module, module: str, *, is_package: bool) -> set[str]:
    """只取**模块顶层**（不深入 try/except、函数）的 import 目标（绝对点分）。

    与 `_direct_import_targets` 的口径**故意不同**：那个是安全边界，宁多勿少；
    这个是**诊断**"候选改动集指向了不存在的首方模块"，所以要刻意避开
    `try: import x / except ImportError` 这类**可选依赖**，否则会天天误报。
    """
    from smart_sorter.graph import _resolve_from_module

    pkg_parts = module.split(".") if is_package else module.split(".")[:-1]
    targets: set[str] = set()
    for node in tree.body:  # 只顶层：Try / FunctionDef 里的 import 不进
        if isinstance(node, ast.Import):
            for alias in node.names:
                targets.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            target = _resolve_from_module(node, pkg_parts)
            if target:
                targets.add(target)
    return targets


def _module_file(root: Path, dotted: str) -> bool:
    """`dotted` 在 root 下能不能当模块导入。

    三种成立方式：`x.py`、`x/__init__.py`、以及**目录本身**——后者是 PEP 420
    **命名空间包**：`app/db/` 里没有 `__init__.py` 也照样能 `import app.db`。
    （真实例：norman 候选里 `app/db/` 就没有 `__init__.py`；把它判成"缺失"是误报。）
    """
    base = root.joinpath(*dotted.split("."))
    return base.with_suffix(".py").is_file() or (base / "__init__.py").is_file() or base.is_dir()


def broken_first_party_imports(
    source: "revision.ChangeSource", analysis_root: str | None = None
) -> list[tuple[str, str]]:
    """改动集里的 .py 文件 import 了一个**首方**模块、而该模块在分析根里不存在 ⇒ 报出来。

    要解决的问题：调用图与选择都是静态的，"这个模块根本不存在"只有真去 import 才会发现，
    而它现在的**唯一症状是收集阶段一个笼统的 `collection-error`**——把"候选自身不可导入"
    与"我们的收集实现有问题"混在一起。真实例（`norman#111`）：PR 改的
    `app/models/connectors.py` 仍 `from app.models.base import Base`，而 ours 侧已把该基类
    搬到 `app/db/base.py`，于是合并产物导入即失败。

    **判据（故意保守，宁缺勿误报）**：只报"**顶层包在分析根下存在**、但它下面的某个子模块
    不存在"这一种形状，因为：
      * 顶层包不存在 ⇒ 无法与"第三方/环境依赖"区分（`sqlalchemy` 当然不在候选目录里），
        所以**不猜**；
      * `try: import … except ImportError` 这类可选依赖：只取模块顶层，天然不进。

    已知边界（如实声明）：`from pkg import sub` 若 `pkg` 存在而 `sub` 是缺失的**子模块**
    （而非符号），本函数判不出来——那需要符号级分析。这里只回答"导入的模块路径在不在"。
    """
    root = Path(analysis_root) if analysis_root else None
    if root is None or not root.is_dir():
        disk = getattr(source, "disk_root", None)
        root = Path(disk) if disk else None
    if root is None or not root.is_dir():
        return []

    out: list[tuple[str, str]] = []
    for entry in source.diff_entries():
        if entry.change_type == "D" or not entry.path.endswith(".py"):
            continue
        try:
            text = source.read_new(entry.path)
        except (OSError, KeyError, ValueError):
            continue
        if not text:
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue  # 语法坏掉是另一类问题，不在本函数里报
        module = _module_name(entry.path)
        is_package = entry.path.endswith("__init__.py")
        for target in sorted(_module_level_imports(tree, module, is_package=is_package)):
            top = target.split(".")[0]
            if not _module_file(root, top):
                continue  # 第三方/环境依赖：不在候选树里很正常，不猜
            if not _module_file(root, target):
                out.append((entry.path, target))
    return out


def _is_dynamic_package_registry(tree: ast.Module) -> bool:
    """Whether a package initializer discovers sibling modules from ``__path__``."""
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = node.func.id if isinstance(node.func, ast.Name) else (
            node.func.attr if isinstance(node.func, ast.Attribute) else ""
        )
        if name in _DYNAMIC_PACKAGE_LOADERS and any(
            isinstance(child, ast.Name) and child.id == "__path__"
            for arg in [*node.args, *(kw.value for kw in node.keywords)]
            for child in ast.walk(arg)
        ):
            return True
    return False


def _has_dynamic_import(tree: ast.Module, module: str, *, is_package: bool) -> bool:
    """已知动态加载 API（含别名/局部导入）；未知目标按整仓兜底，不猜包范围。

    这不是任意 Python 反射的证明器；无法识别的自定义加载机制仍需 shadow 证据。
    """
    from smart_sorter.graph import _parse_imports

    imports = _parse_imports(ast.Module(body=list(ast.walk(tree)), type_ignores=[]),
                             module, is_package=is_package)
    aliases = {**imports.module_aliases, **imports.symbol_imports}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = ast.unparse(node.func)
            first, dot, rest = name.partition(".")
            qualified = aliases.get(first, first) + (dot + rest if dot else "")
            if qualified in _DYNAMIC_IMPORT_CALLS:
                return True
    return False


_SKIP_DIRS = {".git", ".venv", "venv", "build", "dist", "__pycache__",
              ".tox", ".nox", ".mypy_cache", ".pytest_cache", ".pytest_tmp", ".eggs"}


class _NonTestImportIndex:
    """One non-test import graph. Callers must not reuse it across changing worktrees."""

    __slots__ = ("reverse", "dynamic_packages", "dynamic_loaders", "parse_error")

    def __init__(
        self,
        reverse: dict[str, set[str]],
        dynamic_packages: set[str],
        dynamic_loaders: set[str],
        parse_error: Exception | None,
    ) -> None:
        self.reverse = reverse
        self.dynamic_packages = dynamic_packages
        self.dynamic_loaders = dynamic_loaders
        self.parse_error = parse_error


def _build_non_test_import_index(repo_path: str) -> _NonTestImportIndex:
    """Scan non-test ``.py`` files once and build the reverse import graph."""
    from smart_sorter import graph

    root = Path(repo_path)
    direct: dict[str, set[str]] = {}
    dynamic_packages: set[str] = set()
    dynamic_loaders: set[str] = set()
    parse_error: Exception | None = None
    for path in sorted(root.rglob("*.py")):
        rel = path.relative_to(root).as_posix()
        if any(part in _SKIP_DIRS for part in rel.split("/")):
            continue
        if is_test_file(rel):
            continue
        mod = graph._rel_to_module(rel)
        try:
            tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        except (OSError, SyntaxError, UnicodeError) as exc:
            parse_error = exc
            continue
        is_package = path.name == "__init__.py"
        direct.setdefault(mod, set()).update(
            _direct_import_targets(tree, mod, is_package=is_package))
        if is_package and _is_dynamic_package_registry(tree):
            dynamic_packages.add(mod)
        if _has_dynamic_import(tree, mod, is_package=is_package):
            dynamic_loaders.add(mod)

    reverse: dict[str, set[str]] = {}
    for mod, targets in direct.items():
        for target in targets:
            reverse.setdefault(target, set()).add(mod)
    return _NonTestImportIndex(reverse, dynamic_packages, dynamic_loaders, parse_error)


def _importers_from_index(index: _NonTestImportIndex, module: str) -> list[str]:
    seen: set[str] = set()
    stack = [mod for mod in index.reverse.get(module, ()) if mod != module]
    stack.extend(
        package for package in index.dynamic_packages if module.startswith(package + ".")
    )
    while stack:
        current = stack.pop()
        if current in seen or current == module:
            continue
        seen.add(current)
        stack.extend(index.reverse.get(current, ()))
    seen.update(index.dynamic_loaders)
    # 已有全量理由时优先报告可定位的依赖证据；否则解析缺口不能伪装成叶子。
    if not seen and index.parse_error is not None:
        raise index.parse_error
    return sorted(seen)


def non_test_importers(repo_path: str, module: str) -> list[str]:
    """仓库里（直接或间接）导入 `module` 的**非测试**模块名，升序返回。

    这是"改动模块是不是叶子"的唯一判据：非叶子 ⇒ 其它模块会经公开 API / 请求管线 /
    动态派发把影响带到静态信号看不见的测试里，函数级选择不再可信（见模块 docstring）。
    扫描局部/条件导入以及已知动态加载 API；解析失败抛错，上层保守全量。
    每次对外调用扫一遍非测试 `.py`，不跨工作区缓存。一次 `full_run_reasons`
    对多个改动文件复用同一份索引，并且在已经必须全量后不再继续做选择分析。
    """
    return _importers_from_index(_build_non_test_import_index(repo_path), module)


def full_run_reasons(repo_path: str, target: str) -> list[str]:
    """返回必须跑全量的原因列表；空列表表示函数级选择可用。

    target 可以是历史 commit-ish 或 revision.WORKTREE（工作区未提交改动）。
    已经必须全量后不再继续做依赖图/选择分析；同一次调用内依赖图最多建一次。
    """
    source = revision.resolve(repo_path, target)
    if not source.has_baseline:
        return ["首个提交，没有可对比的父版本"]

    entries = source.diff_entries()
    # worktree 模式下【完全没有未提交改动】：不能静默选空集（那会让"跑了 0 个测试"
    # 被误当成"已验证通过"，正是 TF-0019/TF-0021 要避免的空选陷阱）。给出明确结果——
    # 保守全量。commit 模式不加此条：历史提交即使只改文档，其空选语义是既有约定。
    if source.kind == "worktree" and not entries:
        return ["工作区无未提交改动，按全量运行（避免空选被误当成已验证）"]

    reasons: list[str] = []
    source_seen = False
    import_index: _NonTestImportIndex | None = None
    for entry in entries:
        path = entry.path
        if _is_doc(path):
            continue
        source_seen = True
        if not path.endswith(".py"):
            reasons.append(f"非 Python 文件改动：{path}")
            continue
        if entry.change_type == "A":
            if not is_test_file(path):
                reasons.append(f"新增源码文件：{path}")
            continue
        if entry.change_type != "M":
            reasons.append(f"删除或重命名 Python 文件：{path}")
            continue
        if PurePosixPath(path).name in _GLOBAL_PY:
            reasons.append(f"全局入口文件改动：{path}")
            continue
        # A known full-run reason already decides the plan; skip leftover
        # selection-safety analysis (import graph / ranking inputs).
        if reasons:
            continue
        try:
            if import_index is None:
                import_index = _build_non_test_import_index(repo_path)
            importers = _importers_from_index(import_index, _module_name(path))
        except (OSError, SyntaxError, UnicodeError) as exc:
            reasons.append(f"无法解析依赖，保守回退全量：{exc}")
            continue
        if importers:
            head = "、".join(importers[:3]) + ("…" if len(importers) > 3 else "")
            reasons.append(
                f"改动模块不是叶子（{len(importers)} 个非测试模块静态导入或可能动态加载它：{head}）：{path}"
                " —— 影响面无法用函数级信号界定，保守回退全量"
            )
            continue
        try:
            old = _blank_function_bodies(source.read_old(path))
            new = _blank_function_bodies(source.read_new(path))
        except SyntaxError:
            reasons.append(f"无法解析：{path}")
            continue
        if old != new:
            reasons.append(f"模块级或类级代码改动：{path}")

    # 只改了文档（或文档 + 噪声）⇒ 源码关键词为空 ⇒ 文件级与名称级都选不出任何测试。
    # 在 **worktree 模式**（`--smart-select` 的日常场景：真跑一次）下，空选会被调用方
    # 执行成"**跑 0 个测试**"——正是上面那条"空选被误当成已验证"的陷阱，所以这里必须明确回退。
    # **commit 模式不加**：分析历史提交时"只改文档 ⇒ 无受影响测试"是既有约定
    # （`test_doc_only_change_is_selectable` 钉着它），改它是产品契约变更、应当单独决定。
    if source.kind == "worktree" and entries and not source_seen:
        reasons.append("改动里没有可解析的源码（只改了文档），按全量运行（避免空选被误当成已验证）")
    return reasons


def changed_test_files(repo_path: str, target: str) -> list[str]:
    """本次新增或修改的测试文件：它们总是要跑。"""
    source = revision.resolve(repo_path, target)
    if not source.has_baseline:
        return []
    return sorted(
        e.path
        for e in source.diff_entries()
        if e.change_type in ("A", "M") and e.path.endswith(".py") and is_test_file(e.path)
    )
