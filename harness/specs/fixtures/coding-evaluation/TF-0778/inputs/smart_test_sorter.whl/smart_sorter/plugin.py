"""pytest 插件：把智能排序接进 pytest 的测试收集阶段。

启用后（加 --smart-sort），插件会在收集完测试用例后，按 scorer 给出的优先级
重排执行顺序，让"更可能失败"的测试先跑，从而更早发现回归。

设计原则：
  - 不加 --smart-sort 时完全无感，绝不改变 pytest 默认行为；
  - git/分析出任何问题时降级为原顺序 + 打印 warning，绝不让 pytest 崩掉。
"""

from __future__ import annotations

import warnings
from pathlib import Path

# 收集阶段用到的排序结果，存起来供 terminal_summary 打印统计。
_SORT_STATE: dict[str, object] = {}


def pytest_addoption(parser) -> None:
    """注册命令行参数。"""
    group = parser.getgroup("smart-sort", "Smart Test Sorter")
    group.addoption(
        "--smart-sort",
        action="store_true",
        default=False,
        help="启用函数级智能排序：高优先级的测试先执行",
    )
    group.addoption(
        "--smart-sort-commit",
        action="store",
        default=None,
        help="用于分析改动的 commit hash；省略则分析工作区未提交改动（默认）",
    )
    group.addoption(
        "--smart-sort-xml-dir",
        action="store",
        default=None,
        help="历史 JUnit XML 目录，用于按失败率加权（可选）",
    )
    group.addoption(
        "--smart-select",
        action="store_true",
        default=False,
        help="在排序基础上只运行受影响的测试；无法安全判断时自动跑全量（隐含 --smart-sort）",
    )


def pytest_collection_modifyitems(session, config, items) -> None:
    """Selection uses the shared conservative planner; explicit sorting stays opt-in."""
    _SORT_STATE.clear()
    select = config.getoption("--smart-select")
    if not (config.getoption("--smart-sort") or select) or not items:
        return

    repo_path = str(getattr(config, "rootpath", None) or config.rootdir)
    from smart_sorter import plan, revision

    commit = config.getoption("--smart-sort-commit") or revision.WORKTREE
    xml_dir = config.getoption("--smart-sort-xml-dir")
    original = list(items)
    try:
        source = revision.resolve(repo_path, commit)
        target_desc = revision.describe(source)
        if source.kind == "commit":
            _warn_if_worktree_diverges(repo_path, source)
        if select:
            doc = plan.build_plan(
                repo_path, source, [item.nodeid for item in original],
                request_id="pytest-plugin", plan_id="pytest-plugin", xml_dir=xml_dir,
            )
            positions = {nid: i for i, nid in enumerate(doc["order"])}
            keep = [item for item in original if item.nodeid in positions]
            drop = [item for item in original if item.nodeid not in positions]
            keep.sort(key=lambda item: positions[item.nodeid])
            matched = sum("call-graph" in doc["reasons"][item.nodeid] for item in keep)
        else:
            from smart_sorter.scorer import prioritize

            ranked = prioritize(repo_path, source, xml_dir=xml_dir)
            priority = {nid: i for i, (nid, _score) in enumerate(ranked)}
            # sorted is stable: unranked items retain their native order.
            keep = sorted(original, key=lambda item: priority.get(
                _normalize_node_id(item.nodeid), len(priority)
            ))
            drop = []
            matched = sum(_normalize_node_id(item.nodeid) in priority for item in keep)
    except Exception as exc:
        warnings.warn(
            f"[smart-sort] 分析失败，回退到默认顺序并运行全部测试：{exc}",
            stacklevel=1,
        )
        return

    if drop:
        config.hook.pytest_deselected(items=drop)
    items[:] = keep
    _SORT_STATE.update(enabled=True, matched=matched, total=len(items), reordered=original != items)
    reporter = config.pluginmanager.get_plugin("terminalreporter")
    if reporter is None:
        return
    reporter.write_line(f"[smart-sort] 分析目标：{target_desc}")
    if select and doc.get("fallback"):
        reporter.write_line("[smart-select] 保持原生顺序运行全部测试，原因：")
        for reason in doc["fallback"]:
            reporter.write_line(f"  - {reason}")
    elif select:
        reporter.write_line(f"[smart-select] 运行 {len(keep)} 个受影响测试，跳过 {len(drop)} 个。")
    else:
        reporter.write_line(f"[smart-sort] 已重排 {len(items)} 个测试，其中 {matched} 个被优先级模型命中。")


def _warn_if_worktree_diverges(repo_path: str, source) -> None:
    """commit 模式下，若目标 commit 与当前工作区不一致，则响亮告警（但继续）。

    调用图/函数索引始终从【当前工作区磁盘】构建；分析历史 commit 时，磁盘上的依赖图
    可能已经和那次提交不同，导致"受影响测试"是按当前代码算的、而非该 commit 当时的。
    这不阻断执行（用户可能确实想按当前代码给历史 diff 排序），但必须让用户知道。
    """
    import git

    try:
        repo = git.Repo(repo_path)
        head_sha = repo.head.commit.hexsha
        dirty = repo.is_dirty(untracked_files=True)
    except Exception:
        return  # 拿不到 HEAD（空仓库等）就不告警，交由后续逻辑处理

    target_sha = source.identity  # commit 模式下是 hexsha[:10]
    if not head_sha.startswith(target_sha) or dirty:
        warnings.warn(
            f"[smart-sort] 分析的是历史提交 {target_sha}，但调用图基于【当前工作区】"
            f"（HEAD={head_sha[:10]}{'，且有未提交改动' if dirty else ''}）构建，"
            "受影响测试按当前代码依赖图计算，可能与该提交当时的真实依赖不一致。",
            stacklevel=2,
        )


def _normalize_node_id(node_id: str) -> str:
    """把 pytest 的 nodeid 归一成排序表用的分组键。

    与 plan.group_key 同一口径（去 [param] 后缀、正斜杠）——委托给它，保证插件排序/统计
    与统一计划引擎用的是同一个归一实现，不各写一份。
    """
    from smart_sorter.plan import group_key

    return group_key(node_id)


def pytest_terminal_summary(terminalreporter, exitstatus, config) -> None:
    """测试结束后打印智能排序的效果统计。"""
    if not _SORT_STATE.get("enabled"):
        return

    total = _SORT_STATE.get("total", 0) or 0
    # 统计"前 20% 的测试里抓到了几个失败"，这是评估排序有效性的直观指标。
    failed_reports = terminalreporter.stats.get("failed", [])
    failed_ids = {_normalize_node_id(r.nodeid) for r in failed_reports}
    if not failed_ids:
        terminalreporter.write_line(
            f"[smart-sort] 命中 {_SORT_STATE.get('matched', 0)}/{total} 个测试；本次无失败。"
        )
        return

    # 统计"前 20% 的执行顺序里抓到了几个失败"，直观反映排序把失败测试提前的效果。
    # 注意：参数化用例会把同一函数拆成多份 report，而 failed_ids 已按归一化去重，
    # 所以分子也必须【按归一化去重】来数，否则会出现 6/4 这种分子大于分母的情况。
    cutoff = max(1, int(total * 0.2))
    early_failed_ids: set[str] = set()
    for seen, report in enumerate(_iter_reports_in_run_order(terminalreporter)):
        if seen >= cutoff:
            break
        nid = _normalize_node_id(report.nodeid)
        if nid in failed_ids:
            early_failed_ids.add(nid)

    terminalreporter.write_line(
        f"[smart-sort] 前 20%（{cutoff} 个）测试中检测到 "
        f"{len(early_failed_ids)}/{len(failed_ids)} 个失败。"
    )


def _iter_reports_in_run_order(terminalreporter):
    """按执行顺序遍历所有用例的 report（passed + failed 合并）。

    pytest 的 stats 按类别分桶，这里合并后用 report 的启动顺序近似执行顺序。
    """
    reports = []
    for key in ("passed", "failed"):
        reports.extend(terminalreporter.stats.get(key, []))
    # 有 start 时间的按时间排；没有就维持插入顺序。
    reports.sort(key=lambda r: getattr(r, "start", 0.0))
    return reports
