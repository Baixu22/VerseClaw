"""宿主计划执行入口（TF-0021）：按固定 test_plan 执行 pytest 并回传 v1 execution_result。

这是本仓对外（VG:TF-0163）的【正式模块入口】，与 `plan_request` 成对：

    <宿主选定的解释器>/python -m smart_sorter.run_plan --plan <plan.json> --out <result.json> \
        [--cwd <分析根>] [--request <request.json>] [--test-dir tests] [--timeout SEC] [--full]

解释器由宿主在命令行显式选定（契约 transport.interpreter_selection），收集与执行都在该解释器内
进行；本入口**不新增 daemon、不新增任务队列、不建第二套账本**，只是把 pytest 跑成一次可解释、
可回传的事实（验收第 4 条）。

## 三条硬规矩

1. **不重新选择**：执行的永远是计划里的确切 nodeid（`--full` 时是计划的 collected 全集），
   按计划给定顺序、保留参数化后缀。本入口不做任何选择/排序判断。
2. **核对后才执行**：执行前真跑一次 `pytest --collect-only` 核对"计划收集摘要 vs 目标当前收集"，
   并（给了 `--request` 时）核对目标身份与环境；执行后核对分析根内容指纹。
   任一不符 ⇒ 结果只能是 `validity=invalid` / `completeness=incomplete`，绝不当成完整通过证据。
3. **三个维度互不顶替**（契约核心）：`selection_scope`（测了什么范围）、`completeness`（计划内跑完没有）、
   `validity`（是否对应当前目标版本）各说各的；零执行、收集失败、超时、取消都不算完整通过。

## raw_exit_code 语义（写死）

始终是**一次真实 pytest 进程的退出码**，不凭空编造：

- 正常路径：执行那次 `pytest <order>` 的退出码；
- 计划被判定过期/测试消失而**未执行**、或计划里没有任何可执行 nodeid（零执行）：
  取核对用那次真实 `pytest --collect-only` 的退出码，`invalid_reason` / `incomplete_reason` 里
  会写明"未执行任何测试"。

## 退出码（供只看退出码的调用方；事实都在结果文件里）

| 退出码 | 含义 |
| --- | --- |
| `0` | 产出结果：计划内跑完、结果有效、无 failed/error |
| `1` | 产出结果：有 failed/error（与 pytest 的"测试失败"同义） |
| `3` | 产出结果：`completeness=incomplete` 或 `validity=invalid`（计划过期/超时/零执行…） |
| `2` | 用法或输入错误，**没有**结果可产出（计划文件读不了、不合契约、`--request` 不合法、解释器里没有 pytest） |

优先级 3 > 1 > 0（与 VG 侧"只降不升"的映射同序：有效性/完成度先于失败计数）。

## 能力边界（如实声明）

`--timeout` 是**协作式**预算：在**每个测试开始前**检查截止时间，超了就中止并记
`incomplete_reason=budget-exhausted`。它不会打断单个超长测试——那条路径靠宿主杀掉本进程，
此时本进程不会写出结果文件，由宿主按契约记 incomplete（不填造成功回执）。

`--full` 是"关闭选择的完整运行路径"：跑计划的 collected 全集并如实标 `selection_scope=full`。
当计划本身是 `selected` 时，这份结果**有意不满足** `validate_binding` 的
"result.selection_scope == plan.selection_scope"——它是独立的一次全量运行，不是那个计划的回执。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from pathlib import Path

from smart_sorter import (__version__, collect, contract_trees, contracts, plan_request,
                        plan_v2, revision)

_EXIT_CLEAN = 0
_EXIT_FAILURES = 1
_EXIT_NOT_CLEAN = 3
_EXIT_USAGE = 2

# 只在两种情况下我们会用"核对那次收集"的退出码代替"执行那次"的退出码（见模块 docstring）。
_COLLECTION_EXIT_FALLBACK = 0


class _Recorder:
    """最小 pytest 插件：把逐测试事实记下来，并在预算耗尽时中止会话。

    只做记录，不改收集、不改顺序、不改结果——执行顺序完全由命令行给的 nodeid 决定。
    """

    def __init__(self, deadline: float | None = None) -> None:
        self.deadline = deadline
        self.timed_out = False
        self.phases: dict[str, list[str]] = {}
        self.outcomes: dict[str, str] = {}
        self.durations: dict[str, float] = {}
        self.collection_errors = 0

    def pytest_collectreport(self, report) -> None:
        """收集阶段的错误单独计数（与断言失败分开，契约要求）。"""
        if report.failed:
            self.collection_errors += 1

    def pytest_runtest_protocol(self, item, nextitem):
        """每个测试开始前检查一次截止时间；超了就协作式中止整个会话。"""
        if self.deadline is not None and time.monotonic() > self.deadline:
            self.timed_out = True
            import pytest

            pytest.exit("smart_sorter: 执行预算耗尽（--timeout）")
        return None

    def pytest_runtest_logreport(self, report) -> None:
        """把一个 phase 的事实记进 outcomes/phases/durations。"""
        node_id = report.nodeid
        self.phases.setdefault(node_id, []).append(report.when)
        self.durations[node_id] = self.durations.get(node_id, 0.0) + float(report.duration or 0.0)
        if report.when == "call":
            # call 阶段的结论最权威，直接覆盖（passed/failed/skipped）。
            self.outcomes[node_id] = report.outcome
        elif report.failed:
            # setup/teardown 失败属于 error（环境/夹具问题），与断言 failed 分开。
            self.outcomes[node_id] = "error"
        else:
            self.outcomes.setdefault(node_id, report.outcome)


def _run_pytest(order: list[str], root: str, timeout_s: int | None) -> tuple[int, _Recorder, float]:
    """在当前解释器里真跑 `pytest <order>`（in-process），返回 (退出码, 记录器, 耗时)。

    in-process 而不是再起子进程：宿主杀本进程时 pytest 会一起结束，不会留下孤儿进程；
    逐测试事实也不必靠解析输出猜。pytest 的人类输出临时改道 stderr，stdout 留给机器 JSON。
    """
    import pytest
    from smart_sorter.pytest_order import PlanOrder

    recorder = _Recorder(deadline=None if timeout_s is None else time.monotonic() + timeout_s)
    plan_order = PlanOrder(order)
    args = plan_order.arguments(root)
    old_cwd = os.getcwd()
    old_path = sys.path[:]
    old_stdout = sys.stdout
    started = time.monotonic()
    try:
        os.chdir(root)
        # Match `python -m pytest` launched in --cwd: chdir alone does not update
        # Python's import path when the host started in a different repository.
        sys.path.insert(0, root)
        sys.stdout = sys.stderr  # 机器 JSON 与人类日志分离
        try:
            exit_code = int(pytest.main(args, plugins=[plan_order, recorder]))
        finally:
            sys.stdout = old_stdout
    finally:
        os.chdir(old_cwd)
        sys.path[:] = old_path
    return exit_code, recorder, time.monotonic() - started


# ---- 独立进程的臂（TF-0037） --------------------------------------------------
#
# 为什么需要：影子对拍的两条臂过去都在**同一个解释器进程**里顺序跑 `pytest.main()`，
# 于是模块缓存、已 import 的被测包、pytest 插件全局状态都可能互相污染——"两次独立运行"
# 只是口头承诺（顺序依赖、共享状态的测试正是靠这类污染串味的）。
#
# 为什么不直接 `subprocess.run([python, "-m", "pytest", ...])`：逐测试事实（outcome/phases/
# duration）必须结构化取回，而去解析 pytest 的人类输出正是我们早先修掉的缺陷
# （`collect.py` 的注释里记着那次教训）。所以子进程里仍然用同一个 `_Recorder`，
# 只是把结果写进临时 JSON 再读回——与 `collect.py` 同一种"结构化回传"手法。
#
# **孤儿进程**：改成独立进程后，宿主要是被强杀，子 pytest 会活下来。因此子进程自带
# `--parent-pid` 看门狗（父进程消失就自杀），并且父侧 `communicate(timeout=...)` 到期后
# 先 terminate 再 kill。这与 VG 侧"deadline 覆盖整个进程树"是同一件事的两半。
_ARM_SCRIPT = r'''
import json, os, sys, time

parent_pid = int(sys.argv[1]); out_path = sys.argv[2]
root = sys.argv[3]; deadline_s = float(sys.argv[4])
sys.path.insert(0, sys.argv[5])
from smart_sorter.pytest_order import PlanOrder
with open(sys.argv[6], encoding="utf-8") as stream:
    order = json.load(stream)
plan_order = PlanOrder(order)

def parent_alive(pid):
    if os.name == "nt":
        import ctypes
        # 0x1000 = PROCESS_QUERY_LIMITED_INFORMATION；父进程已退出时打不开句柄。
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
        if not h:
            return False
        code = ctypes.c_ulong()
        ok = ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return bool(ok) and code.value == 259  # STILL_ACTIVE
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def write(payload):
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False)

if not parent_alive(parent_pid):
    write({"aborted": "parent-gone", "exit_code": None, "outcomes": {}, "phases": {},
           "durations": {}, "timed_out": False, "collection_errors": 0})
    raise SystemExit(0)

import pytest

class Recorder:
    def __init__(self):
        self.phases = {}; self.outcomes = {}; self.durations = {}
        self.collection_errors = 0; self.timed_out = False
        # 与 in-process 版同口径：`--timeout 0` 表示"一开始就已经超了"，第一个测试之前就中止
        # （**不是**"不限时"）。0 == 关掉预算这件事由 `None` 表达，不靠 0。
        self._deadline = (time.monotonic() + deadline_s) if deadline_s is not None and deadline_s >= 0 else None
        self._last_check = 0.0
    def pytest_collectreport(self, report):
        if report.failed:
            self.collection_errors += 1
    def pytest_runtest_protocol(self, item, nextitem):
        now = time.monotonic()
        if self._deadline is not None and now > self._deadline:
            self.timed_out = True
            pytest.exit("smart_sorter: 执行预算耗尽（--timeout）")
        # 父进程若已消失，本子进程没有存在的理由（避免留下孤儿 pytest）。
        if now - self._last_check > 1.0:
            self._last_check = now
            if not parent_alive(parent_pid):
                self.timed_out = True
                pytest.exit("smart_sorter: 宿主已退出")
        return None
    def pytest_runtest_logreport(self, report):
        nid = report.nodeid
        self.phases.setdefault(nid, []).append(report.when)
        self.durations[nid] = self.durations.get(nid, 0.0) + float(report.duration or 0.0)
        if report.when == "call":
            self.outcomes[nid] = report.outcome
        elif report.failed:
            self.outcomes[nid] = "error"
        else:
            self.outcomes.setdefault(nid, report.outcome)

rec = Recorder()
old_cwd = os.getcwd()
try:
    os.chdir(root)
    sys.path.insert(0, root)
    code = int(pytest.main(plan_order.arguments(root), plugins=[plan_order, rec]))
finally:
    os.chdir(old_cwd)
write({"aborted": None, "exit_code": code, "outcomes": rec.outcomes, "phases": rec.phases,
       "durations": rec.durations, "timed_out": rec.timed_out,
       "collection_errors": rec.collection_errors})
'''


def _interpreter_exists(interpreter: str, shutil_module) -> bool:
    """这个解释器真的能起来吗（只在**起进程之前**问一次，避免半构造的 Popen 泄漏句柄）。

    带路径分隔符的按路径判（存在且是文件）；裸名字（如 `python`）按 PATH 查。
    """
    candidate = Path(interpreter)
    if candidate.parent != Path(".") or os.sep in interpreter or "/" in interpreter:
        return candidate.is_file()
    return shutil_module.which(interpreter) is not None


def _run_pytest_isolated(
    order: list[str], root: str, timeout_s: int | None, python: str | None = None,
) -> tuple[int, _Recorder, float]:
    """在一个**独立解释器进程**里跑 `pytest <order>`，结构化取回逐测试事实。

    与 `_run_pytest` 的差别只有"在哪跑"：这里用 `sys.executable`（或显式 `python`）起子进程，
    因此两条臂之间不共享模块缓存、已 import 的被测包与 pytest 插件全局状态。

    失败与超时的语义（刻意保守，绝不当成"跑完了"）：

    * 子进程非 0 退出且**没写出报告**、或写了但缺字段 ⇒ 退出码原样返回，记录器为空
      （`executed` 会是空的 ⇒ 上层按 `incomplete` 处理，而不是误判成"没有失败"）；
    * `--timeout` 到期 ⇒ 子进程被 terminate→kill，`timed_out=True`（不静默变成"跑完"）；
    * 父进程若在子进程运行期间消失，子进程自带看门狗自杀，不留孤儿 pytest。
    """
    import shutil
    import subprocess
    import tempfile

    interpreter = python or sys.executable
    recorder = _Recorder(deadline=None)
    started = time.monotonic()
    # 先确认解释器真的在，再去起进程：**不要**让 Popen 在 __init__ 里抛（半构造的 Popen
    # 对象稍后被 GC 时会泄漏 "invalid handle" 之类的 unraisable 异常，污染调用方的输出）。
    # 起不来与 in-process 的"没有 pytest"同类 ⇒ 依赖不可用，记一条收集失败、给非 0 退出码，
    # 由上层判 incomplete——绝不静默成"跑完且没有失败"。
    if not _interpreter_exists(interpreter, shutil):
        recorder.collection_errors = 1
        return _EXIT_NOT_CLEAN, recorder, time.monotonic() - started
    # 父侧等得比子侧的协作式截止**略久**：子进程到了 deadline 会 `pytest.exit()` 并写出报告，
    # 父侧要是同一时刻就开枪，会把一份本来能拿到的结构化结论打成"没结论"。
    parent_timeout = None if timeout_s is None else timeout_s + 30
    with tempfile.TemporaryDirectory(prefix="sts-arm-") as directory:
        out_path = str(Path(directory) / "arm.json")
        order_path = Path(directory) / "order.json"
        order_path.write_text(json.dumps(order), encoding="utf-8")
        argv = [interpreter, "-c", _ARM_SCRIPT, str(os.getpid()), out_path, root,
                # `-1` 表示"没给预算"（`None`）；0 表示"预算就是 0 秒"——两者语义不同，别混。
                str(timeout_s if timeout_s is not None else -1),
                str(Path(__file__).resolve().parent.parent), str(order_path)]
        try:
            proc = subprocess.Popen(
                argv, cwd=root, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                text=True, encoding="utf-8", errors="replace",
            )
        except OSError:
            # 解释器起不来（不存在/不可执行）：这与 in-process 版"没有 pytest"同类，
            # 属于**依赖不可用**，不能静默当成"跑完且没有失败"：记录器留空、退出码非 0，
            # 上层据此判 incomplete（`execute_plan` 会把它记成收集失败）。
            recorder.collection_errors = 1
            return _EXIT_NOT_CLEAN, recorder, time.monotonic() - started
        try:
            _, stderr = proc.communicate(timeout=parent_timeout)
        except subprocess.TimeoutExpired:
            # 先给一次体面结束的机会，再强杀：不留孤儿。
            proc.terminate()
            try:
                proc.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()
            recorder.timed_out = True
            return _EXIT_NOT_CLEAN, recorder, time.monotonic() - started

        payload: dict = {}
        output = Path(out_path)
        if output.is_file():
            try:
                payload = json.loads(output.read_text(encoding="utf-8"))
            except (ValueError, UnicodeError):
                payload = {}
        exit_code = payload.get("exit_code")
        if exit_code is None:
            # 子进程没给出结构化结论（崩溃/被杀）：不猜，退出码用子进程真实的那个。
            exit_code = proc.returncode if proc.returncode is not None else _EXIT_NOT_CLEAN
            recorder.collection_errors = 1 if proc.returncode not in (0, 1) else 0
            if payload.get("aborted"):
                recorder.timed_out = True
            return exit_code, recorder, time.monotonic() - started

        recorder.outcomes = {k: v for k, v in (payload.get("outcomes") or {}).items()}
        recorder.phases = {k: list(v) for k, v in (payload.get("phases") or {}).items()}
        recorder.durations = {k: float(v) for k, v in (payload.get("durations") or {}).items()}
        recorder.collection_errors = int(payload.get("collection_errors") or 0)
        recorder.timed_out = bool(payload.get("timed_out"))
        _ = stderr
        return int(exit_code), recorder, time.monotonic() - started


def _actual_env_id() -> str:
    """本实现实际运行环境的身份，与 plan_request/样例同口径：py<major>.<minor>-<platform>。"""
    return f"py{sys.version_info.major}.{sys.version_info.minor}-{sys.platform}"


def _env_mismatch(request: dict, log) -> str | None:
    """请求声明的 env_id 与本机环境冲突时返回原因，否则 None。

    刻意做成"宽容比对"：契约只规定 env_id 是"运行解释器/环境身份（如 py3.12-win）"，
    没规定拼写。所以只从里面识别 Python 版本与操作系统族，**认得出且矛盾**才判不匹配；
    认不出就如实记一条 note（表示"没核对"，而不是"核对通过"），避免把拼写差异误判成环境漂移。
    """
    # 1.1 的 `env_id` 是一个"py3.10-win32"式的串；**2.0 把它拆成了
    # `identities.environment_identity`（结构化：python / platform / dependencies_digest）**。
    # 按 1.1 的读法去读 2.0 的请求 ⇒ 恒为"未声明"⇒ 环境永远"没核对"，那条 note 会误报。
    if request.get("protocol_version") == "1.1":
        declared = (request.get("identities") or {}).get("env_id")
    else:
        from smart_sorter.environment import mismatch
        from smart_sorter.plan_v2 import environment_identity_now
        env = (request.get("identities") or {}).get("environment_identity") or {}
        return mismatch(env, environment_identity_now())
    if not declared:
        log("请求未声明环境身份（1.1: identities.env_id / 2.0: identities.environment_identity）"
            "：环境身份未核对")
        return None
    actual = _actual_env_id()
    py = re.search(r"(\d+)\.(\d+)", declared)
    if py and (int(py.group(1)), int(py.group(2))) != sys.version_info[:2]:
        return f"环境不匹配：请求声明 Python {py.group(1)}.{py.group(2)}，实际 {sys.version_info[0]}.{sys.version_info[1]}"
    os_token = re.search(r"win|linux|darwin|mac", declared.lower())
    if os_token:
        family = "win" if sys.platform.startswith("win") else (
            "darwin" if sys.platform == "darwin" else "linux"
        )
        if os_token.group(0) not in (family, "mac" if family == "darwin" else family):
            return f"环境不匹配：请求声明操作系统 {os_token.group(0)}，实际 {sys.platform}"
    else:
        log(f"env_id={declared!r} 认不出操作系统族：只核对了 Python 版本（实际 {actual}）")
    return None


def execute_plan(
    plan_doc: dict,
    *,
    root: str,
    test_dir: str = "tests",
    timeout_s: int | None = None,
    full: bool = False,
    request: dict | None = None,
    isolated: bool = False,
    interpreter: str | None = None,
    log=lambda message: None,
) -> tuple[str, dict]:
    """按计划执行 pytest，返回 ("result", execution_result) 或 ("error", 机器可读错误)。

    这是本模块的核心；CLI 只负责读写文件与退出码。

    `isolated=True` 时改用**独立解释器进程**跑这条臂（TF-0037）：影子对拍的两次运行因此
    不共享模块缓存 / 已 import 的被测包 / pytest 插件全局状态。默认仍是 in-process
    （宿主入口的既有行为不变：宿主杀本进程时 pytest 一起结束，不留孤儿）。
    """
    order = list(plan_doc["collected"] if full else plan_doc["order"])
    scope = "full" if full else plan_doc["selection_scope"]
    stale: list[str] = []

    # ---- 执行前核对：目标 / 计划收集摘要 / 环境 ------------------------------
    if request is not None:
        # 走 `contract_trees` 单点（2026-10-04）。原先写死 `contracts.validate`（**只认 v1**）
        # ⇒ `shadow --request <2.0>` 走到执行臂时被拒。这是"版本路由散落"的**第五处**——
        # 前四处（plan_request ×2、run_plan ×2、stability ×1）修完后才撞出来，
        # 说明**扫正则不够**：得连 `contracts.validate(` 一起盯住。
        req_version = request.get("protocol_version")
        req_errors = (contracts.validate(request, "request") if req_version == "1.1"
                      else contract_trees.validate_against(request, "request", req_version))
        if req_errors:
            return "error", {
                "ok": False, "error_kind": "input-error",
                "reason": f"--request 不符合 {req_version} 契约：" + "；".join(req_errors),
            }
        resolution = plan_request.confirm_target(request)
        if not resolution.ok:
            stale.append(f"请求所指目标无法确认（{resolution.refusal_code}）：{resolution.reason}")
        elif resolution.target_identity != plan_doc["target_identity"]:
            stale.append(
                f"计划与执行目标不匹配：plan.target_identity={plan_doc['target_identity']} "
                f"≠ 当前目标 {resolution.target_identity}"
            )
        env_reason = _env_mismatch(request, log)
        if env_reason:
            stale.append(env_reason)
        if req_version == "2.0":
            from smart_sorter.plan_v2 import content_mismatch
            mismatch = content_mismatch(request, root)
            if mismatch:
                stale.append(mismatch)

    fresh = collect.collect_nodeids(root, test_dir)
    if not fresh.succeeded and fresh.code == "dependency-unavailable":
        # 解释器/依赖不可用：连核对都做不了，没有结果可产出。
        return "error", {
            "ok": False, "error_kind": "dependency-unavailable", "reason": fresh.detail,
        }
    if not fresh.succeeded:
        stale.append(f"收集失败（{fresh.code}）：{fresh.detail}")
    else:
        fresh_nodes = set(fresh.nodeids)
        if fresh_nodes != set(plan_doc["collected"]):
            stale.append(
                "计划里的收集摘要与目标当前收集结果不一致（计划过期或目标已变化）："
                f"plan.collected={len(plan_doc['collected'])} 个，当前={len(fresh.nodeids)} 个"
            )
        missing = [node_id for node_id in order if node_id not in fresh_nodes]
        if missing:
            stale.append(
                f"计划内的 {len(missing)} 个测试在目标上已不存在（测试消失）："
                f"{missing[0]} 等"
            )

    # ---- 计划不成立：拒绝使用旧计划，不重新选择、不猜 -------------------------
    if stale:
        for reason in stale:
            log(f"计划核对不通过：{reason}")
        return "result", _build_result(
            plan_doc, order, scope,
            executed=[], outcomes={}, phases={}, durations={},
            exit_code=fresh.returncode if fresh.returncode is not None else _COLLECTION_EXIT_FALLBACK,
            duration_s=0.0,
            # 收集阶段真的失败了就如实记 1 条收集失败（不是断言失败）：
            # 这样"一次运行为什么全都没跑"在 failure_categories 里可见，
            # 而不必靠读 invalid_reason 的文本猜（TF-0014 的不稳定记录依赖这个区分）。
            collection_errors=1 if fresh.code == "collection-error" else 0,
            timed_out=False,
            invalid_reasons=stale,
            incomplete_reason="计划核对不通过，按【拒绝使用旧计划】处理：未执行任何测试",
        interpreter=interpreter,
        )

    # ---- 计划内没有任何可执行 nodeid：零执行，绝不当成通过 ---------------------
    if not order:
        log("计划内没有任何可执行的 nodeid：零执行")
        return "result", _build_result(
            plan_doc, order, scope,
            executed=[], outcomes={}, phases={}, durations={},
            exit_code=fresh.returncode if fresh.returncode is not None else _COLLECTION_EXIT_FALLBACK,
            duration_s=0.0, collection_errors=0, timed_out=False,
            invalid_reasons=[],
            incomplete_reason="计划内没有任何可执行的 nodeid（零执行）",
        interpreter=interpreter,
        )

    # ---- 真跑 ----------------------------------------------------------------
    before_digest = revision.content_digest(root)
    if isolated:
        log("在独立解释器进程里执行这条臂（与另一条臂不共享模块/插件状态）")
        exit_code, recorder, duration = _run_pytest_isolated(order, root, timeout_s)
    else:
        exit_code, recorder, duration = _run_pytest(order, root, timeout_s)
    after_digest = revision.content_digest(root)

    post: list[str] = []
    if before_digest != after_digest:
        post.append("运行期间分析根的 .py 内容发生变化，结果不对应计划目标版本")
    if request is not None:
        # 用同一个请求再确认一次目标身份。**两种都要处理**：
        #   ① 确认成功、但身份换成了别的版本；
        #   ② **确认本身失败**（候选目录被换掉、磁盘内容对不上声明）。
        # 旧实现只处理 ①：`ok == False` 时整个分支不触发，于是「执行末尾目标已无法确认」
        # 被静默跳过 ⇒ 一份不对应任何明确版本的结果仍然算 `validity=valid`。
        # 确认失败与身份漂移同罪：都必须让这份回执失效。
        after_resolution = plan_request.confirm_target(request)
        if not after_resolution.ok:
            post.append(
                f"运行期间目标身份无法确认（{after_resolution.refusal_code}）："
                f"{after_resolution.reason}"
            )
        elif after_resolution.target_identity != plan_doc["target_identity"]:
            post.append(
                f"运行期间目标身份变化：{plan_doc['target_identity']} → {after_resolution.target_identity}"
            )
        if request.get("protocol_version") == "2.0":
            from smart_sorter.plan_v2 import content_mismatch
            mismatch = content_mismatch(request, root)
            if mismatch:
                post.append(mismatch)

    executed = list(recorder.outcomes)
    expected_executed = [node for node in order if node in recorder.outcomes]
    if executed != expected_executed:
        post.append("实际执行的测试集合或顺序与固定计划不一致")
    incomplete_reason = None
    if recorder.timed_out:
        incomplete_reason = "budget-exhausted：--timeout 预算在测试之间耗尽，会话被协作式中止"
    elif len(executed) < len(order):
        executed_set = set(executed)
        missing_after = [n for n in order if n not in executed_set]
        incomplete_reason = (
            f"计划内 {len(order)} 个测试只跑完 {len(executed)} 个；未执行首个：{missing_after[0]}"
        )

    return "result", _build_result(
        plan_doc, order, scope,
        executed=executed, outcomes=recorder.outcomes, phases=recorder.phases,
        durations=recorder.durations, exit_code=exit_code, duration_s=duration,
        collection_errors=recorder.collection_errors, timed_out=recorder.timed_out,
        invalid_reasons=post, incomplete_reason=incomplete_reason,
        interpreter=interpreter,
    )


def _build_result(
    plan_doc: dict,
    order: list[str],
    scope: str,
    *,
    executed: list[str],
    outcomes: dict[str, str],
    phases: dict[str, list[str]],
    durations: dict[str, float],
    exit_code: int,
    duration_s: float,
    collection_errors: int,
    timed_out: bool,
    invalid_reasons: list[str],
    incomplete_reason: str | None,
    interpreter: str | None = None,
) -> dict:
    """把事实组装成一份 v1 execution_result（三维度各说各的，绝不互相顶替）。"""
    executed_set = set(executed)
    not_executed = [node_id for node_id in order if node_id not in executed_set]

    validity = "invalid" if invalid_reasons else "valid"
    # complete 表示"计划内测试全部跑完"，因此**至少得有一个测试**：order 为空时 executed 与
    # not_executed 都是空，vacuous 地判 complete 会把"跑 0 个"包装成完整通过——正是契约
    # 明令禁止的零执行陷阱。
    completeness = "complete" if order and not_executed == [] and not timed_out else "incomplete"

    facts = {
        node_id: {
            "outcome": outcomes[node_id],
            "phases": list(phases.get(node_id, [])),
            "duration_s": round(durations.get(node_id, 0.0), 6),
        }
        for node_id in executed
    }
    failed = [n for n in executed if outcomes.get(n) == "failed"]
    errored = [n for n in executed if outcomes.get(n) == "error"]

    result: dict = {
        "protocol_version": plan_doc["protocol_version"],  # 回显计划版本以维持绑定一致
        "product_version": f"smart-test-sorter/{__version__}",
        "request_id": plan_doc["request_id"],
        "plan_id": plan_doc["plan_id"],
        "target_identity": plan_doc["target_identity"],
        "selection_scope": scope,
        "completeness": completeness,
        "validity": validity,
        "executed": executed,
        "not_executed": not_executed,
        "outcomes": facts,
        "raw_exit_code": int(exit_code),
        "duration_s": round(duration_s, 6),
        "failure_categories": {
            "assertion": len(failed),
            "collection": collection_errors,
            "environment": len(errored),
            "cancelled": 1 if timed_out else 0,
        },
    }
    if validity == "invalid":
        result["invalid_reason"] = "；".join(invalid_reasons)
    if completeness == "incomplete":
        result["incomplete_reason"] = incomplete_reason or "计划内测试未跑完"

    if plan_doc.get("protocol_version") == "2.0":
        result = _upgrade_to_v2(result, plan_doc, interpreter=interpreter)
    return result


def _now_iso() -> str:
    """UTC ISO-8601（秒精度，带 Z）。执行时刻是**事实**，不能空着也不能编。"""
    import datetime

    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def _upgrade_to_v2(result: dict, plan_doc: dict, *, interpreter: str | None = None) -> dict:
    """把执行事实升成 2.0 形状（**只加表达，不改事实**）。

    2.0 相对 1.1 新增两个**必填**：`content_identity` 与 `execution_identity`。
    - `content_identity`：**照抄计划里那三项**（kind/value/manifest_digest）。
      执行侧**不重算**——它执行的就是计划所指的那份内容，重算反而是另一个口径。
      （VG 0040 提的『同名字段不同形状』是**有原因的**：`observed_at` 是规划期的观察，
      执行侧对应的是 `observations`。）
    - `execution_identity`：**执行事实**，只有执行侧知道 ⇒ 这里填，`interpreter` 用**实际用的那个**
      （`sys.executable` 或宿主显式给的那个），不是从计划里抄——那正是
      VG 0042 §四③ 裁定的"由执行侧写"。
    - `observations`：执行前后各**观察**一次目标身份；观察不到写 `unconfirmed`，
      **不写 `confirmed` 也不省略**（省略会被读成"核对通过"）。
    """
    ci = plan_doc.get("content_identity") or {}
    env = plan_v2.environment_identity_now()
    return {
        **result,
        "content_identity": {
            "kind": ci.get("kind"),
            "value": ci.get("value"),
            "manifest_digest": ci.get("manifest_digest"),
        },
        "execution_identity": {
            "execution_id": f"exec-{plan_doc.get('plan_id', 'unknown')}",
            "interpreter": interpreter or sys.executable,
            "started_at": _now_iso(),
        },
        "environment_identity": env,
        "observations": {
            # 执行侧的观察只有"内容身份有没有变"这一件；没观察 ⇒ unconfirmed。
            "before_execution": "confirmed" if not result.get("invalid_reason") else "mismatch",
            "after_execution": "confirmed" if result.get("validity") == "valid" else "mismatch",
        },
    }


def build_parser() -> argparse.ArgumentParser:
    """入口参数：宿主显式给解释器 + 模块 + 计划文件，不依赖开发机隐式 PATH。"""
    parser = argparse.ArgumentParser(
        prog="smart_sorter.run_plan",
        description="按 v1 test_plan 执行 pytest 并产出 v1 execution_result（或机器可读错误）。",
    )
    parser.add_argument("--plan", required=True, help="要执行的 test_plan JSON 文件路径")
    parser.add_argument("--out", default=None,
                        help="把 execution_result JSON 写到该文件（stdout 仍输出同一份）")
    parser.add_argument("--output-only", action="store_true", help="结果只写 --out，不在 stdout 重复")
    parser.add_argument("--cwd", default=None,
                        help="分析根（候选目录或 repo.path）；nodeid 相对它。默认当前目录")
    parser.add_argument("--request", default=None,
                        help="对应的 candidate_request JSON；给了就核对目标身份与环境")
    parser.add_argument("--test-dir", default="tests",
                        help="目标仓库内测试目录名，默认 tests（须与生成计划时一致）")
    parser.add_argument("--timeout", type=int, default=None,
                        help="执行阶段预算秒数（协作式：在每个测试之间检查）")
    parser.add_argument("--full", action="store_true",
                        help="关闭选择：跑计划的 collected 全集，结果如实标 selection_scope=full")
    parser.add_argument("--isolated", action="store_true",
                        help="在**独立解释器进程**里执行（默认在进程内跑）。宿主/编排按固定计划跑一次时"
                             "用不上它；需要『整条臂与别的执行互不污染』时（例如自己做 A/B 对拍）才开。"
                             "影子入口 smart_sorter.shadow 两臂默认就是独立的。")
    return parser


def main(argv: list[str] | None = None) -> int:
    """入口主流程。返回进程退出码 0/1/3（产出结果）或 2（用法/输入错误）。"""
    plan_request._force_utf8_output()
    args = build_parser().parse_args(argv)
    if args.output_only and not args.out:
        return _usage_error("--output-only 需要 --out")

    def log(message: str) -> None:
        print(f"[run_plan] {message}", file=sys.stderr)

    root = str(Path(args.cwd or os.getcwd()).resolve())
    if not Path(root).is_dir():
        return _usage_error(f"分析根不存在或不是目录 -> {root}")

    try:
        plan_doc = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return _usage_error(f"计划文件不存在 -> {args.plan}")
    except OSError as exc:
        return _usage_error(f"计划文件不可读 -> {args.plan}：{exc}")
    except json.JSONDecodeError as exc:
        return _usage_error(f"计划文件不是合法 JSON -> {args.plan}：{exc}")

    if not isinstance(plan_doc, dict):
        return _usage_error("计划文件顶层必须是 JSON 对象")

    # 未知协议版本必须显式拒绝：契约的 _semantic_plan 只校结构+跨字段语义，不查版本白名单
    # （request/refusal 查、plan/result 不查，是契约侧的一处不对称）。执行入口不能指望它，
    # 否则一个 protocol_version=9.9 的计划会被照跑。已作为偏差交回契约维护方。
    #
    # **2026-10-04（VG 0043 §二② 那条支）**：这条门原先只认 1.0/1.1，于是 2.0 计划
    # **根本进不了执行**。改走 `contract_trees` 单点选树——与 plan_request 同一套口径，
    # 免得"版本路由散落在各入口"（那正是 0042 §二 抓到 CLI 崩的那类问题的根）。
    plan_version = plan_doc.get("protocol_version")
    try:
        contract_trees.tree_for(plan_version, producing=True)
    except contract_trees.UnsupportedProtocol as exc:
        return _usage_error(
            f"计划的协议版本 {plan_version!r} 不受支持（本实现支持 "
            f"{sorted(contract_trees.SUPPORTED_TREES)}），拒绝而非静默兼容：{exc}"
        )

    plan_errors = (contracts.validate(plan_doc, "plan") if plan_version == "1.1"
                   else contract_trees.validate_against(plan_doc, "plan", plan_version))
    if plan_errors:
        # 不合契约的计划不执行：连"计划身份"都不可信，产物无从绑定。
        return _usage_error(f"计划不符合 {plan_version} 契约：" + "；".join(plan_errors))

    request = None
    if args.request:
        try:
            request = json.loads(Path(args.request).read_text(encoding="utf-8"))
        except FileNotFoundError:
            return _usage_error(f"请求文件不存在 -> {args.request}")
        except (OSError, json.JSONDecodeError) as exc:
            return _usage_error(f"请求文件不可读 -> {args.request}：{exc}")
        if not isinstance(request, dict):
            return _usage_error("请求文件顶层必须是 JSON 对象")

    kind, doc = execute_plan(
        plan_doc, root=root, test_dir=args.test_dir, timeout_s=args.timeout,
        full=args.full, request=request, isolated=args.isolated, log=log,
    )
    if kind == "error":
        return _usage_error(doc["reason"])

    text = json.dumps(doc, ensure_ascii=False, indent=2)
    if args.out:
        try:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
        except OSError as exc:
            return _usage_error(f"无法写出 {args.out}：{exc}")
        log(f"已写出 {args.out}")
    if not args.output_only:
        print(text)

    # 自产结果必须过**它自己声明的版本**对应的契约树（1.1 走原路径，行为一字未变）。
    # 2026-10-04 修：这里原先固定用 v1，于是 2.0 result 被自己的入口判成
    # 「出现未声明字段 content_identity」而退 2——**与 VG 0042 抓到的那处同类**：
    # 版本路由散落在主要路径之外。两处都已改走 `contract_trees` 单点。
    doc_version = doc.get("protocol_version")
    errors = (contracts.validate(doc, "result") if doc_version == "1.1"
              else contract_trees.validate_against(doc, "result", doc_version))
    if errors:
        log(f"内部错误：生成的结果不符合 {doc_version} 契约：{errors}")
        return _EXIT_USAGE

    attempted = len(plan_doc["collected"] if args.full else plan_doc["order"])
    log(
        f"plan={doc['plan_id']} target={doc['target_identity']} "
        f"scope={doc['selection_scope']} completeness={doc['completeness']} "
        f"validity={doc['validity']} executed={len(doc['executed'])}/{attempted} "
        f"exit={doc['raw_exit_code']}"
    )
    return _exit_code_for(doc)


def _exit_code_for(doc: dict) -> int:
    """退出码口径：3 完整性/有效性优先，其次 1 有失败，最后 0 干净（与 VG 只降不升同序）。"""
    if doc["validity"] != "valid" or doc["completeness"] != "complete":
        return _EXIT_NOT_CLEAN
    bad = [o for o in doc["outcomes"].values() if o.get("outcome") in ("failed", "error")]
    return _EXIT_FAILURES if bad else _EXIT_CLEAN


def _usage_error(reason: str) -> int:
    """进程级用法/输入错误：stderr 出人类原因，stdout 出一行机器可读错误对象。"""
    print(f"[run_plan] 错误：{reason}", file=sys.stderr)
    print(json.dumps(
        {"ok": False, "error_kind": "input-error", "reason": reason}, ensure_ascii=False,
    ))
    return _EXIT_USAGE


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
