"""真实测试收集（pytest --collect-only）——standalone CLI 与宿主请求入口的唯一实现。

为什么单独一个模块：TF-0020/TF-0027 要求"同一规范化输入经 standalone 与宿主请求入口得到
相同的测试集合"。收集是这条链上唯一真正跑外部进程的一步，如果两处各写一份，nodeid 解析、
退出码归类、超时口径迟早会漂移。因此收集只有这一份实现，两个入口都调它。

收集是【事实】而非推测：collected 必须是目标目录上真跑 pytest 得到的 nodeid（保留参数化
后缀与大小写），本模块绝不臆造、绝不用空列表冒充"没有测试"。

nodeid 一律**相对分析根**（命令行显式 `--rootdir=<repo_path>`）：这样 plan.order 里每个
nodeid 都是"在分析根下可直接执行"的，宿主按配置拼 `pytest <nodeid>` 时不会因为外层仓库的
pyproject.toml 抢走 rootdir 而找不到文件。

归类（对应契约 plan_refusal.refusal_code）：
  - succeeded=False, code="dependency-unavailable"  解释器/pytest 不可用（环境问题）
  - succeeded=False, code="collection-error"        pytest 跑了但收集失败/0 用例/超时
  - succeeded=True                                   拿到非空 nodeid 全集
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

# 收集是只读操作，但大仓库的 --collect-only 也会跑 conftest；给一个上限避免宿主卡死。
DEFAULT_TIMEOUT_SECONDS = 300

# pytest 在"没装 pytest"时的典型 stderr 片段（退出码 1，极易与真实收集错误混淆）。
_MISSING_PYTEST_MARKERS = (
    "No module named pytest",
    "No module named 'pytest'",
)

# 只依赖所选解释器里的 pytest/标准库，无需给目标环境安装 STS 或 JSON 插件。
# 与 run_plan 的 recorder 一样读 pytest 对象；终端输出只用于错误诊断。
_COLLECT_SCRIPT = """
import json
import sys
from pathlib import Path
import pytest

output = Path(sys.argv[1])
class Recorder:
    errors = 0
    deselected = 0
    def pytest_collectreport(self, report):
        self.errors += int(report.failed)
    def pytest_deselected(self, items):
        self.deselected += len(items)
    @pytest.hookimpl(trylast=True)
    def pytest_sessionfinish(self, session, exitstatus):
        output.write_text(json.dumps({
            'nodeids': [item.nodeid for item in session.items],
            'errors': self.errors, 'deselected': self.deselected,
        }), encoding='utf-8')
raise SystemExit(pytest.main(sys.argv[2:], plugins=[Recorder()]))
"""


@dataclass(frozen=True)
class CollectionResult:
    """一次收集尝试的结果。succeeded=True 时 nodeids 非空且是可信的测试全集。

    returncode 是**那次真实 pytest 进程的原始退出码**（解释器根本起不来时为 None）——
    执行入口要用它作 execution_result.raw_exit_code，所以不能在这里吞掉。
    """

    nodeids: list[str]
    succeeded: bool
    code: str
    detail: str
    returncode: int | None = None
    # 仅供实验诊断；生产调用不得把部分收集当成全集。
    partial_nodeids: list[str] = field(default_factory=list)
    collection_errors: int = 0


def collect_nodeids(
    repo_path: str,
    test_dir: str = "tests",
    *,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    python: str | None = None,
    extra_args: list[str] | None = None,
) -> CollectionResult:
    """在 repo_path 里跑 `python -m pytest --collect-only`，返回结构化收集结果。

    **nodeid 一律相对分析根**：命令行显式传 `--rootdir=<repo_path>`。不这么做的话，pytest 会
    沿目录树向上找 pyproject.toml/setup.cfg 之类的配置文件，把 rootdir 定在**外层仓库**上，
    于是候选目录在别人仓库里时 nodeid 会变成 `experiments/.../wt/tests/test_x.py::test_a`——
    宿主拿它去候选目录里跑 pytest 就找不到文件。计划里的 order 必须是"在分析根下可直接执行"
    的确定排列，所以这里把 rootdir 钉死在分析根上。

    参数:
        repo_path: 收集的工作目录（候选模式传【候选目录】，绝不退回 STS 源码目录）。
        test_dir:  仓库内测试目录名（相对 repo_path）。
        python:    显式解释器；默认 sys.executable（= 宿主选定的解释器，不依赖 PATH）。
    """
    root = str(Path(repo_path).resolve())
    cmd = [
        python or sys.executable, "-c", _COLLECT_SCRIPT,
    ]
    pytest_args = [
        "--collect-only", "-q",
        "--no-header", "--rootdir", root, "-p", "no:cacheprovider", test_dir,
        *(extra_args or []),
    ]
    data = {}
    try:
        with tempfile.TemporaryDirectory(prefix="sts-collect-") as directory:
            output = Path(directory) / "collection.json"
            proc = subprocess.run(
                [*cmd, str(output), *pytest_args], cwd=root, capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=timeout,
            )
            if output.is_file():
                try:
                    data = json.loads(output.read_text(encoding="utf-8"))
                except (ValueError, UnicodeError):
                    data = {}
    except subprocess.TimeoutExpired:
        return CollectionResult(
            [], False, "collection-error",
            f"pytest --collect-only 超时（>{timeout}s，test_dir={test_dir}）",
        )
    except OSError as exc:
        # 解释器不存在/不可执行：这是环境依赖问题，不是"收集到 0 个测试"。
        return CollectionResult(
            [], False, "dependency-unavailable",
            f"无法启动 pytest（解释器 {cmd[0]}）：{exc}",
        )

    stderr = proc.stderr or ""
    if proc.returncode != 0 and any(m in stderr for m in _MISSING_PYTEST_MARKERS):
        return CollectionResult(
            [], False, "dependency-unavailable",
            f"指定解释器里没有 pytest（{cmd[0]}）：{_first_line(stderr)}",
            returncode=proc.returncode,
        )

    valid_report = (
        isinstance(data, dict) and isinstance(data.get("nodeids"), list)
        and all(isinstance(n, str) and n for n in data["nodeids"])
        and type(data.get("errors")) is int and data["errors"] >= 0
        and type(data.get("deselected")) is int and data["deselected"] >= 0
    )
    # Collection order is a pytest fact. Sorting here would silently reorder
    # forced-full execution and the planner's stable tie-breaks.
    ids = list(dict.fromkeys(data["nodeids"])) if valid_report else []
    errors = data["errors"] if valid_report else 0
    if proc.returncode != 0 or errors:
        return CollectionResult(
            [], False, "collection-error",
            f"pytest --collect-only 退出码 {proc.returncode}（test_dir={test_dir}）："
            f"{_first_line(stderr) or _first_line(proc.stdout or '')}",
            returncode=proc.returncode,
            partial_nodeids=ids if proc.returncode == 2 and errors else [],
            collection_errors=errors,
        )

    if not valid_report or data["deselected"]:
        return CollectionResult(
            [], False, "collection-error", "收集报告缺失/无效或测试被预先剔除，不能确认测试全集",
            returncode=proc.returncode,
        )
    if not ids:
        return CollectionResult(
            [], False, "collection-error",
            f"pytest --collect-only 未收集到任何测试（test_dir={test_dir}）",
            returncode=proc.returncode,
        )
    return CollectionResult(
        ids, True, "", f"收集到 {len(ids)} 个 nodeid（test_dir={test_dir}）",
        returncode=proc.returncode,
    )


def _first_line(text: str) -> str:
    """取第一行非空文本，用于把长 stderr 压成一句可读原因。"""
    for line in text.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return ""
