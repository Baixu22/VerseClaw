"""真实试用轨迹与"选择模式启用范围"的决定（TF-0015）。

## 它回答什么问题

影子验证（TF-0013）回答**一次**选择漏没漏；本模块回答**一段时间、一批项目上**该不该开选择：

- 把每一次影子验证的**配对结果**记成一条轨迹样本（同一目标版本上"按计划跑" vs "全量跑"）；
- 按**项目 × 变化类型**分别算指标：配对端到端耗时、**首个失败时间**、回退率、
  失败/无法判定的分母、选择的降时比例；
- 只有**证据覆盖到位**的层（stratum）才建议启用选择；其余一律保持关闭。

## 两条入口

```bash
# 记一条真实试用样本（报告由 python -m smart_sorter.shadow 真跑产出）
python -m smart_sorter.trial record --report shadow-report.json \
    --project <项目名> --change-type <变化类型> [--ledger usage.jsonl]

# 由轨迹算出"启用范围"决定
python -m smart_sorter.trial decide --ledger usage.jsonl --out policy.json \
    [--min-samples N] [--min-revisions R] [--min-days D] [--target-saving 0.40]
```

## 决定规则（写死，可复算）

某一层（项目 × 变化类型）**启用选择**必须同时满足：

1. **量够**：**干净**可判定的配对样本 ≥ `--min-samples`（默认 3）——
   「判不了」的样本（不可比、或漏选只能归因为不稳定/运行错误）**不算**；
2. **独立覆盖够**：这些样本横跨 ≥ `--min-revisions` 个**不同目标版本**（`target_identity`，
   默认 2）——同一个版本重复跑 50 次仍然是"1 个版本"，不是覆盖；
   报告里同时给出 `distinct_days` / `elapsed_days` 作为**信号**（供人判断这批证据是不是
   集中在同一天/同一批条件里），**但日历默认不是门槛**（`--min-days` 默认 0 = 不设日历门槛）。
   想按日历守时（例如"必须跨两周真实使用"）就显式给 `--min-days 14`，那时它才是硬条件；
3. **零确定漏选 + 不确定/矛盾一票否决**：该层不能有任何"确定失败被漏掉"
   （`missed_failures` 一条都不能有）；`missed-indeterminate`（判不了）、两臂互相矛盾、
   以及**旧样本缺"是否矛盾"这条信息**，都不得作为干净成功证据；
4. **有真实正净收益**：平均降时必须 **> 0**。全是全量回退（省不下）不算，
   选择比全量还慢（负收益）更不算——负收益如实带符号报告，不截断成 0。

> **为什么这几条要一起守**（2026-10-01 口径收紧，用户裁定）：审计用**契约合法**的输入证明过，
> 旧口径下三条跨版本的 `missed-failures-indeterminate` 样本 + 平均节省 0 就能得到
> `enable-listed-strata`——门槛比它自己文档写的"零确定漏选 + 确实省得下"弱。
> 「判不了」不是「没漏」，两臂矛盾也不是「成功」，省不下更不是「收益」。

> **为什么日历默认不再是门槛**（2026-09-29 产品口径调整）：日历只是"样本独立性"的**弱代理**。
> 对这类项目，两周等待既拖慢节奏，又不保证样本更独立（同一个项目的同一批测试、同一台机器）。
> 真正要守的是①量、②跨版本独立性、③零确定漏选、④确实省得下——这四条都能当场算出来，
> 于是证据循环从"两周"变成"几分钟"，而**不牺牲任何安全条件**：
> 确定漏选照样一票否决，且跨时间稳定性作为 `distinct_days`/`elapsed_days` 信号如实报告出来，
> 让"这批证据集中在一天"这件事看得见，而不是被日历门槛替我们下结论。

任一条不满足就**保持关闭**，并把理由逐条写进策略文件。默认 `default_enabled=false`：
选择在本产品里始终是**选择性开启**（pytest 不加 `--smart-select` 即为关闭），
关闭后仍可完整验证（`shadow --mode full` 就是那条路径，且会被记成
`full-verification` 样本一起进账本）。

## 40% 降时目标：如实报告，不许把漏检改记为零

原探索目标是"平均降时 40%"。本模块不改这个目标，但把**两种口径**都算出来：

- `production_saving_ratio`：只看"生产路径"的耗时（选中集耗时 / 全量耗时），配对影子跑的那次
  全量属于试用的代价、不算在生产收益里；
- `charged_saving_ratio`：**有确定漏选的样本按 0 收益计**（那次漏检必须靠全量才发现，
  不能因为"晚上又补跑了一次全量"就把白天的漏检改记成零成本）。

达标与否都如实写进策略文件（`target.met` / `target.met_charged`）。降时只统计**两次运行都报了耗时**
的样本（`saving_ratio_samples` 写明用了几条）：拿不到耗时就是拿不到，不按 0 顶替。

## 产物不是对外协议

`smart-test-sorter/usage-sample/v1`（账本条目）与 `smart-test-sorter/selection-enablement/v1`
（策略）都是**本产品自己的验证产物**，不进 VG—STS 契约；账本是**只追加**的 JSONL。
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

from smart_sorter import __version__, plan_request, shadow

LEDGER_SCHEMA = "smart-test-sorter/usage-sample/v1"
POLICY_SCHEMA = "smart-test-sorter/selection-enablement/v1"
#: 启用规则的版本身份（**本产品自己的研究产物**，不进 VG—STS 契约）。
#: v1 = 2026-09-29 口径（门槛只问"零确定漏选 + 不是全部回退全量"）；
#: v2 = 2026-10-01 口径收紧（用户裁定）：判不了/两臂矛盾/矛盾未知的样本不算干净覆盖，
#:      且"正净收益"成为硬门槛（负收益带符号报告、不再截断成 0）。
#: 旧产物不改写，按它自己的 v1 解释；新产物一律带 v2。
RULE_VERSION = "enablement/v2"

DEFAULT_LEDGER = "usage-ledger.jsonl"
DEFAULT_MIN_SAMPLES = 3
# 日历默认**不是**门槛：它只是"样本独立性"的弱代理，对这类项目会拖慢节奏而不保证独立性。
# 覆盖由「量 + 跨版本独立性」承担；想按日历守时请显式 --min-days 14。
DEFAULT_MIN_DAYS = 0
# 独立性地板：样本至少要横跨两个不同目标版本，否则"同一版本重复跑"不能算覆盖。
DEFAULT_MIN_REVISIONS = 2
DEFAULT_TARGET_SAVING = 0.40

_EXIT_OK = 0
_EXIT_USAGE = 2
_EXIT_EMPTY = 3

STATUS_OK = "ok"
STATUS_MISSED_DEFINITE = "missed-definite"
STATUS_MISSED_INDETERMINATE = "missed-indeterminate"
STATUS_UNDECIDABLE = "undecidable"
STATUS_FULL_VERIFICATION = "full-verification"

#: 用户的意图（"生产路径"），与"试用代价"不同：见模块 docstring。
_USAGE_STATUSES = {STATUS_OK, STATUS_MISSED_DEFINITE, STATUS_MISSED_INDETERMINATE, STATUS_UNDECIDABLE}


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def first_failure_seconds(run: dict | None) -> float | None:
    """一次运行里"跑到第一个失败"用掉的测试耗时（按实际执行顺序累加）。

    只累加测试自身的 `duration_s`（不含解释器启动、收集、固定开销），因此它是一个
    **可用于跨运行比较**的相对量，不是墙钟时间。没有失败就是 None（不是 0）。
    """
    if not run:
        return None
    outcomes = run.get("outcomes") or {}
    total = 0.0
    for node_id in run.get("executed") or []:
        fact = outcomes.get(node_id) or {}
        total += float(fact.get("duration_s") or 0.0)
        if fact.get("outcome") in ("failed", "error"):
            return round(total, 6)
    return None


def _failed_or_error(run: dict | None) -> set[str]:
    """一次运行里 outcome 为 failed/error 的 nodeid 集合（与 `shadow._bad_tests` 同口径）。"""
    if not isinstance(run, dict):
        return set()
    return {
        node_id
        for node_id, outcome in (run.get("outcomes") or {}).items()
        if isinstance(outcome, dict) and outcome.get("outcome") in ("failed", "error")
    }


def _contradictions(report: dict) -> tuple[list[str], bool]:
    """两臂互相矛盾的测试 + 「这条信息是否已知」。

    **优先**读报告里已经记下的 `comparison.contradictory_runs`（2026-10-01 之后写的报告都有）。
    收紧之前写下的 shadow 报告没有这个字段——按"旧证据不改写、能从原始报告重算就重算"的口径，
    这里用报告里**原样内嵌的两次运行**（`runs.selected` / `runs.full`）按与 `shadow.compare`
    完全相同的定义重算：两个方向（选中集失败而全量通过、全量失败而选中集跑了却通过）取并集。

    连原始运行都没有（例如只有 `mode=full`、根本没有选中臂）时返回 `known=False`：
    **未知不等于干净**，`build_policy` 会据此阻断资格。
    """
    comparison = report.get("comparison") or {}
    if comparison.get("contradictory_runs") is not None:
        return sorted(comparison.get("contradictory_runs") or []), True
    runs = report.get("runs") or {}
    selected, full = runs.get("selected"), runs.get("full")
    if not isinstance(selected, dict) or not isinstance(full, dict):
        return [], False
    if "outcomes" not in selected or "outcomes" not in full:
        return [], False
    selected_bad = _failed_or_error(selected)
    full_bad = _failed_or_error(full)
    full_failed_selected_passed = (full_bad & set(selected.get("executed") or [])) - selected_bad
    return sorted((selected_bad - full_bad) | full_failed_selected_passed), True


def sample_from_report(
    report: dict, *, project: str, change_type: str,
    recorded_at: str | None = None, note: str = "",
) -> dict:
    """把一份真实的影子报告压成一条**试用样本**（含逐项归因）。

    只接受 `smart-test-sorter/shadow-report/v1`：别的文件不认，绝不硬猜字段。
    """
    if not isinstance(report, dict):
        raise ValueError(f"影子报告顶层必须是 JSON 对象（实际 {type(report).__name__}）")
    if report.get("schema") != shadow.REPORT_SCHEMA:
        raise ValueError(
            f"不是 {shadow.REPORT_SCHEMA}（实际 {report.get('schema')!r}）："
            "试用样本只能来自真实跑出的影子报告"
        )
    comparison = report.get("comparison") or {}
    if not isinstance(comparison, dict):
        raise ValueError(f"影子报告的 comparison 必须是对象（实际 {type(comparison).__name__}）")
    mode = report.get("mode")
    scope = report.get("selection_scope")
    timing = report.get("timing") or {}
    selected_duration = timing.get("selected_duration_s")
    full_duration = timing.get("full_duration_s")

    if mode == "full":
        status = STATUS_FULL_VERIFICATION
    elif not comparison.get("comparable"):
        status = STATUS_UNDECIDABLE
    elif comparison.get("missed_failures"):
        status = STATUS_MISSED_DEFINITE
    elif comparison.get("missed_failures_indeterminate"):
        status = STATUS_MISSED_INDETERMINATE
    else:
        status = STATUS_OK

    not_definite = (report.get("flakiness") or {}).get("not_definite") or {}
    contradictions, contradiction_known = _contradictions(report)
    attribution = []
    for node_id in comparison.get("missed_failures") or []:
        attribution.append({
            "nodeid": node_id, "kind": "definite",
            "reason": "全量里失败、选中集没跑到，且没有任何不稳定/运行错误证据 ⇒ 确定的漏选",
        })
    for node_id in comparison.get("missed_failures_indeterminate") or []:
        attribution.append({
            "nodeid": node_id, "kind": "indeterminate",
            "reason": not_definite.get(node_id)
            or "有证据说明它不是确定的断言失败（不稳定或运行错误）⇒ 判不了，不算确定漏选",
        })
    for node_id in (report.get("runs", {}).get("full") or {}).get("not_executed") or []:
        attribution.append({
            "nodeid": node_id, "kind": "not-executed",
            "reason": "全量那次也没跑到它（未跑完/被取消）⇒ 不是漏选证据",
        })

    paired = None
    if selected_duration is not None and full_duration is not None:
        paired = round(float(selected_duration) + float(full_duration), 6)

    return {
        "schema": LEDGER_SCHEMA,
        "recorded_at": recorded_at or _utc_now(),
        "project": project,
        "change_type": change_type,
        "note": note,
        "report": None,          # 由调用方按需填（账本里保留相对/绝对路径由 CLI 决定）
        "mode": mode,
        "status": status,
        "target_identity": report.get("target_identity"),
        "plan_id": report.get("plan_id"),
        "selection_scope": scope,
        "fallback": bool(scope == "full" and mode != "full"),
        # 全量回退的原因如实留着：省不下时间时要能说清是政策保守，而不是"选择没效果"。
        "fallback_reasons": list(report.get("plan_fallback") or []),
        "verdict": comparison.get("verdict"),
        "selected_duration_s": selected_duration,
        "full_duration_s": full_duration,
        "paired_duration_s": paired,
        "first_failure_s_selected": first_failure_seconds(
            (report.get("runs") or {}).get("selected")
        ),
        "first_failure_s_full": first_failure_seconds((report.get("runs") or {}).get("full")),
        "collected_count": comparison.get("collected_count"),
        "selected_count": comparison.get("selected_count"),
        # 这次影子跑带了哪些不稳定证据、有没有因为"目标版本对不上"被拒绝（如实留档）。
        "evidence_sources": list((report.get("flakiness") or {}).get("evidence_sources") or []),
        "rejected_evidence": dict((report.get("flakiness") or {}).get("rejected_sources") or {}),
        "missed_definite": list(comparison.get("missed_failures") or []),
        "missed_indeterminate": list(comparison.get("missed_failures_indeterminate") or []),
        # 两臂互相矛盾的测试（全量失败、选中集跑了却通过 / 反向）：既不是漏检也不是干净成功
        # （2026-10-01 口径收紧）。`contradiction_known` 用来区分「明确没有矛盾」与
        # 「这份旧报告里根本没记这条」——后者是未知，不能当成干净样本。
        # 旧报告能从原始两次运行重算的就重算（见 `_contradictions`），不改写旧文件。
        "contradictory_runs": contradictions,
        "contradiction_known": contradiction_known,
        "attribution": attribution,
        "full_completeness": ((report.get("runs") or {}).get("full") or {}).get("completeness"),
        "full_validity": ((report.get("runs") or {}).get("full") or {}).get("validity"),
    }


def _saving_ratio(sample: dict) -> float:
    """生产路径的降时比例（选中集 vs 全量）。全量没耗时/回退全量 ⇒ 0，不编数。

    **保留符号**（2026-10-01 口径收紧）：选择比全量还慢时如实报负数，不再 `max(0.0, …)` 截断。
    截断会把「选择有害」粉饰成「没省下但无害」，而这正是启用建议最该看见的一格。
    """
    if sample["status"] == STATUS_FULL_VERIFICATION or sample.get("fallback"):
        return 0.0
    selected = sample.get("selected_duration_s")
    full = sample.get("full_duration_s")
    if not selected or not full or full <= 0:
        return 0.0
    return 1.0 - float(selected) / float(full)


def _mean(values: list[float]) -> float | None:
    return round(statistics.fmean(values), 6) if values else None


def summarize(samples: list[dict]) -> dict:
    """一组样本的指标（纯函数）。`samples` 里混有 full-verification 时会被分开统计。

    三条口径写死，避免"用数字掩盖没有数据"：

    - **降时只统计"两次运行都报了耗时"的样本**：拿不到耗时就如实标 `saving_ratio_samples` 少一个，
      不拿 0 顶替（0 是"没省下"，不是"没数据"）；
    - **日期门槛只看干净样本占用的日期**：判不了的样本不构成证据覆盖，不能帮某一层凑够两周；
    - **`clean_samples` 才是"干净可判定样本"**（2026-10-01 口径收紧）：它排除
      `undecidable`（两臂不可比）、`missed-indeterminate`（判不了）、两臂矛盾、
      以及**旧报告里没记"是否矛盾"**的未知样本。`decidable_samples` 保留旧口径以便对账，
      但**门槛用 `clean_samples`**——"判不了"不等于"没漏"。
    """
    usage = [s for s in samples if s.get("status") in _USAGE_STATUSES]
    verifications = [s for s in samples if s.get("status") == STATUS_FULL_VERIFICATION]
    decidable = [s for s in usage if s.get("status") != STATUS_UNDECIDABLE]
    # 干净样本：排掉判不了、矛盾与"是否矛盾未知"三类。
    # **只有明确 True 才算已知**：字段缺失（收紧前写下的账本条目）同样是未知——未知不减分
    # 变成加分，否则旧账本会凭"没记这条"自动升级成干净样本。
    clean = [
        s for s in decidable
        if s.get("status") != STATUS_MISSED_INDETERMINATE
        and not (s.get("contradictory_runs") or [])
        and s.get("contradiction_known") is True
    ]
    timed = [
        s for s in clean
        if s.get("selected_duration_s") is not None and s.get("full_duration_s") is not None
    ]

    savings = [_saving_ratio(s) for s in timed]
    # 确定漏选的样本按 0 收益计：漏检是靠全量才发现的，不因为事后补跑而变成"省了"。
    # 收益带符号之后，"计 0"不能把负收益**洗成正的**（那等于用一次漏检换掉一次变慢的惩罚），
    # 所以取 min(原始收益, 0)：保证 charged 永远不优于原始读数。
    charged = [
        min(0.0, _saving_ratio(s)) if s.get("status") == STATUS_MISSED_DEFINITE else _saving_ratio(s)
        for s in timed
    ]
    # 门槛用的日期只数**干净**样本；`all_sample_days` 是含判不了样本的原始计数（仅供阅读）。
    clean_days = sorted(
        {(s.get("recorded_at") or "")[:10] for s in clean if s.get("recorded_at")}
    )
    all_days = sorted({(s.get("recorded_at") or "")[:10] for s in usage if s.get("recorded_at")})
    # 独立覆盖的主指标：干净样本横跨多少个不同目标版本（日历只作弱信号）。
    clean_revisions = sorted(
        {s.get("target_identity") for s in clean if s.get("target_identity")}
    )
    clean_verifications = [
        s for s in verifications
        if s.get("full_completeness") == "complete" and s.get("full_validity") == "valid"
    ]
    stamps = [s.get("recorded_at") for s in usage if s.get("recorded_at")]

    return {
        "samples": len(usage),
        # 门槛用的分母（干净）；`decidable_samples` 保留旧口径，便于与历史读数对账。
        "clean_samples": len(clean),
        "decidable_samples": len(decidable),
        "undecidable_samples": len([s for s in usage if s.get("status") == STATUS_UNDECIDABLE]),
        "contradictory_samples": len([s for s in usage if s.get("contradictory_runs") or []]),
        "unknown_contradiction_samples": len([
            s for s in usage if s.get("contradiction_known") is not True
        ]),
        "definite_miss_samples": len([s for s in usage if s.get("status") == STATUS_MISSED_DEFINITE]),
        "indeterminate_miss_samples": len(
            [s for s in usage if s.get("status") == STATUS_MISSED_INDETERMINATE]
        ),
        # 失败/未跑完的分母把 full-verification 样本也算进去：它们同样可能是一次失败的运行。
        "failed_run_samples": len([
            s for s in samples
            if s.get("full_completeness") != "complete" or s.get("full_validity") != "valid"
        ]),
        # "关掉选择后仍可完整验证"只认**有效且跑完**的 full 样本；跑坏的单独计数。
        "full_verification_samples": len(clean_verifications),
        "full_verification_failed_samples": len(verifications) - len(clean_verifications),
        "fallback_samples": len([s for s in decidable if s.get("fallback")]),
        "fallback_rate": (round(len([s for s in decidable if s.get("fallback")]) / len(decidable), 6)
                          if decidable else None),
        "fallback_reasons": sorted({
            reason for s in decidable for reason in (s.get("fallback_reasons") or [])
        }),
        # 带过证据、但因目标版本不同被拒绝的样本数（"证据不许跨版本开脱"的可看见证据）。
        "rejected_evidence_samples": len([s for s in usage if s.get("rejected_evidence")]),
        "paired_duration_s_mean": _mean(
            [float(s["paired_duration_s"]) for s in decidable if s.get("paired_duration_s") is not None]
        ),
        "full_duration_s_mean": _mean(
            [float(s["full_duration_s"]) for s in decidable if s.get("full_duration_s") is not None]
        ),
        "selected_duration_s_mean": _mean(
            [float(s["selected_duration_s"]) for s in decidable
             if s.get("selected_duration_s") is not None]
        ),
        "first_failure_s_selected_mean": _mean(
            [float(s["first_failure_s_selected"]) for s in decidable
             if s.get("first_failure_s_selected") is not None]
        ),
        "first_failure_s_full_mean": _mean(
            [float(s["first_failure_s_full"]) for s in decidable
             if s.get("first_failure_s_full") is not None]
        ),
        "saving_ratio_samples": len(timed),
        "saving_ratio_mean": _mean(savings),
        "saving_ratio_min": round(min(savings), 6) if savings else None,
        "saving_ratio_max": round(max(savings), 6) if savings else None,
        # 有确定漏选的样本按 0 收益计的版本（"不用夜间补跑把白天的漏检改记为零"）。
        "charged_saving_ratio_mean": _mean(charged),
        "first_recorded_at": min(stamps) if stamps else None,
        "last_recorded_at": max(stamps) if stamps else None,
        "distinct_days": len(clean_days),
        "days": clean_days,
        "all_sample_days": len(all_days),
        "distinct_revisions": len(clean_revisions),
        "revisions": clean_revisions[:20],
        "distinct_projects": len({s.get("project") for s in clean if s.get("project")}),
        # 门槛只认干净样本的正净收益（0/负都不行）。单列出来，省得别人从 saving_ratio_mean
        # （它按"确定漏选记 0"的 charged 口径算过）里误读。
        "clean_saving_ratio_mean": _mean([_saving_ratio(s) for s in timed]),
    }


def _elapsed_days(samples: list[dict]) -> int:
    stamps = sorted((s.get("recorded_at") or "")[:10] for s in samples if s.get("recorded_at"))
    if len(stamps) < 2:
        return 0
    first = datetime.strptime(stamps[0], "%Y-%m-%d")
    last = datetime.strptime(stamps[-1], "%Y-%m-%d")
    return (last - first).days


def build_policy(
    samples: list[dict], *,
    min_samples: int = DEFAULT_MIN_SAMPLES,
    min_days: int = DEFAULT_MIN_DAYS,
    min_revisions: int = DEFAULT_MIN_REVISIONS,
    target_saving: float = DEFAULT_TARGET_SAVING,
    generated_at: str | None = None,
) -> dict:
    """由试用轨迹算出「选择模式的启用范围」（纯函数，规则见模块 docstring）。"""
    strata: dict[tuple[str, str], list[dict]] = {}
    for sample in samples:
        if sample.get("status") == STATUS_FULL_VERIFICATION:
            # "关掉选择后的完整验证"是 kill-switch 证据，不是某一层的使用样本：
            # 它不进任何层的门槛判断（但会出现在 overall 的 full_verification_samples 里）。
            continue
        key = (sample.get("project") or "?", sample.get("change_type") or "?")
        strata.setdefault(key, []).append(sample)

    entries = []
    for (project, change_type), group in sorted(strata.items()):
        summary = summarize(group)
        elapsed = _elapsed_days(group)
        blocking = []
        if summary["clean_samples"] < min_samples:
            blocking.append(
                f"干净可判定样本 {summary['clean_samples']}/{min_samples} 不足"
                "（判不了、两臂矛盾、以及旧样本里「是否矛盾」未知的都不算覆盖）"
            )
        if summary["distinct_revisions"] < min_revisions:
            blocking.append(
                f"干净样本只横跨 {summary['distinct_revisions']} 个不同目标版本，未达 "
                f"{min_revisions}（同一版本重复跑不算独立覆盖）"
            )
        if min_days > 0 and summary["distinct_days"] < min_days:
            blocking.append(
                f"（显式要求的）日历门槛未达：干净样本只占 {summary['distinct_days']} 个不同日期，"
                f"少于 {min_days}（日历默认不是门槛，这里是你显式给的门槛）"
            )
        if summary["definite_miss_samples"]:
            blocking.append(f"有 {summary['definite_miss_samples']} 个样本出现确定的漏选")
        if summary["indeterminate_miss_samples"]:
            # 「判不了」不是「没漏」：这类样本既证明不了安全，也不构成覆盖。
            blocking.append(
                f"有 {summary['indeterminate_miss_samples']} 个样本的漏选**判不了**"
                "（不稳定/运行错误证据）——判不了不算干净成功证据"
            )
        if summary["contradictory_samples"]:
            blocking.append(
                f"有 {summary['contradictory_samples']} 个样本出现两臂互相矛盾"
                "（同一测试一次失败一次通过）：说明结果与顺序/状态有关，不能当成功证据"
            )
        if summary["unknown_contradiction_samples"]:
            blocking.append(
                f"有 {summary['unknown_contradiction_samples']} 个样本「是否矛盾」未知"
                "（收紧之前写下的旧报告/账本没记这条，也重算不出来）——未知不减分变成加分"
            )
        if summary["fallback_rate"] == 1.0:
            blocking.append("全部样本都回退全量：选择在这一层省不下任何东西")
        # 正净收益门槛（2026-10-01 口径收紧）：0 与负数都不行——"白跑一遍"或"更慢"都不是收益。
        net = summary["clean_saving_ratio_mean"]
        if net is None:
            blocking.append("干净样本里没有一条同时报了两次耗时：净收益无法判定")
        elif net <= 0:
            blocking.append(
                f"干净样本的平均降时 {net:+.4f} 不是**正**净收益"
                "（0 = 白跑一遍；负数 = 选择比全量还慢，如实带符号报告、不做截断）"
            )
        entries.append({
            "project": project,
            "change_type": change_type,
            "enable_selection": not blocking,
            "blocking_reasons": blocking,
            "elapsed_days": elapsed,
            # 覆盖信号（不是门槛）：批证据是不是集中在同一天、同一个项目，人应该看得见。
            "coverage_signals": {
                "distinct_revisions": summary["distinct_revisions"],
                "distinct_projects": summary["distinct_projects"],
                "distinct_days": summary["distinct_days"],
                "elapsed_days": elapsed,
            },
            **summary,
        })

    enabled = [f"{e['project']}/{e['change_type']}" for e in entries if e["enable_selection"]]
    overall = summarize(samples)
    saving = overall["saving_ratio_mean"]
    charged = overall["charged_saving_ratio_mean"]
    return {
        "schema": POLICY_SCHEMA,
        "product_version": f"smart-test-sorter/{__version__}",
        "generated_at": generated_at or _utc_now(),
        "thresholds": {
            "min_samples": min_samples,
            "min_revisions": min_revisions,
            "min_days": min_days,
            "min_days_is_a_gate": min_days > 0,
            "target_saving_ratio": target_saving,
            "min_net_saving_ratio": 0.0,
            # 规则身份：策略产物是**我们自己的研究产物**（不进 VG—STS 契约），但规则换过口径，
            # 必须能分清新旧读数——2026-10-01 收紧后旧产物仍按老规则解释。
            "rule_version": RULE_VERSION,
            "rule": (
                "某层启用选择必须同时满足：**干净**可判定样本量足够（量）、横跨足够多的不同目标版本"
                "（独立性）、零确定漏选、无「判不了」样本、无两臂矛盾（含旧样本「是否矛盾」未知）、"
                "且干净样本的平均降时是**正**净收益（0 与负数都不行；全部回退全量自然也不满足）。"
                "`min_days > 0` 时才额外要求日历跨度：日历默认**不是**门槛，"
                "`distinct_days`/`elapsed_days` 只作为覆盖信号报告出来。"
            ),
        },
        "overall": {
            **overall,
            "elapsed_days": _elapsed_days(samples),
            "projects": sorted({s.get("project") for s in samples if s.get("project")}),
            "change_types": sorted({s.get("change_type") for s in samples if s.get("change_type")}),
        },
        "strata": entries,
        "default_enabled": False,
        "enabled_strata": enabled,
        "verdict": "enable-listed-strata" if enabled else "keep-selection-disabled",
        "target": {
            "saving_ratio": target_saving,
            "observed_saving_ratio": saving,
            "observed_charged_saving_ratio": charged,
            "met": None if saving is None else saving >= target_saving,
            "met_charged": None if charged is None else charged >= target_saving,
            "note": (
                "40% 是原探索目标，达到与否都如实报告；charged 口径把「有确定漏选的样本」"
                "按 0 收益计，避免用事后补跑把白天的漏检改记为零成本。"
            ),
        },
        "kill_switch": {
            "default": "关闭（pytest 不加 --smart-select 就是完整运行）",
            "full_verification_commands": [
                "python -m smart_sorter.shadow --repo <仓库> --mode full --out full.json",
                "pytest（不加 --smart-select）",
            ],
            "full_verification_samples": overall["full_verification_samples"],
            "note": (
                "关闭选择后仍可完整验证：full 模式的影子报告会进账本，标成 "
                "full-verification，不参与收益统计，只用来证明「关得掉、且关掉后跑得全」。"
            ),
        },
        "note": (
            "本文件是**建议**，不是开关本身：产品默认不启用选择；启用范围由使用者按本文件"
            "逐层判断。任一门槛未达即「保持关闭」。覆盖由「量 + 跨版本独立性」承担；"
            "日历跨度只作为信号报告，想按日历守时请显式给 --min-days。"
        ),
    }


def read_ledger(path: str) -> list[dict]:
    """读只追加的 JSONL 账本；坏行响亮报错，不静默跳过（账本是证据，不许含糊）。"""
    ledger = Path(path)
    if not ledger.exists():
        return []
    samples = []
    for number, line in enumerate(ledger.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            doc = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"账本第 {number} 行不是合法 JSON：{exc}") from exc
        if not isinstance(doc, dict):
            raise ValueError(
                f"账本第 {number} 行顶层必须是 JSON 对象（实际 {type(doc).__name__}）"
            )
        if doc.get("schema") != LEDGER_SCHEMA:
            raise ValueError(
                f"账本第 {number} 行的 schema 是 {doc.get('schema')!r}，不是 {LEDGER_SCHEMA}"
            )
        if doc.get("status") not in (_USAGE_STATUSES | {STATUS_FULL_VERIFICATION}):
            # 看不懂的行必须响亮失败：静默丢掉一行就等于悄悄改了证据。
            raise ValueError(
                f"账本第 {number} 行的 status={doc.get('status')!r} 不认识"
                f"（认识的是 {sorted(_USAGE_STATUSES | {STATUS_FULL_VERIFICATION})}）"
            )
        samples.append(doc)
    return samples


def append_ledger(path: str, sample: dict) -> None:
    ledger = Path(path)
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(sample, ensure_ascii=False) + "\n")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="smart_sorter.trial",
        description="记录真实试用轨迹，并按「证据覆盖」决定选择模式的启用范围（默认保持关闭）。",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    record = sub.add_parser("record", help="把一份真实影子报告记成一条试用样本（只追加）")
    record.add_argument("--report", required=True, help="python -m smart_sorter.shadow 产出的报告")
    record.add_argument("--project", required=True, help="真实项目名（如 experiment-httpx）")
    record.add_argument("--change-type", required=True,
                        help="变化类型（如 src-only / tests-only / docs-only / non-python / mixed）")
    record.add_argument("--ledger", default=DEFAULT_LEDGER, help=f"JSONL 账本，默认 {DEFAULT_LEDGER}")
    record.add_argument("--recorded-at", default=None,
                        help="显式指定记录时间（UTC ISO），便于可复现的试用证据")
    record.add_argument("--note", default="", help="备注（写清这次样本的来源）")

    decide = sub.add_parser("decide", help="由轨迹算出启用范围（哪一层可以开、哪一层必须关）")
    decide.add_argument("--ledger", default=DEFAULT_LEDGER)
    decide.add_argument("--out", default=None, help="把策略 JSON 写到该文件（stdout 仍输出同一份）")
    decide.add_argument("--min-samples", type=int, default=DEFAULT_MIN_SAMPLES)
    decide.add_argument("--min-revisions", type=int, default=DEFAULT_MIN_REVISIONS,
                        help="独立覆盖：可判定样本至少要横跨多少个不同目标版本（默认 2）")
    decide.add_argument("--min-days", type=int, default=DEFAULT_MIN_DAYS,
                        help="可选的日历门槛（默认 0 = 不设）：想要求『必须跨 N 天真实使用』时才显式给")
    decide.add_argument("--target-saving", type=float, default=DEFAULT_TARGET_SAVING)
    decide.add_argument("--generated-at", default=None, help="显式指定生成时间（UTC ISO）")

    status = sub.add_parser("status", help="只打印账本指标（不做决定）")
    status.add_argument("--ledger", default=DEFAULT_LEDGER)
    return parser


def main(argv: list[str] | None = None) -> int:
    plan_request._force_utf8_output()
    args = build_parser().parse_args(argv)

    def log(message: str) -> None:
        print(f"[trial] {message}", file=sys.stderr)

    try:
        if args.command == "record":
            report_path = Path(args.report)
            try:
                report = json.loads(report_path.read_text(encoding="utf-8"))
            except FileNotFoundError:
                return _usage_error(f"报告文件不存在 -> {args.report}")
            except (OSError, json.JSONDecodeError) as exc:
                return _usage_error(f"报告文件读不了 -> {args.report}：{exc}")
            sample = sample_from_report(
                report, project=args.project, change_type=args.change_type,
                recorded_at=args.recorded_at, note=args.note,
            )
            sample["report"] = str(report_path)
            append_ledger(args.ledger, sample)
            log(
                f"已记账：{sample['project']}/{sample['change_type']} status={sample['status']} "
                f"verdict={sample['verdict']} scope={sample['selection_scope']} -> {args.ledger}"
            )
            print(json.dumps(sample, ensure_ascii=False, indent=2))
            return _EXIT_OK

        samples = read_ledger(args.ledger)
        if not samples:
            log(f"账本为空或不存在：{args.ledger}（没有样本就没有证据，不做任何决定）")
            print(json.dumps(
                {"ok": False, "error_kind": "empty-ledger", "reason": f"账本为空：{args.ledger}"},
                ensure_ascii=False,
            ))
            return _EXIT_EMPTY

        if args.command == "status":
            print(json.dumps(summarize(samples), ensure_ascii=False, indent=2))
            return _EXIT_OK

        if args.min_samples < 1 or args.min_days < 0 or args.min_revisions < 1:
            return _usage_error("--min-samples 必须 ≥1；--min-revisions 必须 ≥1；--min-days 必须 ≥0")
        policy = build_policy(
            samples, min_samples=args.min_samples, min_days=args.min_days,
            min_revisions=args.min_revisions,
            target_saving=args.target_saving, generated_at=args.generated_at,
        )
    except (ValueError, OSError) as exc:
        return _usage_error(str(exc))

    text = json.dumps(policy, ensure_ascii=False, indent=2)
    if args.out:
        try:
            Path(args.out).write_text(text + "\n", encoding="utf-8")
        except OSError as exc:
            return _usage_error(f"无法写出 {args.out}：{exc}")
        log(f"已写出 {args.out}")
    print(text)

    log(
        f"verdict={policy['verdict']} 样本={policy['overall']['samples']} "
        f"日期={policy['overall']['distinct_days']} 启用层={policy['enabled_strata'] or '（无，保持关闭）'} "
        f"平均降时={policy['overall']['saving_ratio_mean']} "
        f"（计漏检后 {policy['overall']['charged_saving_ratio_mean']}）"
    )
    return _EXIT_OK


def _usage_error(reason: str) -> int:
    print(f"[trial] 错误：{reason}", file=sys.stderr)
    print(json.dumps(
        {"ok": False, "error_kind": "input-error", "reason": reason}, ensure_ascii=False,
    ))
    return _EXIT_USAGE


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
