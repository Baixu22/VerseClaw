"""命令行入口：给定 repo（可选 commit），打印推荐优先跑的测试排序。

用法:
    python -m smart_sorter <repo_path> [commit_hash] [--xml-dir PATH] [--top-k N]

不给 commit_hash 时，默认分析【工作区未提交改动】（staged + unstaged + untracked）——
覆盖"刚改完还没 commit 就想看该跑哪些测试"的日常场景。给了 commit 则分析该历史提交。
"""

from __future__ import annotations

import argparse
import sys

import git

from smart_sorter import revision
from smart_sorter.ast_diff import get_changed_functions
from smart_sorter.scorer import prioritize


def _force_utf8_output() -> None:
    """让标准输出/错误用 UTF-8，避免 Windows 默认 GBK 终端把中文打成乱码。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8")
            except (ValueError, OSError):
                pass


def build_parser() -> argparse.ArgumentParser:
    """构造命令行参数解析器（只用标准库 argparse）。"""
    parser = argparse.ArgumentParser(
        prog="smart_sorter",
        description="函数级回归测试优先级排序：根据某次 commit 的改动推荐先跑哪些测试。",
    )
    parser.add_argument("repo_path", help="目标 git 仓库路径")
    parser.add_argument(
        "commit_hash",
        nargs="?",
        default=revision.WORKTREE,
        help="要分析的 commit hash（可用短哈希）；省略则分析工作区未提交改动",
    )
    parser.add_argument(
        "--xml-dir",
        default=None,
        help="历史 JUnit XML 目录，用于按历史失败率加权（可选）",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=None,
        help="只显示前 K 个测试（默认全部显示）",
    )
    parser.add_argument(
        "--test-dir",
        default="tests",
        help="仓库内测试目录名，默认 tests",
    )
    parser.add_argument(
        "--no-graph",
        action="store_true",
        help="关闭调用图多跳分析，退回一跳名称匹配（MVP 行为）",
    )
    parser.add_argument(
        "--max-hops",
        type=int,
        default=4,
        help="调用图模式下反向 BFS 的最大跳数，默认 4",
    )
    parser.add_argument(
        "--emit-plan",
        action="store_true",
        help="改为输出一份 v1.1 test_plan JSON（机器可读走 stdout，日志走 stderr）；"
             "会先跑 pytest --collect-only 取真实 nodeid，再交统一计划引擎生成",
    )
    parser.add_argument(
        "--request-id",
        default="cli-request",
        help="--emit-plan 时写入计划的 request_id（默认 cli-request）",
    )
    parser.add_argument(
        "--plan-id",
        default="cli-plan",
        help="--emit-plan 时写入计划的 plan_id（默认 cli-plan）",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """CLI 主流程。返回进程退出码（0 成功，非 0 表示出错）。"""
    _force_utf8_output()
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.emit_plan:
        return _emit_plan(args)

    # 统一的错误处理：仓库/commit 有问题时给清晰提示，而不是抛栈。
    try:
        source = revision.resolve(args.repo_path, args.commit_hash)
        changed = get_changed_functions(args.repo_path, args.commit_hash)
        ranked = prioritize(
            args.repo_path,
            args.commit_hash,
            xml_dir=args.xml_dir,
            test_dir=args.test_dir,
            use_graph=not args.no_graph,
            max_hops=args.max_hops,
        )
    except git.exc.NoSuchPathError:
        print(f"错误：仓库路径不存在 -> {args.repo_path}", file=sys.stderr)
        return 2
    except git.exc.InvalidGitRepositoryError:
        print(f"错误：不是有效的 git 仓库 -> {args.repo_path}", file=sys.stderr)
        return 2
    except (git.exc.BadName, ValueError):
        print(f"错误：找不到 commit -> {args.commit_hash}", file=sys.stderr)
        return 2

    _print_report(revision.describe(source), changed, ranked, args.top_k)
    return 0


def _collect_nodeids(repo_path: str, test_dir: str) -> list[str]:
    """跑 pytest --collect-only 取真实 nodeid（保留参数化后缀）。

    实际收集由 smart_sorter.collect 提供——宿主请求入口（plan_request）用同一份实现，
    两个入口的 nodeid 口径与失败归类因此不可能漂移。返回排序后的 nodeid；收集不成功返回
    空列表，由调用方据此改走 refusal。
    """
    from smart_sorter import collect

    return collect.collect_nodeids(repo_path, test_dir).nodeids


def _emit_plan(args) -> int:
    """--emit-plan：收集真实 nodeid -> 统一计划引擎 -> 输出 v1.1 test_plan JSON。

    机器可读 JSON 走 stdout，人类日志走 stderr（与 contracts CLI 同源约定）。
    收集不到任何 nodeid -> 输出 plan_refusal，退出码 3（收集失败 / 依赖不可用分别归类）。
    """
    import json

    from smart_sorter import collect, contracts, plan

    try:
        source = revision.resolve(args.repo_path, args.commit_hash)
    except (git.exc.NoSuchPathError, git.exc.InvalidGitRepositoryError):
        print(f"错误：仓库路径无效 -> {args.repo_path}", file=sys.stderr)
        return 2
    except (git.exc.BadName, ValueError):
        print(f"错误：找不到 commit -> {args.commit_hash}", file=sys.stderr)
        return 2

    result = collect.collect_nodeids(args.repo_path, args.test_dir)
    if not result.succeeded:
        # 收集不到测试全集：如实报告无法规划。目标可确认（revision 解析成功），但收集
        # 未成功，故 conservative_full_available=False。
        refusal = plan.build_refusal(
            args.request_id, result.code, result.detail,
            target_identity=source.identity, collected_count=0,
            collection_succeeded=False,
        )
        print(json.dumps(refusal, ensure_ascii=False, indent=2))
        print(f"[plan] {result.detail}，已输出 plan_refusal({result.code})。", file=sys.stderr)
        assert contracts.validate(refusal, "refusal") == []
        return 3

    doc = plan.build_plan(
        args.repo_path, args.commit_hash, result.nodeids,
        request_id=args.request_id, plan_id=args.plan_id,
        xml_dir=args.xml_dir, test_dir=args.test_dir,
    )
    errs = contracts.validate(doc, "plan")
    print(json.dumps(doc, ensure_ascii=False, indent=2))
    if errs:
        # 引擎产出的计划竟不合契约：这是 bug，响亮报错而非静默放行。
        print(f"[plan] 内部错误：生成的计划不符合契约：{errs}", file=sys.stderr)
        return 2
    print(
        f"[plan] {revision.describe(source)}：collected={len(doc['collected'])} "
        f"selected={len(doc['selected'])} scope={doc['selection_scope']}",
        file=sys.stderr,
    )
    return 0



def _print_report(
    target_desc: str,
    changed: list[dict],
    ranked: list[tuple[str, float]],
    top_k: int | None,
) -> None:
    """把分析结果格式化打印到终端（纯文本，无颜色/进度条）。"""
    shown = ranked[:top_k] if top_k else ranked

    print("=== Smart Test Sorter ===")
    print(f"分析目标: {target_desc}")
    print(f"Changed functions: {len(changed)}")
    print(f"Affected tests: {len(ranked)}")
    print()

    if not shown:
        print("没有检测到受影响的测试（可能该 commit 未改动被测函数）。")
        return

    # 表头
    print(f"{'Priority':<10}{'Score':<8}Test")
    for i, (name, score) in enumerate(shown, start=1):
        print(f"{i:<10}{score:<8.2f}{name}")

    print()
    print("Suggested command:")
    node_ids = " ".join(name for name, _ in shown)
    print(f"  pytest {node_ids}")


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
