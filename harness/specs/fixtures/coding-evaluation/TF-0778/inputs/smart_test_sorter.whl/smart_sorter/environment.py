"""Runtime identity shared by the host probe, planning and execution."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import sys


def identity() -> dict[str, str]:
    # Describe installed distributions, not a lockfile or a caller's declaration.
    distributions = sorted({
        f"{dist.metadata['Name'].lower()}=={dist.version}"
        for dist in importlib.metadata.distributions()
    })
    return {
        "python": ".".join(map(str, sys.version_info[:3])),
        "platform": sys.platform,
        "dependencies_digest": "sha256:" + hashlib.sha256(
            "\n".join(distributions).encode("utf-8")
        ).hexdigest(),
    }


def mismatch(expected: dict, actual: dict) -> str | None:
    for field in ("python", "platform", "dependencies_digest"):
        if field in expected and expected[field] != actual.get(field):
            return f"环境不匹配：{field} 声明 {expected[field]!r}，实际 {actual.get(field)!r}"
    return None


if __name__ == "__main__":
    print(json.dumps(identity(), ensure_ascii=False))
