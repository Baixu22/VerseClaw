"""VG—STS v1 契约校验（纯标准库）。

VG 与 STS 用 `contracts/vg-sts/v1/` 下的 JSON Schema 作为一次性请求(request)、测试计划
(plan)、执行结果(result)的共同语言。本模块提供两层检查，两仓与实验都复用它，避免各自
手写一份、口径漂移：

  1. 结构校验：一个【最小 JSON Schema 子集】校验器（draft-07 的常用关键字），只依赖标准
     库，不引入 jsonschema，符合本项目"核心只用 ast + gitpython + stdlib"的约束。
  2. 语义校验：schema 表达不了的跨字段不变量——选择范围(selected/full)、执行完成度
     (complete/incomplete)、结果有效性(valid/invalid)三个维度不能相互顶替；空选/零执行不得
     标成完整通过；预算中止不得算 complete；candidate 模式必须给全两侧 OID 等。

设计原则与 safety.py / revision.py 一致：判定是纯函数，返回【错误原因列表】（空=通过），
不抛异常、不打印，方便 pytest 与 CLI 两处复用。CLI 见文件末尾 main()。
"""

from __future__ import annotations

import json
import re
from pathlib import Path

# 契约数据的两个存放位置（内容必须逐字节一致）：
#   1) 装好的 wheel 里：契约随包发布在 smart_sorter/_contract/vg-sts/v1/
#      （构建时由 setup.py 的 build_py 钩子从权威目录复制，并当场按 manifest 摘要校验）；
#   2) 源码 checkout 里：仓库根的 contracts/vg-sts/v1/——**权威**内容就在这里。
# 运行时按顺序找第一个存在的。产品装到源码目录之外也必须能跑，所以 1) 不能省；
# 而 2) 作为源码运行（含测试与开发）时的唯一来源。
_PACKAGED_CONTRACT = Path(__file__).resolve().parent / "_contract" / "vg-sts" / "v1"
_CHECKOUT_CONTRACT = (
    Path(__file__).resolve().parent.parent.parent / "contracts" / "vg-sts" / "v1"
)


def _find_contract_root(tree: str = "v1") -> Path:
    """挑一个存在的契约根；都不存在时返回源码路径（报错信息比包内路径更有用）。"""
    for candidate in (_PACKAGED_CONTRACT.parent / tree, _CHECKOUT_CONTRACT.parent / tree):
        if candidate.is_dir():
            return candidate
    return _CHECKOUT_CONTRACT.parent / tree


_CONTRACT_ROOT = _find_contract_root()

# 本产品实现支持的协议版本集合。未知版本必须拒绝，不静默猜测兼容。
# 1.1 相对 1.0 只做【向后兼容的放宽/新增】：risk.hints 的 symbol 变可选、
# 新增 plan_refusal 对象、若干更严的语义规则。1.0 请求/计划/结果在 1.1 下仍全部合法，
# 因此两版都受支持，VG 已固定的 1.0 消费不受破坏。
SUPPORTED_PROTOCOL_VERSIONS = frozenset({"1.0", "1.1"})

# 文档种类 -> schema 文件名。
_SCHEMA_FILES = {
    "request": "candidate_request.schema.json",
    "plan": "test_plan.schema.json",
    "result": "execution_result.schema.json",
    "refusal": "plan_refusal.schema.json",
}


def contract_root() -> Path:
    """契约根目录（装好的包里是包内副本，源码 checkout 里是仓库根 contracts/）。

    测试与 CLI 共用，避免各自拼路径。产品入口（plan_request/run_plan）在运行时也依赖它，
    所以它必须在【源码目录之外】的安装环境里同样可用——这是 TF-0025 抓到的打包缺陷。
    """
    return _CONTRACT_ROOT


def load_schema(kind: str, root: Path | None = None) -> dict:
    """按种类('request'|'plan'|'result'|'refusal')加载 JSON Schema。

    `root` 是**给契约草案用**的旁路：默认仍指向权威契约根（v1），显式传入时才换根。
    这样"用同一套 schema 引擎校验草案目录"不需要第二份校验器实现，也不会改变 v1 的任何行为。
    """
    try:
        name = _SCHEMA_FILES[kind]
    except KeyError:
        raise ValueError(f"未知文档种类：{kind!r}，应为 {sorted(_SCHEMA_FILES)} 之一") from None
    base = root or _CONTRACT_ROOT
    path = base / "schema" / name
    if not path.is_file():
        # 正常情况下不会发生：wheel 里带了契约副本、源码树里有权威目录。真缺了就给一句
        # 可操作的话，而不是抛一个只有路径的 FileNotFoundError。
        raise ValueError(
            f"契约 schema 缺失：{path}（安装包应自带契约数据；从源码运行时请在仓库根下调用）"
        )
    return json.loads(path.read_text(encoding="utf-8"))


# ---- 第 1 层：最小 JSON Schema 子集校验器 -----------------------------------
#
# 支持的 draft-07 关键字（够本契约用，不追求完整）：
#   type / required / properties / additionalProperties / enum / const /
#   items / minItems / minimum / pattern / minLength / $ref(仅 #/$defs/*) / oneOf
# $ref 只解析同文档的 "#/$defs/<name>"（本契约所有引用都是这种形式）。

_TYPE_CHECKS = {
    "object": lambda v: isinstance(v, dict),
    "array": lambda v: isinstance(v, list),
    "string": lambda v: isinstance(v, str),
    "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
    "number": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
    "null": lambda v: v is None,
}


def _resolve_ref(ref: str, root: dict) -> dict:
    """解析 '#/$defs/<name>' 形式的本地引用；其它形式视为不支持。"""
    if not ref.startswith("#/"):
        raise ValueError(f"仅支持本地 $ref(#/...)，收到：{ref!r}")
    node: object = root
    for part in ref[2:].split("/"):
        node = node[part]
    return node  # type: ignore[return-value]


def _validate_node(value: object, schema: dict, root: dict, path: str, errs: list[str]) -> None:
    """针对单个 schema 节点校验 value，把错误追加进 errs（path 用于定位）。"""
    if "$ref" in schema:
        _validate_node(value, _resolve_ref(schema["$ref"], root), root, path, errs)
        return

    if "oneOf" in schema:
        matched = 0
        for sub in schema["oneOf"]:
            trial: list[str] = []
            _validate_node(value, sub, root, path, trial)
            if not trial:
                matched += 1
        if matched != 1:
            errs.append(f"{path}: 不满足恰好一个 oneOf 分支（匹配 {matched} 个）")
        return

    _validate_keywords(value, schema, root, path, errs)


def _validate_keywords(value: object, schema: dict, root: dict, path: str, errs: list[str]) -> None:
    """校验单个 schema 节点里除 $ref/oneOf 外的关键字。"""
    expected_type = schema.get("type")
    if expected_type is not None:
        types = expected_type if isinstance(expected_type, list) else [expected_type]
        if not any(_TYPE_CHECKS[t](value) for t in types):
            errs.append(f"{path}: 期望类型 {expected_type}，实际 {type(value).__name__}")
            return  # 类型不符，后续基于类型的检查无意义

    if "const" in schema and value != schema["const"]:
        errs.append(f"{path}: 期望常量 {schema['const']!r}，实际 {value!r}")
    if "enum" in schema and value not in schema["enum"]:
        errs.append(f"{path}: {value!r} 不在允许取值 {schema['enum']} 内")

    if isinstance(value, str):
        if "minLength" in schema and len(value) < schema["minLength"]:
            errs.append(f"{path}: 字符串过短（<{schema['minLength']}）")
        pat = schema.get("pattern")
        if pat is not None and not re.search(pat, value):
            errs.append(f"{path}: 不匹配模式 {pat!r}")

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            errs.append(f"{path}: 小于最小值 {schema['minimum']}")

    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            errs.append(f"{path}: 数组元素过少（<{schema['minItems']}）")
        item_schema = schema.get("items")
        if item_schema is not None:
            for i, item in enumerate(value):
                _validate_node(item, item_schema, root, f"{path}[{i}]", errs)

    if isinstance(value, dict):
        _validate_object(value, schema, root, path, errs)


def _validate_object(value: dict, schema: dict, root: dict, path: str, errs: list[str]) -> None:
    """object 专属：required / properties / additionalProperties。"""
    for req in schema.get("required", []):
        if req not in value:
            errs.append(f"{path}: 缺少必填字段 {req!r}")

    props = schema.get("properties", {})
    for key, sub_value in value.items():
        if key in props:
            _validate_node(sub_value, props[key], root, f"{path}.{key}", errs)
        elif schema.get("additionalProperties") is False:
            errs.append(f"{path}: 出现未声明字段 {key!r}")


def validate_schema(doc: object, kind: str, root: Path | None = None) -> list[str]:
    """只做【结构】校验：返回错误原因列表（空=通过）。kind∈{request,plan,result,refusal}。

    `root` 用于校验**契约草案**（旁路到草案目录）。默认仍是权威契约根，v1 行为一字不变。
    """
    schema = load_schema(kind, root)
    errs: list[str] = []
    _validate_node(doc, schema, schema, kind, errs)
    return errs


# ---- 第 2 层：跨字段语义不变量（schema 表达不了的）--------------------------


def _protocol_error(doc: dict) -> list[str]:
    """协议版本白名单：未知版本一律拒绝，四种文档口径一致（不静默兼容）。

    这四种文档（request/plan/result/refusal）共用同一套受支持集合，所以检查放在一处；
    早先只有 request/refusal 查了它，plan/result 会漏掉 `protocol_version=9.9` 这种输入。
    """
    if doc.get("protocol_version") not in SUPPORTED_PROTOCOL_VERSIONS:
        return [
            f"协议版本 {doc.get('protocol_version')!r} 不受支持"
            f"（支持 {sorted(SUPPORTED_PROTOCOL_VERSIONS)}），拒绝而非静默兼容"
        ]
    return []


def _semantic_request(doc: dict) -> list[str]:
    """请求语义：协议版本受支持；各 mode 的目标身份齐全；candidate 两侧 OID 必须给全。"""
    errs: list[str] = _protocol_error(doc)
    mode = doc.get("mode")
    target = doc.get("target") or {}
    identities = doc.get("identities") or {}
    if mode == "candidate":
        # 候选模式：两侧变更并集，必须给全 base/ours/theirs + 候选目录，禁止只比第一父。
        for f in ("candidate_dir", "base_oid", "ours_oid", "theirs_oid"):
            if not target.get(f):
                errs.append(f"candidate 模式缺少目标字段 target.{f}（两侧变更并集所需，不能只比第一父）")
        # 候选内容身份由 tree/commit OID 唯一确定；必须给出其一，且不用工作树指纹。
        if not target.get("candidate_tree_oid") and not target.get("candidate_commit_oid"):
            errs.append(
                "candidate 模式必须给出 target.candidate_tree_oid 或 candidate_commit_oid "
                "作为候选内容身份（候选目录仅作定位，临时路径不能当唯一身份）"
            )
        if identities.get("worktree_content_digest"):
            errs.append(
                "candidate 模式不应携带 identities.worktree_content_digest"
                "（候选是已物化的树，内容身份用 candidate_tree_oid/candidate_commit_oid，省略工作树指纹）"
            )
    elif mode == "commit":
        if not target.get("commit_oid"):
            errs.append("commit 模式缺少 target.commit_oid")
        if identities.get("worktree_content_digest"):
            errs.append("commit 模式不应携带 identities.worktree_content_digest（历史提交内容身份由 commit_oid 确定）")
    elif mode == "workspace":
        if not target.get("head_oid"):
            errs.append("workspace 模式缺少 target.head_oid（工作区改动相对哪个 HEAD）")
    return errs


def _semantic_plan(doc: dict) -> list[str]:
    """计划语义：协议版本受支持；selected/excluded ⊆ collected 且互斥；order 是 selected 的排列；
    回退原因存在 ⇒ full；full ⇒ selected==collected。"""
    errs: list[str] = _protocol_error(doc)
    collected = set(doc.get("collected", []))
    selected = list(doc.get("selected", []))
    excluded = set(doc.get("excluded", []))
    selected_set = set(selected)
    scope = doc.get("selection_scope")

    if not selected_set <= collected:
        errs.append("selected 含 collected 之外的 nodeid（选择必须相对成功收集的全集可核对）")
    if not excluded <= collected:
        errs.append("excluded 含 collected 之外的 nodeid")
    if selected_set & excluded:
        errs.append("selected 与 excluded 相交（同一测试不能既选又排除）")
    if set(doc.get("order", [])) != selected_set:
        errs.append("order 必须恰好是 selected 的一个排列（确定可重放执行顺序）")

    fallback = doc.get("fallback") or []
    if fallback and scope != "full":
        errs.append("存在回退原因(fallback)但 selection_scope 不是 full")
    if scope == "full" and selected_set != collected:
        errs.append("selection_scope=full 时 selected 必须等于 collected 全集")
    if scope == "selected" and not selected_set and not excluded:
        errs.append("selection_scope=selected 但既无选中也无排除（空计划不得当作已规划）")

    # 风险裁定至少要能定位到被裁定的提示：symbol 或 path 给一个（提示可无符号）。
    for i, rd in enumerate(doc.get("risk_decisions") or []):
        if isinstance(rd, dict) and not rd.get("symbol") and not rd.get("path"):
            errs.append(f"risk_decisions[{i}] 必须给出 symbol 或 path 以定位被裁定的风险提示")
    return errs


def _semantic_result(doc: dict) -> list[str]:
    """结果语义：协议版本受支持；三维度分离；空选/零执行不得完整通过；incomplete/invalid 必带原因。"""
    errs: list[str] = _protocol_error(doc)
    completeness = doc.get("completeness")
    validity = doc.get("validity")
    executed = doc.get("executed", [])
    outcomes = doc.get("outcomes", {})
    exit_code = doc.get("raw_exit_code")

    if validity == "invalid" and not doc.get("invalid_reason"):
        errs.append("validity=invalid 必须给出 invalid_reason")
    if completeness == "incomplete" and not doc.get("incomplete_reason"):
        errs.append("completeness=incomplete 必须给出 incomplete_reason")
    # complete 表示计划内测试全部跑完：不能既标 complete 又留下未执行项（残缺输出陷阱）。
    if completeness == "complete" and doc.get("not_executed"):
        errs.append("completeness=complete 但 not_executed 非空（计划内有测试未跑完，应记为 incomplete）")

    # 空选/零执行不能被包装成完整通过（TF-0001/0021 的空选陷阱）。
    passed_clean = exit_code == 0 and completeness == "complete" and validity == "valid"
    if passed_clean and not executed:
        errs.append("零执行不得报告为完整有效通过（executed 为空）")

    # executed 与 outcomes 必须对齐：每个跑到的测试都要有事实记录。
    missing = [nid for nid in executed if nid not in outcomes]
    if missing:
        errs.append(f"executed 中 {len(missing)} 个 nodeid 缺少 outcomes 事实记录")

    # 原始退出码 0 通常意味着没有失败/错误；若 outcomes 里出现 failed/error 则矛盾。
    bad = [nid for nid, o in outcomes.items()
           if isinstance(o, dict) and o.get("outcome") in ("failed", "error")]
    if exit_code == 0 and bad:
        errs.append("raw_exit_code=0 但 outcomes 中存在 failed/error（退出码与事实矛盾）")
    return errs


_SEMANTIC = {"request": _semantic_request, "plan": _semantic_plan, "result": _semantic_result}


def _semantic_refusal(doc: dict) -> list[str]:
    """无法规划回执语义：协议版本受支持；只有目标可确认且成功收集到全集才允许保守全量。

    这是"无法规划"带内形状的核心安全不变量——防止 STS 在【不能确认目标】或【没拿到测试
    全集】时，让宿主 VG 以为可以安全地保守全量回退。
    """
    errs: list[str] = _protocol_error(doc)
    confirmable = doc.get("target_confirmable")
    full_ok = doc.get("conservative_full_available")
    if confirmable and not doc.get("target_identity"):
        errs.append("target_confirmable=true 必须给出 target_identity（已确认的目标身份）")
    attempted = doc.get("attempted_collection") or {}
    collected_all = bool(attempted.get("succeeded"))
    # 保守全量的前提：目标可确认 且 成功收集到测试全集，二者缺一不可。
    if full_ok and not (confirmable and collected_all):
        errs.append(
            "conservative_full_available=true 需同时满足 target_confirmable=true 与 "
            "attempted_collection.succeeded=true（未知目标或未收集到全集时不得声称可保守全量）"
        )
    return errs


_SEMANTIC["refusal"] = _semantic_refusal


def validate(doc: object, kind: str) -> list[str]:
    """结构 + 语义两层校验，返回错误原因列表（空=通过）。

    先结构后语义：结构不过时跳过语义（字段类型都不对，跨字段判断无意义）。
    """
    errs = validate_schema(doc, kind)
    if errs:
        return errs
    return _SEMANTIC[kind](doc)  # type: ignore[operator]


# ---- 跨文档绑定校验：request <-> plan <-> result 必须同指一次候选 -------------
#
# 单个文件各自合法，不代表它们说的是同一件事。VG 关心的"错候选"（plan/result 的
# target 与 request 不一致，或 plan_id 对不上）只能跨文档核对。这里做纯字段一致性
# 检查，不重新分析候选内容。


def validate_binding(request: dict, plan: dict, result: dict | None = None) -> list[str]:
    """核对 request/plan(/result) 是否绑定同一次请求与同一目标身份。

    只做身份链一致性（request_id、plan_id、target_identity、selection_scope、protocol_version），
    不做各自的结构/语义校验（那是 validate() 的职责，调用方应先分别过一遍）。
    返回错误原因列表（空=通过）。result 可选。

    **候选模式额外核一层**：request 没有单一 `target_identity` 字段（它用 mode+OID 表达目标），
    但只要它给了候选内容身份（`target.candidate_tree_oid`），计划/结果的 `target_identity` 就必须
    等于写死的口径 `candidate@<tree_oid 前 7 位小写>`（生成规则见 plan_request）。
    少了这一层，"错候选"只能靠 request_id 兜：一份 target_identity 漂移的计划会被静态绑定放行
    （TF-0024 复核 VG 联调包时实测到这个缺口，已补上；契约文件未动）。
    """
    errs: list[str] = []
    req_id = request.get("request_id")
    if plan.get("request_id") != req_id:
        errs.append(
            f"plan.request_id({plan.get('request_id')!r}) 与 request.request_id({req_id!r}) 不一致（错候选/张冠李戴）"
        )
    # 候选模式下的目标身份核对（能推就推：只有给了 candidate_tree_oid 才能推）。
    tree_oid = (request.get("target") or {}).get("candidate_tree_oid")
    if tree_oid:
        expected_identity = "candidate@" + str(tree_oid).strip().lower()[:7]
        if plan.get("target_identity") != expected_identity:
            errs.append(
                f"plan.target_identity({plan.get('target_identity')!r}) 与 request 的候选内容身份不一致："
                f"按 candidate@<candidate_tree_oid 前 7 位小写> 应为 {expected_identity!r}"
            )
        if result is not None and result.get("target_identity") != expected_identity:
            errs.append(
                f"result.target_identity({result.get('target_identity')!r}) 与 request 的候选内容身份不一致："
                f"应为 {expected_identity!r}"
            )
    # 目标身份漂移：request 侧没有单一 target_identity 字段（它用 mode+OID 表达），因此这里核对
    # plan 与 result 之间，并把 request_id 作为请求身份锚点；plan/result 的 target_identity 必须一致。
    if result is not None:
        if result.get("request_id") != req_id:
            errs.append(
                f"result.request_id({result.get('request_id')!r}) 与 request.request_id({req_id!r}) 不一致"
            )
        if result.get("plan_id") != plan.get("plan_id"):
            errs.append(
                f"result.plan_id({result.get('plan_id')!r}) 与 plan.plan_id({plan.get('plan_id')!r}) 不一致（结果未绑定该计划）"
            )
        if result.get("target_identity") != plan.get("target_identity"):
            errs.append(
                "result.target_identity 与 plan.target_identity 不一致（执行目标漂移，结果应记 invalid）"
            )
        if result.get("selection_scope") != plan.get("selection_scope"):
            errs.append(
                f"result.selection_scope({result.get('selection_scope')!r}) 与 "
                f"plan.selection_scope({plan.get('selection_scope')!r}) 不一致"
            )
    # 协议版本必须同一（不能一个 1.0 一个 1.1 混用）。
    versions = {request.get("protocol_version"), plan.get("protocol_version")}
    if result is not None:
        versions.add(result.get("protocol_version"))
    if len(versions) > 1:
        errs.append(f"request/plan/result 的 protocol_version 不一致：{sorted(str(v) for v in versions)}")
    return errs


# ---- CLI：python -m smart_sorter.contracts validate <file> --as <kind> ------
#
# 机器可读输出(JSON)走 stdout，人类日志走 stderr，两者分离。退出码：
#   0 通过 / 3 校验失败 / 2 用法或输入错误。


def _force_utf8_output() -> None:
    """避免 Windows GBK 终端把中文打成乱码（与 cli.py 同源做法）。"""
    import sys

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8")
            except (ValueError, OSError):
                pass


def main(argv: list[str] | None = None) -> int:
    """校验契约文件。两个子命令：

      validate <file> --as request|plan|result|refusal  单文件结构+语义校验
      bind --request R --plan P [--result X]             跨文件绑定一致性（错候选）
    """
    import argparse
    import sys

    _force_utf8_output()
    parser = argparse.ArgumentParser(
        prog="smart_sorter.contracts",
        description="校验 VG—STS v1 契约文件（结构 + 语义 + 跨文档绑定）。",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_val = sub.add_parser("validate", help="单文件结构+语义校验")
    p_val.add_argument("file", help="待校验的 JSON 文件路径")
    p_val.add_argument(
        "--as", dest="kind", required=True, choices=sorted(_SCHEMA_FILES),
        help="文档种类：request | plan | result | refusal",
    )

    p_bind = sub.add_parser("bind", help="跨文档绑定一致性（request/plan/result 是否同指一次候选）")
    p_bind.add_argument("--request", required=True, help="request JSON 文件")
    p_bind.add_argument("--plan", required=True, help="plan JSON 文件")
    p_bind.add_argument("--result", help="result JSON 文件（可选）")

    args = parser.parse_args(argv)

    def _load(path: str) -> object:
        return json.loads(Path(path).read_text(encoding="utf-8"))

    try:
        if args.command == "validate":
            doc = _load(args.file)
        else:  # bind
            req_doc = _load(args.request)
            plan_doc = _load(args.plan)
            res_doc = _load(args.result) if args.result else None
    except FileNotFoundError as exc:
        print(f"错误：文件不存在 -> {exc.filename}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"错误：JSON 解析失败 -> {exc}", file=sys.stderr)
        return 2

    if args.command == "validate":
        errors = validate(doc, args.kind)
        kind = args.kind
    else:
        errors = validate_binding(req_doc, plan_doc, res_doc)  # type: ignore[arg-type]
        kind = "binding"

    # 机器可读结论 -> stdout。
    print(json.dumps({"ok": not errors, "kind": kind, "errors": errors}, ensure_ascii=False))
    # 人类日志 -> stderr。
    if errors:
        print(f"[contracts] {kind} 校验失败，{len(errors)} 处问题：", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        return 3
    print(f"[contracts] {kind} 校验通过。", file=sys.stderr)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
